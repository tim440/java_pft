package ru.rgs.APITests.tests.contracts.dsago;

import com.google.common.collect.ImmutableMap;
import io.qameta.allure.Feature;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import ru.rgs.APITests.TestBase;
import ru.rgs.APITests.model.SearchContract.preview.ContractPreview;
import ru.rgs.APITests.model.SearchContract.search.RequestContractSearch;
import ru.rgs.APITests.model.contracts.delete.ContractDeleteResult;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static org.testng.Assert.assertEquals;

@Feature("Договор ДСАГО")
@Story("Удаление")
public class RemoveDsagoTests extends TestBase {

    private Client client;
    private String requestContractSearch;
    private Response responseContractSearch;

    @BeforeClass
    public void init() {
        client = storage.getClient();
    }

    @Test()
    public void removeDsagoTest() {
        /*ContractDeleteResult deleteContractResult = removeContract(client, "72018bc073050ea1511e79ed0", "private/data/module-dsago/DsagoWs/delete");
        assertEquals(deleteContractResult.isSuccess(), true);
*/
      log("\n ==================\n" + "Тест удаления ДСАГО" + "\n ==================\n");
        searchContract("2000000020", "ЕЕЕ");
        ContractPreview contractSearch = storage.getContractSearch();
        String contractId = contractSearch.getDataList().get(0).getId();
        removeContract(contractId);
      log("\n ==================\n" + "Завершение удаления ДСАГО" + "\n ==================\n");
    }

    @Step("Поиск договора для удаления")
    protected void searchContract(String contractNumber, String series) {
        String requestContractSearch = requestContract(contractNumber, series);
        responseContract(requestContractSearch);
    }

    @Step("Удаление договора")
    private void removeContract(String contractId) {
        String requestContract = requestContractRemove(contractId);
        responseContractRemove(requestContract);
    }


    @Step("обработка ответа на удаление договора")
    private void responseContractRemove(String requestContract) {
        Response agentContractRemoveResponse = getInvocation
                (target, Entity.entity(requestContract, MediaType.APPLICATION_FORM_URLENCODED_TYPE)).invoke();
        checkStatusResponse(agentContractRemoveResponse);
        ContractDeleteResult deleteContract = getDeleteContractResult(agentContractRemoveResponse);
        assertEquals(deleteContract.isSuccess(), false);
    }

    @Step("обработка запроса на удаление договора")
    private String requestContractRemove(String contractId) {
        String jsonRequestContractRemove = gson.toJson(ImmutableMap.of("id", contractId));
        String requestContractDel = "records=" + jsonRequestContractRemove;
        target = client.target(BASE_URL + "private/data/module-dsago/DsagoWs/delete");
        return requestContractDel;
    }


    @Step("Обработка результата поиска договора")
    protected void responseContract(String requestContractSearch) {
        Response contractSearchResponse = getInvocation(target, Entity.entity(requestContractSearch, MediaType.APPLICATION_FORM_URLENCODED_TYPE)).invoke();
        ContractPreview contractSearch = getContractSearchForDel(contractSearchResponse);
        storage.setContractSearch(contractSearch);
        assertEquals(contractSearch.isSuccess(), true);
    }

    @Step("Обработка запроса поиска договора")
    protected String requestContract(String contractNumber, String series) {
        RequestContractSearch requestContractSearch = new RequestContractSearch(series, contractNumber);
        String jsonRequestContract = gson.toJson(requestContractSearch);
        String requestContractFind = "constraints=" + jsonRequestContract + "&page=1&start=0&limit=100";
        target = client.target(BASE_URL + "private/data/module-search/ContractSearchWs/find");
        return requestContractFind;
    }
}