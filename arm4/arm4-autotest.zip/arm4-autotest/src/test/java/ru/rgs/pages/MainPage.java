package ru.rgs.pages;

import javafx.beans.value.WeakChangeListener;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ru.rgs.logic.ApplicationManager;

/**
 * Created by Алексей on 14.09.2016.
 */
public class MainPage extends AnyPage {

    public MainPage(PageManager pages) {
        super(pages);
    }

    @FindBy(xpath = ".//*[text()='Добавить ОА']/following-sibling::span")
    private WebElement createAgentReportButton;

    @FindBy(css = "div[id*='user-information-block'][class='x-panel x-panel-default']")
    private WebElement workDaysBlock;

    public MainPage clickCrateAgentReportButton() {
        click(createAgentReportButton);
        return this;
    }

    public WebElement getWorkDaysBlock() {
        return workDaysBlock;
    }
}
