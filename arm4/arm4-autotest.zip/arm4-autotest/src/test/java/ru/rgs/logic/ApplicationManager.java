package ru.rgs.logic;

import org.openqa.selenium.*;
import org.testng.ITestContext;
import org.testng.annotations.Listeners;
import ru.rgs.model.User;
import ru.rgs.util.EnvironmentInfo;
import ru.rgs.util.PropertyLoader;
import ru.rgs.util.TestListener;
import ru.stqa.selenium.factory.WebDriverFactory;
import ru.stqa.selenium.factory.WebDriverFactoryMode;

import java.io.IOException;
import java.util.Set;

/**
 * Менеджер
 */

public class ApplicationManager {

    private static String appURL;
    protected String gridHubUrl;
    protected Capabilities capabilities;
    private WebDriver driver;

    EnvironmentInfo env;

    private UserHelper userHelper;
    private MainHelper mainHelper;

    public ApplicationManager() throws IOException {
        env = EnvironmentInfo.instance();
        createWebDriver();

        userHelper = new UserHelper(this);
        mainHelper = new MainHelper(this);

    }

    private void createWebDriver() throws IOException {
        setAppUrl(PropertyLoader.loadProperty("site.url"));
        gridHubUrl = PropertyLoader.loadProperty("grid.url");
        if ("".equals(gridHubUrl)) {
            gridHubUrl = null;
        }
        capabilities = PropertyLoader.loadCapabilities();
        WebDriverFactory.setMode(WebDriverFactoryMode.THREADLOCAL_SINGLETON);
        driver = WebDriverFactory.getDriver(gridHubUrl, capabilities);
        driver.manage().window().maximize();
        driver.get(appURL);
    }

    private void openProject() {

    }

    public ApplicationManager login(String role) {
        User user = env.getUser(role);
        userHelper.loginAs(user);
        return this;
    }

    public UserHelper getUserHelper() {
        return userHelper;
    }

    public MainHelper getMainHelper() {
        return mainHelper;
    }

    public WebDriver getWebDriver() {
        return driver;
    }

    public EnvironmentInfo getEnvirinmentInstance() {
        return env;
    }

    public void setAppUrl(String appURL) {
        ApplicationManager.appURL = appURL;
    }

    public Set<Cookie> getCookies() {
        return driver.manage().getCookies();
    }

    public String getUrl() {
        return driver.getCurrentUrl();
    }

    public byte[] takeScreenshot() {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }
}