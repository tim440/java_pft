package ru.rgs.pages;

import org.openqa.selenium.WebDriver;

/**
 * Created by Алексей on 17.09.2016.
 */
public class ComponentManager {

    private WebDriver driver;
    public ListFormSelectionAgent listFormSelectionAgent;

    public ComponentManager(WebDriver driver) {
        this.driver = driver;
        listFormSelectionAgent = new ListFormSelectionAgent(this);
    }

    public WebDriver getWebDriver() {
        return driver;
    }
}
