package ru.rgs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Родительский компонент, от которого наследуются все остальные компонтенты
 */
public abstract class Component {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected ComponentManager components;

    public Component(ComponentManager components){
        this.components = components;
        driver = components.getWebDriver();
        wait = new WebDriverWait(driver, 10);
    }

    /*
     * Обязательный метод для всех компонентов именно в нем мы будем получать WebElement через ExtJS
     */
    protected abstract WebElement parentComponent();

    protected void click(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    protected void fillWithClear(WebElement element, String text) {
        click(element);
        element.clear();
        element.sendKeys(text);
    }

    protected void fill(WebElement element, String text) {
        click(element);
        element.sendKeys(text);
    }

    protected void waitVisibility(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public WebDriver getWebDriver() {
        return driver;
    }
}
