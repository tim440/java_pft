package ru.rgs.SeleniumTests;

import org.testng.annotations.Test;

/**
 * Created by Алексей on 31.08.2016.
 */
public class CreatingAgentReportTest extends TestBaseSelenium {

    @Test
    private void creatingAgentReport() {
        app.login("user");
        app.getUserHelper().acceptTosPage();
        app.getMainHelper().ensurePageLoaded()
                .createAgentReport("%%%%%%", "ИПКалинка")
                .selectAgent("344504520289");
    }
}
