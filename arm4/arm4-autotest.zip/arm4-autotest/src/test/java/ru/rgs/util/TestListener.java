package ru.rgs.util;

import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import ru.rgs.logic.ApplicationManager;
import ru.yandex.qatools.allure.annotations.Attachment;

public class TestListener implements ITestListener {

    private ApplicationManager app;

    @Override
    public void onFinish(ITestContext arg0) {

    }

    @Override
    public void onStart(ITestContext arg0) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        app = (ApplicationManager) result.getTestContext().getAttribute("app");
        saveScreenshot(app.takeScreenshot());
        saveCookies("Cookies");
        saveUrl("Url");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        app = (ApplicationManager) result.getTestContext().getAttribute("app");
        saveScreenshot(app.takeScreenshot());
        saveCookies("Cookies");
        saveUrl("Url");
    }

    @Attachment(value = "Page screenshot", type = "image/png")
    public byte[] saveScreenshot(byte[] screenShot) {
        return screenShot;
    }

    @Attachment(value = "{0}", type = "text/plain")
    public Set<Cookie> saveCookies(String attachName) {
        return app.getCookies();
    }

    @Attachment(value = "{0}", type = "text/plain")
    public String saveUrl(String attachName) {
        return app.getUrl();
    }

    @Override
    public void onTestSkipped(ITestResult arg0) {

    }

    @Override
    public void onTestStart(ITestResult arg0) {

    }

    @Override
    public void onTestSuccess(ITestResult arg0) {

    }
}
