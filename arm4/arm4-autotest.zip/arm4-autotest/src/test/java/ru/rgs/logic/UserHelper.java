package ru.rgs.logic;

import ru.rgs.model.User;
import ru.rgs.util.EnvironmentInfo;

/**
 * Created by Алексей on 03.09.2016.
 */
public class UserHelper extends DriverBasedHelper {

    public UserHelper(ApplicationManager manager) {
        super(manager.getWebDriver());
    }

    // Логинимся
    public UserHelper loginAs(User user) {
        if (isNotLoggedIn()) {
            pages.loginPage.setLogin(user.getLogin())
                    .setPassword(user.getPassword())
                    .clickSubmitBtn();
        }
        return this;
    }

    public UserHelper acceptTosPage() {
        pages.tosPage.waitForVisibleWindowTos().clickAcceptBtn();
        return this;
    }

    // Проверяем, что User залогинен и делаем logout
    public void logout() {
        if (isLoggedIn()) {
            pages.anyPage.clickLogoutButton();
        }
    }

    // тут будет проверка, что пользователь залогинен (скорее всего доступность кнопки выхода)
    public boolean isLoggedIn() {
        return true;
    }

    // тут будет проверка, что пользователь залогинен как определенный пользователь (если нужна будет такая проверка)
    public boolean isLoggedInAs(User user) {
        return true;
    }

    // тут будет проверка, что пользователь незалогинен и находится на странице логина
    public boolean isNotLoggedIn() {
        return true;
    }
}
