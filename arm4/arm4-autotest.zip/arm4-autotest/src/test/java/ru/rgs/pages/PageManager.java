package ru.rgs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by Алексей on 03.09.2016.
 */
public class PageManager {

    private WebDriver driver;

    public LoginPage loginPage;
    public AgentReportPage agentReportPage;
    public TosPage tosPage;
    public AnyPage anyPage;
    public MainPage mainPage;

    public PageManager(WebDriver driver) {
        this.driver = driver;
        loginPage = initElements(new LoginPage(this));
        agentReportPage = initElements(new AgentReportPage(this));
        tosPage = initElements(new TosPage(this));
        anyPage = initElements(new AnyPage(this));
        mainPage = initElements(new MainPage(this));
    }

    private <T extends Page> T initElements(T page) {
        PageFactory.initElements(driver, page);
        return page;
    }

    public WebDriver getWebDriver() {
        return driver;
    }
}