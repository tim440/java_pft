package ru.rgs.APITests;

import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import ru.rgs.logic.ApplicationManager;
import ru.stqa.selenium.factory.WebDriverFactory;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

/**
 * Базовый класс для API тестов
 */
public class TestBaseAPI {

    protected WebDriver driver;
    private ApplicationManager app;
    protected BasicCookieStore cookieStore = new BasicCookieStore();

    static boolean cookiesSaved = false;

    @BeforeSuite
    public void initTestSuite() throws IOException {
        app = new ApplicationManager();
        app.login("user");
        app.getUserHelper().acceptTosPage();
        if (!cookiesSaved) {
            initCookies();
            cookiesSaved = true;
        }
        WebDriverFactory.dismissAll();
    }

    protected void initCookies() {
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date date = calendar.getTime();
        Map<String, String> hashmap = new HashMap<String, String>();
        WebDriver seleniumDriver = driver;
        Set<Cookie> cookies = seleniumDriver.manage().getCookies();
        for (Cookie cookie : cookies) {
            hashmap.put(cookie.getName(), cookie.getValue());
        }
        BasicClientCookie cookieSession = new BasicClientCookie("JSESSIONID", hashmap.get("JSESSIONID"));
        cookieSession.setDomain("");
        cookieSession.setPath("/");
        cookieSession.setExpiryDate(date);
        cookieStore.addCookie(cookieSession);
        System.out.println(cookieSession);
    }

    protected CloseableHttpClient initHttpClient() {
        return HttpClients.custom()
                .setDefaultCookieStore(cookieStore).build();
    }

    protected HttpUriRequest getRequest(String apiURL) throws URISyntaxException {
        return RequestBuilder.get()
                .setUri(new URI(apiURL))
                .build();
    }
}