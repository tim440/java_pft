package ru.rgs.logic;

import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * MainHelper взаимодействует с элементами главной страницы
 * Элементами главной страницы являются все элементы, расположенные на главной странице
 * + элементы, которые не тебуют открытия вкладки
 * Новая вкладка = новая страница = новый хелпер
 */
public class MainHelper extends DriverBasedHelper {

    private ApplicationManager manager;

    public MainHelper(ApplicationManager manager) {
        super(manager.getWebDriver());
    }

    public MainHelper ensurePageLoaded() {
        wait.until(ExpectedConditions.visibilityOf(pages.mainPage.getWorkDaysBlock()));
        return this;
    }

    public MainHelper createAgentReport(String code, String name) {
        pages.mainPage.clickCrateAgentReportButton();
        getComponents().listFormSelectionAgent.setCodeField(code)
                .setAgentNameField(name)
                .clickAcceptFiltersButton();
        return this;
    }

    public MainHelper selectAgent(String code) {
        getComponents().listFormSelectionAgent.clickAgent(code)
                .clickAcceptSelect();
        return this;
    }
}
