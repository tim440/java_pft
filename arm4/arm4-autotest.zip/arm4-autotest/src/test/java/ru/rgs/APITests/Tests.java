package ru.rgs.APITests;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.*;

/**
 * API тест
 */
public class Tests extends TestBaseAPI {

    @Test
    public void query() throws URISyntaxException, IOException {
        String apiURL = "URL query";
        System.out.println(apiURL);

        getRequest(apiURL);
        CloseableHttpResponse response = initHttpClient().execute(getRequest(apiURL));
        try {
            String json = IOUtils.toString(response.getEntity().getContent());
            ObjectMapper objectMapper = new ObjectMapper();
            Map map = objectMapper.readValue(json, Map.class);
        } finally {
            response.close();
        }
    }

}
