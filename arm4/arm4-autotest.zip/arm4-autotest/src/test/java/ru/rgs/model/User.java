package ru.rgs.model;

/**
 * Created by Алексей on 03.09.2016.
 */
public class User {

    private final String role;
    private final String login;
    private final String password;

    public User(String role, String login, String password) {
        this.role = role;
        this.login = login;
        this.password = password;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    @Override
    public String toString() {
        return "User{" +
                "role='" + role + '\'' +
                ", login='" + login + '\'' +
                ", pass='" + password + '\'' +
                '}';
    }
}
