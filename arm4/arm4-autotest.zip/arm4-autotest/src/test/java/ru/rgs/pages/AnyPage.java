package ru.rgs.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Алексей on 03.09.2016.
 */
public class AnyPage extends Page {

    public AnyPage(PageManager pages) {
        super(pages);
    }

    @FindBy(css = "#_header_logout")
    private WebElement buttonLogout;

    public AnyPage clickLogoutButton() {
        click(buttonLogout);
        return this;
    }
}
