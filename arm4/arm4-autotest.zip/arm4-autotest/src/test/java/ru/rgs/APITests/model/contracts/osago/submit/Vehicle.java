package ru.rgs.APITests.model.contracts.osago.submit;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Vehicle{

	@Override
 	public String toString(){
		return 
			"Vehicle{" + 
			"}";
		}
}