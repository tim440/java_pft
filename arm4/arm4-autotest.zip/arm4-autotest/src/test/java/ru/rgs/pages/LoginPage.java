package ru.rgs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Алексей on 31.08.2016.
 */
public class LoginPage extends AnyPage {

    public LoginPage(PageManager pages) {
        super(pages);
    }

    @FindBy(css = "#usernameField-inputEl")
    private WebElement fieldLogin;

    @FindBy(css = "#passwordField-inputEl")
    private WebElement fieldPassword;

    @FindBy(css = ".x-btn-button")
    private WebElement buttonSubmit;

    public LoginPage setLogin(String login) {
        fill(fieldLogin, login);
        return this;
    }

    public LoginPage setPassword(String pass) {
        fill(fieldPassword, pass);
        return this;
    }

    public LoginPage clickSubmitBtn() {
        click(buttonSubmit);
        return this;
    }
}
