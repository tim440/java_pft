package ru.rgs.util;

import org.apache.commons.io.IOUtils;
import org.apache.http.impl.client.BasicCookieStore;
import ru.rgs.model.User;

import java.io.IOException;
import java.util.*;

/**
 * Author: Sergey Saiyan, sergey.sova42@gmail.com
 * Created on 30.11.15.
 */
public class EnvironmentInfo {

    private static EnvironmentInfo INSTANCE;

    private final Map<String, User> userByRole = new HashMap<String, User>();

    private BasicCookieStore cookieStore = new BasicCookieStore();

    private EnvironmentInfo() throws IOException {
        for (User user : readUser("test3")) {
            userByRole.put(user.getRole(), user);
        }
    }

    public static synchronized EnvironmentInfo instance() {
        if (INSTANCE == null) {
            try {
                INSTANCE = new EnvironmentInfo();
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }
        return INSTANCE;
    }

    public User getUser(String role) {
        return userByRole.get(role);
    }

    private List<User> readUser(String platform) throws IOException {
        String file = "/auth/" + platform + ".properties";
        List<String> lines = IOUtils.readLines(getClass().getResourceAsStream(file));

        if (lines.isEmpty()) {
            return Collections.emptyList();
        }

        List<User> users = new ArrayList<User>();
        for (int i = 0; i < lines.size() / 2; i++) {
            String line1 = lines.get(i * 2);
            String line2 = lines.get(i * 2 + 1);

            String role = line1.split("=")[0].split("\\.")[0];
            String email = line1.split("=")[1];
            String pass = line2.split("=")[1];

            users.add(new User(role, email, pass));
        }
        return users;
    }

    public BasicCookieStore getCookieStore() {
        return cookieStore;
    }
}

