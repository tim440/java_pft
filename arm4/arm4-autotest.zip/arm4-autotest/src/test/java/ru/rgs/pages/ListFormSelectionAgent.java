package ru.rgs.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Пробный пример Component object
 */
public class ListFormSelectionAgent extends Component {
    public ListFormSelectionAgent(ComponentManager components) {
        super(components);
    }

    /**
     * Основной (родительский) элемент, от которого строятся все остальные элементы,
     * относящиеся к данному компоненту (или данной компоненте, не знаю как правильнее на языке программистов :) )
     */
    @Override
    protected WebElement parentComponent() {
        return driver.findElement(By.cssSelector("body > div[id*='ext-comp-']"));
    }

    private WebElement codeField = getComponent(By.cssSelector("div[id^=gridcolumn]:nth-of-type(1) input[id^=textfield]"));

    private WebElement codeSKKField = getComponent(By.cssSelector("div[id^=gridcolumn]:nth-of-type(2) input[id^=textfield]"));

    private WebElement agentNameField = getComponent(By.cssSelector("div[id^=gridcolumn]:nth-of-type(3) input[id^=textfield]"));

    private WebElement acceptFiltersButton = getComponent(By.xpath(".//span[text()='Применить фильтр']/following-sibling::span"));

    private WebElement acceptSelect = getComponent(By.xpath(".//span[text()='Выбрать']/following-sibling::span"));

    private WebElement getComponent(By selector){
        return parentComponent().findElement(selector);
    }

    private WebElement getComponentByText(By selector){
        return parentComponent().findElement(selector);
    }

    public ListFormSelectionAgent setCodeField(String code) {
        fill(codeField, code);
        return this;
    }

    public ListFormSelectionAgent setCodeSKKField(String codeSKK) {
        fill(codeSKKField, codeSKK);
        return this;
    }

    public ListFormSelectionAgent setAgentNameField(String name) {
        fill(agentNameField, name);
        return this;
    }

    public ListFormSelectionAgent clickAcceptFiltersButton() {
        click(acceptFiltersButton);
        return this;
    }

    public ListFormSelectionAgent clickAgent(String code) {
        WebElement element = getComponent(By.xpath(".//div[text()='" + code + "']"));
        waitVisibility(element);
        click(element);
        return this;
    }

    public ListFormSelectionAgent clickAcceptSelect() {
        click(acceptSelect);
        return this;
    }
}
