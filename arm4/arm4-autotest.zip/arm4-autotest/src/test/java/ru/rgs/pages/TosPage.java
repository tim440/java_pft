package ru.rgs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Алексей on 31.08.2016.
 */
public class TosPage extends AnyPage {

    public TosPage(PageManager pages) {
        super(pages);
    }

    @FindBy(css = "#window-1012")
    private WebElement windowTos;

    @FindBy(css = "#acceptBtn-btnIconEl")
    private WebElement btnAccept;

    @FindBy(css = "#declineBtn-btnIconEl")
    private WebElement btnDecline;

    public TosPage waitForVisibleWindowTos() {
        waitVisibility(windowTos);
        return this;
    }

    public TosPage clickAcceptBtn() {
        click(btnAccept);
        return this;
    }

    public TosPage clickDeclineBtn() {
        click(btnDecline);
        return this;
    }
}
