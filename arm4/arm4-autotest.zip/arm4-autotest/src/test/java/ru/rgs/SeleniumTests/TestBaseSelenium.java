package ru.rgs.SeleniumTests;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Cookie;
import org.testng.ITestContext;
import org.testng.annotations.*;
import ru.rgs.logic.ApplicationManager;
import ru.rgs.util.TestListener;
import ru.stqa.selenium.factory.WebDriverFactory;

import java.io.IOException;
import java.util.Set;

/**
 * Базовый класс для всех тестов содержит в себе общие классы,
 * а также @BeforeSuite и родительский @BeforeClass, выполняемые перед всеми тестами и перед каждым классом
 * и @AfterSuite и @AfterClass, выполняемые после всех тестов и после каждого класса соответственно
 */

@Listeners(TestListener.class)
public class TestBaseSelenium {

    protected ApplicationManager app;

    /*
     * Инициализируем драйвер из общего, для всех видов тестов, менеджера
     * Передаем контекст в листенер
     */
    @BeforeClass
    public void initWebDriver(ITestContext context) throws IOException {
        app = new ApplicationManager();
        context.setAttribute("app", app);
    }

    @AfterClass
    public void tearDown() {
        WebDriverFactory.dismissDriver(app.getWebDriver());
    }

    @AfterSuite(alwaysRun = true)
    public void tearDownAll() {
        WebDriverFactory.dismissAll();
    }
}
