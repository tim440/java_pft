package ru.rgs.APITests.model.contracts.delete;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class DeletionResult{

	@Override
 	public String toString(){
		return 
			"DeletionResult{" + 
			"}";
		}
}