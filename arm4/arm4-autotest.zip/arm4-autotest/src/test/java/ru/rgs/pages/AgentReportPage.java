package ru.rgs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

/**
 * Created by Алексей on 31.08.2016.
 */
public class AgentReportPage extends AnyPage {

    public AgentReportPage(PageManager pages) {
        super(pages);
    }


}
