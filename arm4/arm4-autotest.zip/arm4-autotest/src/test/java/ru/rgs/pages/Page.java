package ru.rgs.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Abstract class representation of a FakePage in the UI. FakePage object pattern
 */
public abstract class Page {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected PageManager pages;

    public Page(PageManager pages) {
        this.pages = pages;
        driver = pages.getWebDriver();
        wait = new WebDriverWait(driver, 10);
    }

    public Page ensurePageLoaded() {
        return this;
    }


    protected void click(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    protected void fillWithClear(WebElement element, String text) {
        click(element);
        element.clear();
        element.sendKeys(text);
    }

    protected void fill(WebElement element, String text) {
        click(element);
        element.sendKeys(text);
    }

    protected void waitVisibility(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public WebDriver getWebDriver() {
        return driver;
    }
}
