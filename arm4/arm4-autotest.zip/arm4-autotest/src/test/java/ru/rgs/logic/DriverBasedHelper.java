package ru.rgs.logic;

import org.omg.CORBA.Object;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import ru.rgs.pages.ComponentManager;
import ru.rgs.pages.PageManager;
import ru.rgs.util.EnvironmentInfo;

/**
 * Родительский класс для хелперов
 */
public abstract class DriverBasedHelper {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected PageManager pages;
    protected ComponentManager components;

    public DriverBasedHelper(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
        pages = new PageManager(driver);
    }

    public ComponentManager getComponents(){
        components = new ComponentManager(driver);
        return components;
    }
}
