package ru.rgs.util;

import ru.rgs.model.User;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by Daria on 27.09.2015.
 */
public class PropertyHelper {

    private final Properties defaultProperties;
    private final Properties properties;

    public PropertyHelper(String propertyFileName) {
        defaultProperties = loadProperties("application.properties");
        properties = loadProperties(propertyFileName + ".properties");
    }

    private Properties loadProperties(String propertyFile) {
        Properties properties = new Properties();

        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propertyFile);
        if (inputStream == null) {
            System.err.println("PROPERTIES FILE [" + propertyFile + "] NOT FOUND");
        } else {
            try {
                properties.load(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return properties;
    }

    public String get(String propertyName) {
        String result = properties.getProperty(propertyName);

        return result != null ? result : defaultProperties.getProperty(propertyName);
    }
}
