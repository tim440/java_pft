package ru.rgs.APITests.model.SearchVehicle.full;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class PersonRole{

	@Override
 	public String toString(){
		return 
			"PersonRole{" + 
			"}";
		}
}