package ru.rgs.APITests.model.contracts.osago.create;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class BlankDto{

	@Override
 	public String toString(){
		return 
			"BlankDto{" + 
			"}";
		}
}