package ru.rgs.APITests.model.AgentStatement.Delete;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class DeletionResult{

  @Override
  public String toString(){
    return
            "DeletionResult{" +
                    "}";
  }
}