package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PremiumRate {

  @SerializedName("rateForOne")
  private int rateForOne;

  public void setRateForOne(int rateForOne) {
    this.rateForOne = rateForOne;
  }

  public int getRateForOne() {
    return rateForOne;
  }

  @Override
  public String toString() {
    return
            "PremiumRate{" +
                    "rateForOne = '" + rateForOne + '\'' +
                    "}";
  }
}