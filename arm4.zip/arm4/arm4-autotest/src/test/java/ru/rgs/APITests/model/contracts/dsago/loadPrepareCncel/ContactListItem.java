package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ContactListItem {

  @SerializedName("versionEndDate")
  private String versionEndDate;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("contactType")
  private ContactType contactType;

  @SerializedName("isIdPregenerated")
  private String isIdPregenerated;

  @SerializedName("abonentName")
  private String abonentName;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("contactLine")
  private String contactLine;

  @SerializedName("versionStartDate")
  private String versionStartDate;

  @SerializedName("entityChangeId")
  private String entityChangeId;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("sysUser")
  private String sysUser;

  @SerializedName("sysCreator")
  private String sysCreator;

  @SerializedName("id")
  private String id;

  public void setVersionEndDate(String versionEndDate) {
    this.versionEndDate = versionEndDate;
  }

  public String getVersionEndDate() {
    return versionEndDate;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setContactType(ContactType contactType) {
    this.contactType = contactType;
  }

  public ContactType getContactType() {
    return contactType;
  }

  public void setIsIdPregenerated(String isIdPregenerated) {
    this.isIdPregenerated = isIdPregenerated;
  }

  public String getIsIdPregenerated() {
    return isIdPregenerated;
  }

  public void setAbonentName(String abonentName) {
    this.abonentName = abonentName;
  }

  public String getAbonentName() {
    return abonentName;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setContactLine(String contactLine) {
    this.contactLine = contactLine;
  }

  public String getContactLine() {
    return contactLine;
  }

  public void setVersionStartDate(String versionStartDate) {
    this.versionStartDate = versionStartDate;
  }

  public String getVersionStartDate() {
    return versionStartDate;
  }

  public void setEntityChangeId(String entityChangeId) {
    this.entityChangeId = entityChangeId;
  }

  public String getEntityChangeId() {
    return entityChangeId;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setSysUser(String sysUser) {
    this.sysUser = sysUser;
  }

  public String getSysUser() {
    return sysUser;
  }

  public void setSysCreator(String sysCreator) {
    this.sysCreator = sysCreator;
  }

  public String getSysCreator() {
    return sysCreator;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  @Override
  public String toString() {
    return
            "ContactListItem{" +
                    "versionEndDate = '" + versionEndDate + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",contactType = '" + contactType + '\'' +
                    ",isIdPregenerated = '" + isIdPregenerated + '\'' +
                    ",abonentName = '" + abonentName + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",contactLine = '" + contactLine + '\'' +
                    ",versionStartDate = '" + versionStartDate + '\'' +
                    ",entityChangeId = '" + entityChangeId + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",sysUser = '" + sysUser + '\'' +
                    ",sysCreator = '" + sysCreator + '\'' +
                    ",id = '" + id + '\'' +
                    "}";
  }
}