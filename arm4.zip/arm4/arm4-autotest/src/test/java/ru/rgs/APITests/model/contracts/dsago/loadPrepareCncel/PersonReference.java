package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PersonReference {

  @SerializedName("displayName")
  private String displayName;

  @SerializedName("id")
  private String id;

  @SerializedName("subjectType")
  private SubjectType subjectType;

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setSubjectType(SubjectType subjectType) {
    this.subjectType = subjectType;
  }

  public SubjectType getSubjectType() {
    return subjectType;
  }

  @Override
  public String toString() {
    return
            "PersonReference{" +
                    "displayName = '" + displayName + '\'' +
                    ",id = '" + id + '\'' +
                    ",subjectType = '" + subjectType + '\'' +
                    "}";
  }
}