package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class PaymentListItem {

  @SerializedName("currencyType")
  private CurrencyType currencyType;

  @SerializedName("isPayGovernment")
  private String isPayGovernment;

  @SerializedName("paymentAgentStatement")
  private PaymentAgentStatement paymentAgentStatement;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("mainAgentId")
  private String mainAgentId;

  @SerializedName("currencyExchangeRate")
  private String currencyExchangeRate;

  @SerializedName("commissionSumRur")
  private String commissionSumRur;

  @SerializedName("commissionList")
  private List<CommissionListItem> commissionList;

  @SerializedName("paymentType")
  private PaymentType paymentType;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("id")
  private String id;

  @SerializedName("exchangeDifference")
  private String exchangeDifference;

  @SerializedName("paymentDocument")
  private PaymentDocument paymentDocument;

  @SerializedName("epsDate")
  private String epsDate;

  @SerializedName("mainAgentCommission")
  private String mainAgentCommission;

  @SerializedName("mainAgentCode")
  private String mainAgentCode;

  @SerializedName("isActivateAgentRoles")
  private String isActivateAgentRoles;

  @SerializedName("isActivateAgentFromAnotherBranch")
  private String isActivateAgentFromAnotherBranch;

  @SerializedName("sumDifference")
  private String sumDifference;

  @SerializedName("paymentCurrencySum")
  private String paymentCurrencySum;

  @SerializedName("paymentDocNumber")
  private String paymentDocNumber;

  @SerializedName("blankDto")
  private BlankDto blankDto;

  @SerializedName("paymentSumRur")
  private String paymentSumRur;

  @SerializedName("mainAgentName")
  private String mainAgentName;

  @SerializedName("bid")
  private String bid;

  @SerializedName("paymentDate")
  private String paymentDate;

  @SerializedName("agentContractId")
  private String agentContractId;

  public void setCurrencyType(CurrencyType currencyType) {
    this.currencyType = currencyType;
  }

  public CurrencyType getCurrencyType() {
    return currencyType;
  }

  public void setIsPayGovernment(String isPayGovernment) {
    this.isPayGovernment = isPayGovernment;
  }

  public String getIsPayGovernment() {
    return isPayGovernment;
  }

  public void setPaymentAgentStatement(PaymentAgentStatement paymentAgentStatement) {
    this.paymentAgentStatement = paymentAgentStatement;
  }

  public PaymentAgentStatement getPaymentAgentStatement() {
    return paymentAgentStatement;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setMainAgentId(String mainAgentId) {
    this.mainAgentId = mainAgentId;
  }

  public String getMainAgentId() {
    return mainAgentId;
  }

  public void setCurrencyExchangeRate(String currencyExchangeRate) {
    this.currencyExchangeRate = currencyExchangeRate;
  }

  public String getCurrencyExchangeRate() {
    return currencyExchangeRate;
  }

  public void setCommissionSumRur(String commissionSumRur) {
    this.commissionSumRur = commissionSumRur;
  }

  public String getCommissionSumRur() {
    return commissionSumRur;
  }

  public void setCommissionList(List<CommissionListItem> commissionList) {
    this.commissionList = commissionList;
  }

  public List<CommissionListItem> getCommissionList() {
    return commissionList;
  }

  public void setPaymentType(PaymentType paymentType) {
    this.paymentType = paymentType;
  }

  public PaymentType getPaymentType() {
    return paymentType;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setExchangeDifference(String exchangeDifference) {
    this.exchangeDifference = exchangeDifference;
  }

  public String getExchangeDifference() {
    return exchangeDifference;
  }

  public void setPaymentDocument(PaymentDocument paymentDocument) {
    this.paymentDocument = paymentDocument;
  }

  public PaymentDocument getPaymentDocument() {
    return paymentDocument;
  }

  public void setEpsDate(String epsDate) {
    this.epsDate = epsDate;
  }

  public String getEpsDate() {
    return epsDate;
  }

  public void setMainAgentCommission(String mainAgentCommission) {
    this.mainAgentCommission = mainAgentCommission;
  }

  public String getMainAgentCommission() {
    return mainAgentCommission;
  }

  public void setMainAgentCode(String mainAgentCode) {
    this.mainAgentCode = mainAgentCode;
  }

  public String getMainAgentCode() {
    return mainAgentCode;
  }

  public void setIsActivateAgentRoles(String isActivateAgentRoles) {
    this.isActivateAgentRoles = isActivateAgentRoles;
  }

  public String getIsActivateAgentRoles() {
    return isActivateAgentRoles;
  }

  public void setIsActivateAgentFromAnotherBranch(String isActivateAgentFromAnotherBranch) {
    this.isActivateAgentFromAnotherBranch = isActivateAgentFromAnotherBranch;
  }

  public String getIsActivateAgentFromAnotherBranch() {
    return isActivateAgentFromAnotherBranch;
  }

  public void setSumDifference(String sumDifference) {
    this.sumDifference = sumDifference;
  }

  public String getSumDifference() {
    return sumDifference;
  }

  public void setPaymentCurrencySum(String paymentCurrencySum) {
    this.paymentCurrencySum = paymentCurrencySum;
  }

  public String getPaymentCurrencySum() {
    return paymentCurrencySum;
  }

  public void setPaymentDocNumber(String paymentDocNumber) {
    this.paymentDocNumber = paymentDocNumber;
  }

  public String getPaymentDocNumber() {
    return paymentDocNumber;
  }

  public void setBlankDto(BlankDto blankDto) {
    this.blankDto = blankDto;
  }

  public BlankDto getBlankDto() {
    return blankDto;
  }

  public void setPaymentSumRur(String paymentSumRur) {
    this.paymentSumRur = paymentSumRur;
  }

  public String getPaymentSumRur() {
    return paymentSumRur;
  }

  public void setMainAgentName(String mainAgentName) {
    this.mainAgentName = mainAgentName;
  }

  public String getMainAgentName() {
    return mainAgentName;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setPaymentDate(String paymentDate) {
    this.paymentDate = paymentDate;
  }

  public String getPaymentDate() {
    return paymentDate;
  }

  public void setAgentContractId(String agentContractId) {
    this.agentContractId = agentContractId;
  }

  public String getAgentContractId() {
    return agentContractId;
  }

  @Override
  public String toString() {
    return
            "PaymentListItem{" +
                    "currencyType = '" + currencyType + '\'' +
                    ",isPayGovernment = '" + isPayGovernment + '\'' +
                    ",paymentAgentStatement = '" + paymentAgentStatement + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",mainAgentId = '" + mainAgentId + '\'' +
                    ",currencyExchangeRate = '" + currencyExchangeRate + '\'' +
                    ",commissionSumRur = '" + commissionSumRur + '\'' +
                    ",commissionList = '" + commissionList + '\'' +
                    ",paymentType = '" + paymentType + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",id = '" + id + '\'' +
                    ",exchangeDifference = '" + exchangeDifference + '\'' +
                    ",paymentDocument = '" + paymentDocument + '\'' +
                    ",epsDate = '" + epsDate + '\'' +
                    ",mainAgentCommission = '" + mainAgentCommission + '\'' +
                    ",mainAgentCode = '" + mainAgentCode + '\'' +
                    ",isActivateAgentRoles = '" + isActivateAgentRoles + '\'' +
                    ",isActivateAgentFromAnotherBranch = '" + isActivateAgentFromAnotherBranch + '\'' +
                    ",sumDifference = '" + sumDifference + '\'' +
                    ",paymentCurrencySum = '" + paymentCurrencySum + '\'' +
                    ",paymentDocNumber = '" + paymentDocNumber + '\'' +
                    ",blankDto = '" + blankDto + '\'' +
                    ",paymentSumRur = '" + paymentSumRur + '\'' +
                    ",mainAgentName = '" + mainAgentName + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",paymentDate = '" + paymentDate + '\'' +
                    ",agentContractId = '" + agentContractId + '\'' +
                    "}";
  }
}