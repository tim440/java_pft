package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class CreateObject {

  @SerializedName("contractType")
  private ContractType contractType;

  @SerializedName("premiumRate")
  private PremiumRate premiumRate;

  @SerializedName("branch")
  private Branch branch;

  @SerializedName("liabilityTypeList")
  private List<LiabilityTypeListItem> liabilityTypeList;

  @SerializedName("validationLogList")
  private List<ValidationLogListItem> validationLogList;

  @SerializedName("number")
  private String number;

  @SerializedName("currentContractChange")
  private CurrentContractChange currentContractChange;

  @SerializedName("paymentScheduleType")
  private PaymentScheduleType paymentScheduleType;

  @SerializedName("isCurrencyEquivalent")
  private String isCurrencyEquivalent;

  @SerializedName("id")
  private String id;

  @SerializedName("isReceivedPrimaryDoc")
  private String isReceivedPrimaryDoc;

  @SerializedName("privilegedProlongation")
  private String privilegedProlongation;

  @SerializedName("beneficiarList")
  private List<BeneficiarListItem> beneficiarList;

  @SerializedName("premiumChargeType")
  private PremiumChargeType premiumChargeType;

  @SerializedName("insurerPersonTypeCode")
  private String insurerPersonTypeCode;

  @SerializedName("creationType")
  private CreationType creationType;

  @SerializedName("vehicleCount")
  private String vehicleCount;

  @SerializedName("saleChannel")
  private SaleChannel saleChannel;

  @SerializedName("productList")
  private List<ProductListItem> productList;

  @SerializedName("status")
  private Status status;

  @SerializedName("noBlank")
  private String noBlank;

  @SerializedName("debitWriteOffReasonList")
  private List<DebitWriteOffReasonListItem> debitWriteOffReasonList;

  @SerializedName("isCoInsurance")
  private String isCoInsurance;

  @SerializedName("agentStatementNumber")
  private String agentStatementNumber;

  @SerializedName("isFranchiseInsteadCoeff")
  private String isFranchiseInsteadCoeff;

  @SerializedName("premium")
  private String premium;

  @SerializedName("insurer")
  private Insurer insurer;

  @SerializedName("liabilityEndDate")
  private String liabilityEndDate;

  @SerializedName("currency")
  private Currency currency;

  @SerializedName("useNewCascoDate")
  private String useNewCascoDate;

  @SerializedName("cancelReason")
  private CancelReason cancelReason;

  @SerializedName("product")
  private Product product;

  @SerializedName("isStateProcurement")
  private String isStateProcurement;

  @SerializedName("insurerId")
  private String insurerId;

  @SerializedName("agentStatementId")
  private String agentStatementId;

  @SerializedName("agentStatementDate")
  private String agentStatementDate;

  @SerializedName("series")
  private String series;

  @SerializedName("insBridgeActivationDate")
  private String insBridgeActivationDate;

  @SerializedName("coInsuranceTotalPremium")
  private String coInsuranceTotalPremium;

  @SerializedName("groupChoiceRuleList")
  private List<GroupChoiceRuleListItem> groupChoiceRuleList;

  @SerializedName("paymentScheduleList")
  private List<PaymentScheduleListItem> paymentScheduleList;

  @SerializedName("payedSum")
  private String payedSum;

  @SerializedName("isQuoteApproved")
  private String isQuoteApproved;

  @SerializedName("contractDate")
  private String contractDate;

  @SerializedName("contractChangeList")
  private List<ContractChangeListItem> contractChangeList;

  @SerializedName("coInsuranceStartDate")
  private String coInsuranceStartDate;

  @SerializedName("office")
  private Office office;

  @SerializedName("prevContractPayedSum")
  private String prevContractPayedSum;

  @SerializedName("insuranceActNumber")
  private String insuranceActNumber;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("contractTypeClassList")
  private List<ContractTypeClassListItem> contractTypeClassList;

  @SerializedName("reissueDate")
  private String reissueDate;

  @SerializedName("sysCreator")
  private String sysCreator;

  @SerializedName("contractTypeClass")
  private ContractTypeClass contractTypeClass;

  @SerializedName("statementStatusCode")
  private String statementStatusCode;

  @SerializedName("contractStartDate")
  private String contractStartDate;

  @SerializedName("insurerSysEditor")
  private String insurerSysEditor;

  @SerializedName("isActivateAgentFromAnotherBranch")
  private String isActivateAgentFromAnotherBranch;

  @SerializedName("agentName")
  private String agentName;

  @SerializedName("insurerHasCellPhone")
  private String insurerHasCellPhone;

  @SerializedName("isReinsure")
  private String isReinsure;

  @SerializedName("productVariant")
  private ProductVariant productVariant;

  @SerializedName("isEmptySourceCheckSum")
  private String isEmptySourceCheckSum;

  @SerializedName("paymentMethod")
  private PaymentMethod paymentMethod;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("claimReturnSum")
  private String claimReturnSum;

  @SerializedName("agentId")
  private String agentId;

  @SerializedName("cancelDate")
  private String cancelDate;

  @SerializedName("existActiveAsyncRequest")
  private String existActiveAsyncRequest;

  @SerializedName("stateProcurementStartDate")
  private String stateProcurementStartDate;

  @SerializedName("previousPremium")
  private String previousPremium;

  @SerializedName("liabilityStartDate")
  private String liabilityStartDate;

  @SerializedName("liabilityType")
  private LiabilityType liabilityType;

  @SerializedName("factAccruedPremiumDateStartDate")
  private String factAccruedPremiumDateStartDate;

  @SerializedName("saleGroup")
  private SaleGroup saleGroup;

  @SerializedName("payerTypeList")
  private List<PayerTypeListItem> payerTypeList;

  @SerializedName("reinsureStartDate")
  private String reinsureStartDate;

  @SerializedName("insuredVehicleList")
  private List<InsuredVehicleListItem> insuredVehicleList;

  @SerializedName("department")
  private Department department;

  @SerializedName("paymentMethodList")
  private List<PaymentMethodListItem> paymentMethodList;

  @SerializedName("insurerChangeId")
  private String insurerChangeId;

  @SerializedName("quoteDate")
  private String quoteDate;

  @SerializedName("likardData")
  private LikardData likardData;

  @SerializedName("contractOption")
  private ContractOption contractOption;

  @SerializedName("exceedsTariff")
  private String exceedsTariff;

  @SerializedName("contractEndDate")
  private String contractEndDate;

  @SerializedName("cancelStatementDate")
  private String cancelStatementDate;

  @SerializedName("insurerName")
  private String insurerName;

  @SerializedName("contractTypeClassStartDate")
  private String contractTypeClassStartDate;

  @SerializedName("blankDto")
  private BlankDto blankDto;

  @SerializedName("premiumRur")
  private String premiumRur;

  @SerializedName("canPayWithoutDoc")
  private String canPayWithoutDoc;

  @SerializedName("paymentTypeList")
  private List<PaymentTypeListItem> paymentTypeList;

  @SerializedName("drivingLimitationTypeList")
  private List<DrivingLimitationTypeListItem> drivingLimitationTypeList;

  @SerializedName("entityPurpose")
  private String entityPurpose;

  @SerializedName("liabilitySum")
  private String liabilitySum;

  @SerializedName("isPledgedProperty")
  private String isPledgedProperty;

  @SerializedName("isProcessPersInfo")
  private String isProcessPersInfo;

  @SerializedName("isProcessPersInfoEmpty")
  private String isProcessPersInfoEmpty;

  public void setContractType(ContractType contractType) {
    this.contractType = contractType;
  }

  public ContractType getContractType() {
    return contractType;
  }

  public void setPremiumRate(PremiumRate premiumRate) {
    this.premiumRate = premiumRate;
  }

  public PremiumRate getPremiumRate() {
    return premiumRate;
  }

  public void setBranch(Branch branch) {
    this.branch = branch;
  }

  public Branch getBranch() {
    return branch;
  }

  public void setLiabilityTypeList(List<LiabilityTypeListItem> liabilityTypeList) {
    this.liabilityTypeList = liabilityTypeList;
  }

  public List<LiabilityTypeListItem> getLiabilityTypeList() {
    return liabilityTypeList;
  }

  public void setValidationLogList(List<ValidationLogListItem> validationLogList) {
    this.validationLogList = validationLogList;
  }

  public List<ValidationLogListItem> getValidationLogList() {
    return validationLogList;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getNumber() {
    return number;
  }

  public void setCurrentContractChange(CurrentContractChange currentContractChange) {
    this.currentContractChange = currentContractChange;
  }

  public CurrentContractChange getCurrentContractChange() {
    return currentContractChange;
  }

  public void setPaymentScheduleType(PaymentScheduleType paymentScheduleType) {
    this.paymentScheduleType = paymentScheduleType;
  }

  public PaymentScheduleType getPaymentScheduleType() {
    return paymentScheduleType;
  }

  public void setIsCurrencyEquivalent(String isCurrencyEquivalent) {
    this.isCurrencyEquivalent = isCurrencyEquivalent;
  }

  public String getIsCurrencyEquivalent() {
    return isCurrencyEquivalent;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setIsReceivedPrimaryDoc(String isReceivedPrimaryDoc) {
    this.isReceivedPrimaryDoc = isReceivedPrimaryDoc;
  }

  public String getIsReceivedPrimaryDoc() {
    return isReceivedPrimaryDoc;
  }

  public void setPrivilegedProlongation(String privilegedProlongation) {
    this.privilegedProlongation = privilegedProlongation;
  }

  public String getPrivilegedProlongation() {
    return privilegedProlongation;
  }

  public void setBeneficiarList(List<BeneficiarListItem> beneficiarList) {
    this.beneficiarList = beneficiarList;
  }

  public List<BeneficiarListItem> getBeneficiarList() {
    return beneficiarList;
  }

  public void setPremiumChargeType(PremiumChargeType premiumChargeType) {
    this.premiumChargeType = premiumChargeType;
  }

  public PremiumChargeType getPremiumChargeType() {
    return premiumChargeType;
  }

  public void setInsurerPersonTypeCode(String insurerPersonTypeCode) {
    this.insurerPersonTypeCode = insurerPersonTypeCode;
  }

  public String getInsurerPersonTypeCode() {
    return insurerPersonTypeCode;
  }

  public void setCreationType(CreationType creationType) {
    this.creationType = creationType;
  }

  public CreationType getCreationType() {
    return creationType;
  }

  public void setVehicleCount(String vehicleCount) {
    this.vehicleCount = vehicleCount;
  }

  public String getVehicleCount() {
    return vehicleCount;
  }

  public void setSaleChannel(SaleChannel saleChannel) {
    this.saleChannel = saleChannel;
  }

  public SaleChannel getSaleChannel() {
    return saleChannel;
  }

  public void setProductList(List<ProductListItem> productList) {
    this.productList = productList;
  }

  public List<ProductListItem> getProductList() {
    return productList;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public Status getStatus() {
    return status;
  }

  public void setNoBlank(String noBlank) {
    this.noBlank = noBlank;
  }

  public String getNoBlank() {
    return noBlank;
  }

  public void setDebitWriteOffReasonList(List<DebitWriteOffReasonListItem> debitWriteOffReasonList) {
    this.debitWriteOffReasonList = debitWriteOffReasonList;
  }

  public List<DebitWriteOffReasonListItem> getDebitWriteOffReasonList() {
    return debitWriteOffReasonList;
  }

  public void setIsCoInsurance(String isCoInsurance) {
    this.isCoInsurance = isCoInsurance;
  }

  public String getIsCoInsurance() {
    return isCoInsurance;
  }

  public void setAgentStatementNumber(String agentStatementNumber) {
    this.agentStatementNumber = agentStatementNumber;
  }

  public String getAgentStatementNumber() {
    return agentStatementNumber;
  }

  public void setIsFranchiseInsteadCoeff(String isFranchiseInsteadCoeff) {
    this.isFranchiseInsteadCoeff = isFranchiseInsteadCoeff;
  }

  public String getIsFranchiseInsteadCoeff() {
    return isFranchiseInsteadCoeff;
  }

  public void setPremium(String premium) {
    this.premium = premium;
  }

  public String getPremium() {
    return premium;
  }

  public void setInsurer(Insurer insurer) {
    this.insurer = insurer;
  }

  public Insurer getInsurer() {
    return insurer;
  }

  public void setLiabilityEndDate(String liabilityEndDate) {
    this.liabilityEndDate = liabilityEndDate;
  }

  public String getLiabilityEndDate() {
    return liabilityEndDate;
  }

  public void setCurrency(Currency currency) {
    this.currency = currency;
  }

  public Currency getCurrency() {
    return currency;
  }

  public void setUseNewCascoDate(String useNewCascoDate) {
    this.useNewCascoDate = useNewCascoDate;
  }

  public String getUseNewCascoDate() {
    return useNewCascoDate;
  }

  public void setCancelReason(CancelReason cancelReason) {
    this.cancelReason = cancelReason;
  }

  public CancelReason getCancelReason() {
    return cancelReason;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public Product getProduct() {
    return product;
  }

  public void setIsStateProcurement(String isStateProcurement) {
    this.isStateProcurement = isStateProcurement;
  }

  public String getIsStateProcurement() {
    return isStateProcurement;
  }

  public void setInsurerId(String insurerId) {
    this.insurerId = insurerId;
  }

  public String getInsurerId() {
    return insurerId;
  }

  public void setAgentStatementId(String agentStatementId) {
    this.agentStatementId = agentStatementId;
  }

  public String getAgentStatementId() {
    return agentStatementId;
  }

  public void setAgentStatementDate(String agentStatementDate) {
    this.agentStatementDate = agentStatementDate;
  }

  public String getAgentStatementDate() {
    return agentStatementDate;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public String getSeries() {
    return series;
  }

  public void setInsBridgeActivationDate(String insBridgeActivationDate) {
    this.insBridgeActivationDate = insBridgeActivationDate;
  }

  public String getInsBridgeActivationDate() {
    return insBridgeActivationDate;
  }

  public void setCoInsuranceTotalPremium(String coInsuranceTotalPremium) {
    this.coInsuranceTotalPremium = coInsuranceTotalPremium;
  }

  public String getCoInsuranceTotalPremium() {
    return coInsuranceTotalPremium;
  }

  public void setGroupChoiceRuleList(List<GroupChoiceRuleListItem> groupChoiceRuleList) {
    this.groupChoiceRuleList = groupChoiceRuleList;
  }

  public List<GroupChoiceRuleListItem> getGroupChoiceRuleList() {
    return groupChoiceRuleList;
  }

  public void setPaymentScheduleList(List<PaymentScheduleListItem> paymentScheduleList) {
    this.paymentScheduleList = paymentScheduleList;
  }

  public List<PaymentScheduleListItem> getPaymentScheduleList() {
    return paymentScheduleList;
  }

  public void setPayedSum(String payedSum) {
    this.payedSum = payedSum;
  }

  public String getPayedSum() {
    return payedSum;
  }

  public void setIsQuoteApproved(String isQuoteApproved) {
    this.isQuoteApproved = isQuoteApproved;
  }

  public String getIsQuoteApproved() {
    return isQuoteApproved;
  }

  public void setContractDate(String contractDate) {
    this.contractDate = contractDate;
  }

  public String getContractDate() {
    return contractDate;
  }

  public void setContractChangeList(List<ContractChangeListItem> contractChangeList) {
    this.contractChangeList = contractChangeList;
  }

  public List<ContractChangeListItem> getContractChangeList() {
    return contractChangeList;
  }

  public void setCoInsuranceStartDate(String coInsuranceStartDate) {
    this.coInsuranceStartDate = coInsuranceStartDate;
  }

  public String getCoInsuranceStartDate() {
    return coInsuranceStartDate;
  }

  public void setOffice(Office office) {
    this.office = office;
  }

  public Office getOffice() {
    return office;
  }

  public void setPrevContractPayedSum(String prevContractPayedSum) {
    this.prevContractPayedSum = prevContractPayedSum;
  }

  public String getPrevContractPayedSum() {
    return prevContractPayedSum;
  }

  public void setInsuranceActNumber(String insuranceActNumber) {
    this.insuranceActNumber = insuranceActNumber;
  }

  public String getInsuranceActNumber() {
    return insuranceActNumber;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setContractTypeClassList(List<ContractTypeClassListItem> contractTypeClassList) {
    this.contractTypeClassList = contractTypeClassList;
  }

  public List<ContractTypeClassListItem> getContractTypeClassList() {
    return contractTypeClassList;
  }

  public void setReissueDate(String reissueDate) {
    this.reissueDate = reissueDate;
  }

  public String getReissueDate() {
    return reissueDate;
  }

  public void setSysCreator(String sysCreator) {
    this.sysCreator = sysCreator;
  }

  public String getSysCreator() {
    return sysCreator;
  }

  public void setContractTypeClass(ContractTypeClass contractTypeClass) {
    this.contractTypeClass = contractTypeClass;
  }

  public ContractTypeClass getContractTypeClass() {
    return contractTypeClass;
  }

  public void setStatementStatusCode(String statementStatusCode) {
    this.statementStatusCode = statementStatusCode;
  }

  public String getStatementStatusCode() {
    return statementStatusCode;
  }

  public void setContractStartDate(String contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  public String getContractStartDate() {
    return contractStartDate;
  }

  public void setInsurerSysEditor(String insurerSysEditor) {
    this.insurerSysEditor = insurerSysEditor;
  }

  public String getInsurerSysEditor() {
    return insurerSysEditor;
  }

  public void setIsActivateAgentFromAnotherBranch(String isActivateAgentFromAnotherBranch) {
    this.isActivateAgentFromAnotherBranch = isActivateAgentFromAnotherBranch;
  }

  public String getIsActivateAgentFromAnotherBranch() {
    return isActivateAgentFromAnotherBranch;
  }

  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }

  public String getAgentName() {
    return agentName;
  }

  public void setInsurerHasCellPhone(String insurerHasCellPhone) {
    this.insurerHasCellPhone = insurerHasCellPhone;
  }

  public String getInsurerHasCellPhone() {
    return insurerHasCellPhone;
  }

  public void setIsReinsure(String isReinsure) {
    this.isReinsure = isReinsure;
  }

  public String getIsReinsure() {
    return isReinsure;
  }

  public void setProductVariant(ProductVariant productVariant) {
    this.productVariant = productVariant;
  }

  public ProductVariant getProductVariant() {
    return productVariant;
  }

  public void setIsEmptySourceCheckSum(String isEmptySourceCheckSum) {
    this.isEmptySourceCheckSum = isEmptySourceCheckSum;
  }

  public String getIsEmptySourceCheckSum() {
    return isEmptySourceCheckSum;
  }

  public void setPaymentMethod(PaymentMethod paymentMethod) {
    this.paymentMethod = paymentMethod;
  }

  public PaymentMethod getPaymentMethod() {
    return paymentMethod;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setClaimReturnSum(String claimReturnSum) {
    this.claimReturnSum = claimReturnSum;
  }

  public String getClaimReturnSum() {
    return claimReturnSum;
  }

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setCancelDate(String cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getCancelDate() {
    return cancelDate;
  }

  public void setExistActiveAsyncRequest(String existActiveAsyncRequest) {
    this.existActiveAsyncRequest = existActiveAsyncRequest;
  }

  public String getExistActiveAsyncRequest() {
    return existActiveAsyncRequest;
  }

  public void setStateProcurementStartDate(String stateProcurementStartDate) {
    this.stateProcurementStartDate = stateProcurementStartDate;
  }

  public String getStateProcurementStartDate() {
    return stateProcurementStartDate;
  }

  public void setPreviousPremium(String previousPremium) {
    this.previousPremium = previousPremium;
  }

  public String getPreviousPremium() {
    return previousPremium;
  }

  public void setLiabilityStartDate(String liabilityStartDate) {
    this.liabilityStartDate = liabilityStartDate;
  }

  public String getLiabilityStartDate() {
    return liabilityStartDate;
  }

  public void setLiabilityType(LiabilityType liabilityType) {
    this.liabilityType = liabilityType;
  }

  public LiabilityType getLiabilityType() {
    return liabilityType;
  }

  public void setFactAccruedPremiumDateStartDate(String factAccruedPremiumDateStartDate) {
    this.factAccruedPremiumDateStartDate = factAccruedPremiumDateStartDate;
  }

  public String getFactAccruedPremiumDateStartDate() {
    return factAccruedPremiumDateStartDate;
  }

  public void setSaleGroup(SaleGroup saleGroup) {
    this.saleGroup = saleGroup;
  }

  public SaleGroup getSaleGroup() {
    return saleGroup;
  }

  public void setPayerTypeList(List<PayerTypeListItem> payerTypeList) {
    this.payerTypeList = payerTypeList;
  }

  public List<PayerTypeListItem> getPayerTypeList() {
    return payerTypeList;
  }

  public void setReinsureStartDate(String reinsureStartDate) {
    this.reinsureStartDate = reinsureStartDate;
  }

  public String getReinsureStartDate() {
    return reinsureStartDate;
  }

  public void setInsuredVehicleList(List<InsuredVehicleListItem> insuredVehicleList) {
    this.insuredVehicleList = insuredVehicleList;
  }

  public List<InsuredVehicleListItem> getInsuredVehicleList() {
    return insuredVehicleList;
  }

  public void setDepartment(Department department) {
    this.department = department;
  }

  public Department getDepartment() {
    return department;
  }

  public void setPaymentMethodList(List<PaymentMethodListItem> paymentMethodList) {
    this.paymentMethodList = paymentMethodList;
  }

  public List<PaymentMethodListItem> getPaymentMethodList() {
    return paymentMethodList;
  }

  public void setInsurerChangeId(String insurerChangeId) {
    this.insurerChangeId = insurerChangeId;
  }

  public String getInsurerChangeId() {
    return insurerChangeId;
  }

  public void setQuoteDate(String quoteDate) {
    this.quoteDate = quoteDate;
  }

  public String getQuoteDate() {
    return quoteDate;
  }

  public void setLikardData(LikardData likardData) {
    this.likardData = likardData;
  }

  public LikardData getLikardData() {
    return likardData;
  }

  public void setContractOption(ContractOption contractOption) {
    this.contractOption = contractOption;
  }

  public ContractOption getContractOption() {
    return contractOption;
  }

  public void setExceedsTariff(String exceedsTariff) {
    this.exceedsTariff = exceedsTariff;
  }

  public String getExceedsTariff() {
    return exceedsTariff;
  }

  public void setContractEndDate(String contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  public String getContractEndDate() {
    return contractEndDate;
  }

  public void setCancelStatementDate(String cancelStatementDate) {
    this.cancelStatementDate = cancelStatementDate;
  }

  public String getCancelStatementDate() {
    return cancelStatementDate;
  }

  public void setInsurerName(String insurerName) {
    this.insurerName = insurerName;
  }

  public String getInsurerName() {
    return insurerName;
  }

  public void setContractTypeClassStartDate(String contractTypeClassStartDate) {
    this.contractTypeClassStartDate = contractTypeClassStartDate;
  }

  public String getContractTypeClassStartDate() {
    return contractTypeClassStartDate;
  }

  public void setBlankDto(BlankDto blankDto) {
    this.blankDto = blankDto;
  }

  public BlankDto getBlankDto() {
    return blankDto;
  }

  public void setPremiumRur(String premiumRur) {
    this.premiumRur = premiumRur;
  }

  public String getPremiumRur() {
    return premiumRur;
  }

  public void setCanPayWithoutDoc(String canPayWithoutDoc) {
    this.canPayWithoutDoc = canPayWithoutDoc;
  }

  public String getCanPayWithoutDoc() {
    return canPayWithoutDoc;
  }

  public void setPaymentTypeList(List<PaymentTypeListItem> paymentTypeList) {
    this.paymentTypeList = paymentTypeList;
  }

  public List<PaymentTypeListItem> getPaymentTypeList() {
    return paymentTypeList;
  }

  public void setDrivingLimitationTypeList(List<DrivingLimitationTypeListItem> drivingLimitationTypeList) {
    this.drivingLimitationTypeList = drivingLimitationTypeList;
  }

  public List<DrivingLimitationTypeListItem> getDrivingLimitationTypeList() {
    return drivingLimitationTypeList;
  }

  public void setEntityPurpose(String entityPurpose) {
    this.entityPurpose = entityPurpose;
  }

  public String getEntityPurpose() {
    return entityPurpose;
  }

  public void setLiabilitySum(String liabilitySum) {
    this.liabilitySum = liabilitySum;
  }

  public String getLiabilitySum() {
    return liabilitySum;
  }

  public void setIsPledgedProperty(String isPledgedProperty) {
    this.isPledgedProperty = isPledgedProperty;
  }

  public String getIsPledgedProperty() {
    return isPledgedProperty;
  }

  public void setIsProcessPersInfo(String isProcessPersInfo) {
    this.isProcessPersInfo = isProcessPersInfo;
  }

  public String getIsProcessPersInfo() {
    return isProcessPersInfo;
  }

  public void setIsProcessPersInfoEmpty(String isProcessPersInfoEmpty) {
    this.isProcessPersInfoEmpty = isProcessPersInfoEmpty;
  }

  public String getIsProcessPersInfoEmpty() {
    return isProcessPersInfoEmpty;
  }

  @Override
  public String toString() {
    return
            "CreateObject{" +
                    "contractType = '" + contractType + '\'' +
                    ",premiumRate = '" + premiumRate + '\'' +
                    ",branch = '" + branch + '\'' +
                    ",liabilityTypeList = '" + liabilityTypeList + '\'' +
                    ",validationLogList = '" + validationLogList + '\'' +
                    ",number = '" + number + '\'' +
                    ",currentContractChange = '" + currentContractChange + '\'' +
                    ",paymentScheduleType = '" + paymentScheduleType + '\'' +
                    ",isCurrencyEquivalent = '" + isCurrencyEquivalent + '\'' +
                    ",id = '" + id + '\'' +
                    ",isReceivedPrimaryDoc = '" + isReceivedPrimaryDoc + '\'' +
                    ",privilegedProlongation = '" + privilegedProlongation + '\'' +
                    ",beneficiarList = '" + beneficiarList + '\'' +
                    ",premiumChargeType = '" + premiumChargeType + '\'' +
                    ",insurerPersonTypeCode = '" + insurerPersonTypeCode + '\'' +
                    ",creationType = '" + creationType + '\'' +
                    ",vehicleCount = '" + vehicleCount + '\'' +
                    ",saleChannel = '" + saleChannel + '\'' +
                    ",productList = '" + productList + '\'' +
                    ",status = '" + status + '\'' +
                    ",noBlank = '" + noBlank + '\'' +
                    ",debitWriteOffReasonList = '" + debitWriteOffReasonList + '\'' +
                    ",isCoInsurance = '" + isCoInsurance + '\'' +
                    ",agentStatementNumber = '" + agentStatementNumber + '\'' +
                    ",isFranchiseInsteadCoeff = '" + isFranchiseInsteadCoeff + '\'' +
                    ",premium = '" + premium + '\'' +
                    ",insurer = '" + insurer + '\'' +
                    ",liabilityEndDate = '" + liabilityEndDate + '\'' +
                    ",currency = '" + currency + '\'' +
                    ",useNewCascoDate = '" + useNewCascoDate + '\'' +
                    ",cancelReason = '" + cancelReason + '\'' +
                    ",product = '" + product + '\'' +
                    ",isStateProcurement = '" + isStateProcurement + '\'' +
                    ",insurerId = '" + insurerId + '\'' +
                    ",agentStatementId = '" + agentStatementId + '\'' +
                    ",agentStatementDate = '" + agentStatementDate + '\'' +
                    ",series = '" + series + '\'' +
                    ",insBridgeActivationDate = '" + insBridgeActivationDate + '\'' +
                    ",coInsuranceTotalPremium = '" + coInsuranceTotalPremium + '\'' +
                    ",groupChoiceRuleList = '" + groupChoiceRuleList + '\'' +
                    ",paymentScheduleList = '" + paymentScheduleList + '\'' +
                    ",payedSum = '" + payedSum + '\'' +
                    ",isQuoteApproved = '" + isQuoteApproved + '\'' +
                    ",contractDate = '" + contractDate + '\'' +
                    ",contractChangeList = '" + contractChangeList + '\'' +
                    ",coInsuranceStartDate = '" + coInsuranceStartDate + '\'' +
                    ",office = '" + office + '\'' +
                    ",prevContractPayedSum = '" + prevContractPayedSum + '\'' +
                    ",insuranceActNumber = '" + insuranceActNumber + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",contractTypeClassList = '" + contractTypeClassList + '\'' +
                    ",reissueDate = '" + reissueDate + '\'' +
                    ",sysCreator = '" + sysCreator + '\'' +
                    ",contractTypeClass = '" + contractTypeClass + '\'' +
                    ",statementStatusCode = '" + statementStatusCode + '\'' +
                    ",contractStartDate = '" + contractStartDate + '\'' +
                    ",insurerSysEditor = '" + insurerSysEditor + '\'' +
                    ",isActivateAgentFromAnotherBranch = '" + isActivateAgentFromAnotherBranch + '\'' +
                    ",agentName = '" + agentName + '\'' +
                    ",insurerHasCellPhone = '" + insurerHasCellPhone + '\'' +
                    ",isReinsure = '" + isReinsure + '\'' +
                    ",productVariant = '" + productVariant + '\'' +
                    ",isEmptySourceCheckSum = '" + isEmptySourceCheckSum + '\'' +
                    ",paymentMethod = '" + paymentMethod + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",claimReturnSum = '" + claimReturnSum + '\'' +
                    ",agentId = '" + agentId + '\'' +
                    ",cancelDate = '" + cancelDate + '\'' +
                    ",existActiveAsyncRequest = '" + existActiveAsyncRequest + '\'' +
                    ",stateProcurementStartDate = '" + stateProcurementStartDate + '\'' +
                    ",previousPremium = '" + previousPremium + '\'' +
                    ",liabilityStartDate = '" + liabilityStartDate + '\'' +
                    ",liabilityType = '" + liabilityType + '\'' +
                    ",factAccruedPremiumDateStartDate = '" + factAccruedPremiumDateStartDate + '\'' +
                    ",saleGroup = '" + saleGroup + '\'' +
                    ",payerTypeList = '" + payerTypeList + '\'' +
                    ",reinsureStartDate = '" + reinsureStartDate + '\'' +
                    ",insuredVehicleList = '" + insuredVehicleList + '\'' +
                    ",department = '" + department + '\'' +
                    ",paymentMethodList = '" + paymentMethodList + '\'' +
                    ",insurerChangeId = '" + insurerChangeId + '\'' +
                    ",quoteDate = '" + quoteDate + '\'' +
                    ",likardData = '" + likardData + '\'' +
                    ",contractOption = '" + contractOption + '\'' +
                    ",exceedsTariff = '" + exceedsTariff + '\'' +
                    ",contractEndDate = '" + contractEndDate + '\'' +
                    ",cancelStatementDate = '" + cancelStatementDate + '\'' +
                    ",insurerName = '" + insurerName + '\'' +
                    ",contractTypeClassStartDate = '" + contractTypeClassStartDate + '\'' +
                    ",blankDto = '" + blankDto + '\'' +
                    ",premiumRur = '" + premiumRur + '\'' +
                    ",canPayWithoutDoc = '" + canPayWithoutDoc + '\'' +
                    ",paymentTypeList = '" + paymentTypeList + '\'' +
                    ",drivingLimitationTypeList = '" + drivingLimitationTypeList + '\'' +
                    ",entityPurpose = '" + entityPurpose + '\'' +
                    ",liabilitySum = '" + liabilitySum + '\'' +
                    ",isPledgedProperty = '" + isPledgedProperty + '\'' +
                    ",isProcessPersInfo = '" + isProcessPersInfo + '\'' +
                    ",isProcessPersInfoEmpty = '" + isProcessPersInfoEmpty + '\'' +
                    "}";
  }
}