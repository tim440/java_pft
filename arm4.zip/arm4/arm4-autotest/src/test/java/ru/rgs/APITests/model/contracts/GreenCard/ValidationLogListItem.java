package ru.rgs.APITests.model.contracts.GreenCard;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ValidationLogListItem {

  @SerializedName("fromDocument")
  private String fromDocument;

  @SerializedName("name")
  private String name;

  @SerializedName("errorCode")
  private String errorCode;

  @SerializedName("fixed")
  private String fixed;

  @SerializedName("id")
  private String id;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("sysUserFullName")
  private String sysUserFullName;

  @SerializedName("createDate")
  private String createDate;

  public void setFromDocument(String fromDocument) {
    this.fromDocument = fromDocument;
  }

  public String getFromDocument() {
    return fromDocument;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public String getErrorCode() {
    return errorCode;
  }

  public void setFixed(String fixed) {
    this.fixed = fixed;
  }

  public String getFixed() {
    return fixed;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setSysUserFullName(String sysUserFullName) {
    this.sysUserFullName = sysUserFullName;
  }

  public String getSysUserFullName() {
    return sysUserFullName;
  }

  public void setCreateDate(String createDate) {
    this.createDate = createDate;
  }

  public String getCreateDate() {
    return createDate;
  }

  @Override
  public String toString() {
    return
            "ValidationLogListItem{" +
                    "fromDocument = '" + fromDocument + '\'' +
                    ",name = '" + name + '\'' +
                    ",errorCode = '" + errorCode + '\'' +
                    ",fixed = '" + fixed + '\'' +
                    ",id = '" + id + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",sysUserFullName = '" + sysUserFullName + '\'' +
                    ",createDate = '" + createDate + '\'' +
                    "}";
  }
}