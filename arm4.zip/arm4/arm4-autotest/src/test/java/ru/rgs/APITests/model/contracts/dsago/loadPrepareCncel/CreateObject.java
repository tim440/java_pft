package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class CreateObject {

  @SerializedName("contractDate")
  private String contractDate;

  @SerializedName("drivingLimitationTypeByPersonTypeList")
  private List<DrivingLimitationTypeByPersonTypeListItem> drivingLimitationTypeByPersonTypeList;

  @SerializedName("contractChangeList")
  private List<ContractChangeListItem> contractChangeList;

  @SerializedName("contractType")
  private ContractType contractType;

  @SerializedName("coInsuranceStartDate")
  private String coInsuranceStartDate;

  @SerializedName("vehicleSysEditor")
  private String vehicleSysEditor;

  @SerializedName("premiumRate")
  private PremiumRate premiumRate;

  @SerializedName("office")
  private Office office;

  @SerializedName("branch")
  private Branch branch;

  @SerializedName("insuranceActNumber")
  private String insuranceActNumber;

  @SerializedName("validationLogList")
  private List<ValidationLogListItem> validationLogList;

  @SerializedName("number")
  private String number;

  @SerializedName("currentContractChange")
  private CurrentContractChange currentContractChange;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("contractTypeClassList")
  private List<ContractTypeClassListItem> contractTypeClassList;

  @SerializedName("insurerIsOwner")
  private String insurerIsOwner;

  @SerializedName("id")
  private String id;

  @SerializedName("sysCreator")
  private String sysCreator;

  @SerializedName("contractTypeClass")
  private ContractTypeClass contractTypeClass;

  @SerializedName("statementStatusCode")
  private String statementStatusCode;

  @SerializedName("isReceivedPrimaryDoc")
  private String isReceivedPrimaryDoc;

  @SerializedName("contractStartDate")
  private String contractStartDate;

  @SerializedName("liability")
  private String liability;

  @SerializedName("insurerSysEditor")
  private String insurerSysEditor;

  @SerializedName("isActivateAgentFromAnotherBranch")
  private String isActivateAgentFromAnotherBranch;

  @SerializedName("agentName")
  private String agentName;

  @SerializedName("premiumChargeType")
  private PremiumChargeType premiumChargeType;

  @SerializedName("insurerPersonTypeCode")
  private String insurerPersonTypeCode;

  @SerializedName("creationType")
  private CreationType creationType;

  @SerializedName("insurerHasCellPhone")
  private String insurerHasCellPhone;

  @SerializedName("isReinsure")
  private String isReinsure;

  @SerializedName("saleChannel")
  private SaleChannel saleChannel;

  @SerializedName("productVariant")
  private ProductVariant productVariant;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("claimReturnSum")
  private String claimReturnSum;

  @SerializedName("status")
  private Status status;

  @SerializedName("noBlank")
  private String noBlank;

  @SerializedName("insuredVehicle")
  private InsuredVehicle insuredVehicle;

  @SerializedName("agentId")
  private String agentId;

  @SerializedName("cancelDate")
  private String cancelDate;

  @SerializedName("vehicleName")
  private String vehicleName;

  @SerializedName("existActiveAsyncRequest")
  private String existActiveAsyncRequest;

  @SerializedName("stateProcurementStartDate")
  private String stateProcurementStartDate;

  @SerializedName("debitWriteOffReasonList")
  private List<DebitWriteOffReasonListItem> debitWriteOffReasonList;

  @SerializedName("insuredVehicleId")
  private String insuredVehicleId;

  @SerializedName("liabilityStartDate")
  private String liabilityStartDate;

  @SerializedName("isCoInsurance")
  private String isCoInsurance;

  @SerializedName("agentStatementNumber")
  private String agentStatementNumber;

  @SerializedName("factAccruedPremiumDateStartDate")
  private String factAccruedPremiumDateStartDate;

  @SerializedName("vehicle")
  private Vehicle vehicle;

  @SerializedName("saleGroup")
  private SaleGroup saleGroup;

  @SerializedName("premium")
  private String premium;

  @SerializedName("insurer")
  private Insurer insurer;

  @SerializedName("payerTypeList")
  private List<PayerTypeListItem> payerTypeList;

  @SerializedName("reinsureStartDate")
  private String reinsureStartDate;

  @SerializedName("liabilityEndDate")
  private String liabilityEndDate;

  @SerializedName("currency")
  private Currency currency;

  @SerializedName("useNewCascoDate")
  private String useNewCascoDate;

  @SerializedName("vehicleId")
  private String vehicleId;

  @SerializedName("cancelReason")
  private CancelReason cancelReason;

  @SerializedName("department")
  private Department department;

  @SerializedName("insurerChangeId")
  private String insurerChangeId;

  @SerializedName("likardData")
  private LikardData likardData;

  @SerializedName("product")
  private Product product;

  @SerializedName("isStateProcurement")
  private String isStateProcurement;

  @SerializedName("contractOption")
  private ContractOption contractOption;

  @SerializedName("contractEndDate")
  private String contractEndDate;

  @SerializedName("cancelStatementDate")
  private String cancelStatementDate;

  @SerializedName("smsSubscription")
  private String smsSubscription;

  @SerializedName("vinStartDate")
  private String vinStartDate;

  @SerializedName("insurerName")
  private String insurerName;

  @SerializedName("insurerId")
  private String insurerId;

  @SerializedName("agentStatementId")
  private String agentStatementId;

  @SerializedName("agentStatementDate")
  private String agentStatementDate;

  @SerializedName("contractTypeClassStartDate")
  private String contractTypeClassStartDate;

  @SerializedName("blankDto")
  private BlankDto blankDto;

  @SerializedName("premiumRur")
  private String premiumRur;

  @SerializedName("paymentTypeList")
  private List<PaymentTypeListItem> paymentTypeList;

  @SerializedName("series")
  private String series;

  @SerializedName("entityPurpose")
  private String entityPurpose;

  @SerializedName("coInsuranceTotalPremium")
  private String coInsuranceTotalPremium;

  public void setContractDate(String contractDate) {
    this.contractDate = contractDate;
  }

  public String getContractDate() {
    return contractDate;
  }

  public void setDrivingLimitationTypeByPersonTypeList(List<DrivingLimitationTypeByPersonTypeListItem> drivingLimitationTypeByPersonTypeList) {
    this.drivingLimitationTypeByPersonTypeList = drivingLimitationTypeByPersonTypeList;
  }

  public List<DrivingLimitationTypeByPersonTypeListItem> getDrivingLimitationTypeByPersonTypeList() {
    return drivingLimitationTypeByPersonTypeList;
  }

  public void setContractChangeList(List<ContractChangeListItem> contractChangeList) {
    this.contractChangeList = contractChangeList;
  }

  public List<ContractChangeListItem> getContractChangeList() {
    return contractChangeList;
  }

  public void setContractType(ContractType contractType) {
    this.contractType = contractType;
  }

  public ContractType getContractType() {
    return contractType;
  }

  public void setCoInsuranceStartDate(String coInsuranceStartDate) {
    this.coInsuranceStartDate = coInsuranceStartDate;
  }

  public String getCoInsuranceStartDate() {
    return coInsuranceStartDate;
  }

  public void setVehicleSysEditor(String vehicleSysEditor) {
    this.vehicleSysEditor = vehicleSysEditor;
  }

  public String getVehicleSysEditor() {
    return vehicleSysEditor;
  }

  public void setPremiumRate(PremiumRate premiumRate) {
    this.premiumRate = premiumRate;
  }

  public PremiumRate getPremiumRate() {
    return premiumRate;
  }

  public void setOffice(Office office) {
    this.office = office;
  }

  public Office getOffice() {
    return office;
  }

  public void setBranch(Branch branch) {
    this.branch = branch;
  }

  public Branch getBranch() {
    return branch;
  }

  public void setInsuranceActNumber(String insuranceActNumber) {
    this.insuranceActNumber = insuranceActNumber;
  }

  public String getInsuranceActNumber() {
    return insuranceActNumber;
  }

  public void setValidationLogList(List<ValidationLogListItem> validationLogList) {
    this.validationLogList = validationLogList;
  }

  public List<ValidationLogListItem> getValidationLogList() {
    return validationLogList;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getNumber() {
    return number;
  }

  public void setCurrentContractChange(CurrentContractChange currentContractChange) {
    this.currentContractChange = currentContractChange;
  }

  public CurrentContractChange getCurrentContractChange() {
    return currentContractChange;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setContractTypeClassList(List<ContractTypeClassListItem> contractTypeClassList) {
    this.contractTypeClassList = contractTypeClassList;
  }

  public List<ContractTypeClassListItem> getContractTypeClassList() {
    return contractTypeClassList;
  }

  public void setInsurerIsOwner(String insurerIsOwner) {
    this.insurerIsOwner = insurerIsOwner;
  }

  public String getInsurerIsOwner() {
    return insurerIsOwner;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setSysCreator(String sysCreator) {
    this.sysCreator = sysCreator;
  }

  public String getSysCreator() {
    return sysCreator;
  }

  public void setContractTypeClass(ContractTypeClass contractTypeClass) {
    this.contractTypeClass = contractTypeClass;
  }

  public ContractTypeClass getContractTypeClass() {
    return contractTypeClass;
  }

  public void setStatementStatusCode(String statementStatusCode) {
    this.statementStatusCode = statementStatusCode;
  }

  public String getStatementStatusCode() {
    return statementStatusCode;
  }

  public void setIsReceivedPrimaryDoc(String isReceivedPrimaryDoc) {
    this.isReceivedPrimaryDoc = isReceivedPrimaryDoc;
  }

  public String getIsReceivedPrimaryDoc() {
    return isReceivedPrimaryDoc;
  }

  public void setContractStartDate(String contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  public String getContractStartDate() {
    return contractStartDate;
  }

  public void setLiability(String liability) {
    this.liability = liability;
  }

  public String getLiability() {
    return liability;
  }

  public void setInsurerSysEditor(String insurerSysEditor) {
    this.insurerSysEditor = insurerSysEditor;
  }

  public String getInsurerSysEditor() {
    return insurerSysEditor;
  }

  public void setIsActivateAgentFromAnotherBranch(String isActivateAgentFromAnotherBranch) {
    this.isActivateAgentFromAnotherBranch = isActivateAgentFromAnotherBranch;
  }

  public String getIsActivateAgentFromAnotherBranch() {
    return isActivateAgentFromAnotherBranch;
  }

  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }

  public String getAgentName() {
    return agentName;
  }

  public void setPremiumChargeType(PremiumChargeType premiumChargeType) {
    this.premiumChargeType = premiumChargeType;
  }

  public PremiumChargeType getPremiumChargeType() {
    return premiumChargeType;
  }

  public void setInsurerPersonTypeCode(String insurerPersonTypeCode) {
    this.insurerPersonTypeCode = insurerPersonTypeCode;
  }

  public String getInsurerPersonTypeCode() {
    return insurerPersonTypeCode;
  }

  public void setCreationType(CreationType creationType) {
    this.creationType = creationType;
  }

  public CreationType getCreationType() {
    return creationType;
  }

  public void setInsurerHasCellPhone(String insurerHasCellPhone) {
    this.insurerHasCellPhone = insurerHasCellPhone;
  }

  public String getInsurerHasCellPhone() {
    return insurerHasCellPhone;
  }

  public void setIsReinsure(String isReinsure) {
    this.isReinsure = isReinsure;
  }

  public String getIsReinsure() {
    return isReinsure;
  }

  public void setSaleChannel(SaleChannel saleChannel) {
    this.saleChannel = saleChannel;
  }

  public SaleChannel getSaleChannel() {
    return saleChannel;
  }

  public void setProductVariant(ProductVariant productVariant) {
    this.productVariant = productVariant;
  }

  public ProductVariant getProductVariant() {
    return productVariant;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setClaimReturnSum(String claimReturnSum) {
    this.claimReturnSum = claimReturnSum;
  }

  public String getClaimReturnSum() {
    return claimReturnSum;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public Status getStatus() {
    return status;
  }

  public void setNoBlank(String noBlank) {
    this.noBlank = noBlank;
  }

  public String getNoBlank() {
    return noBlank;
  }

  public void setInsuredVehicle(InsuredVehicle insuredVehicle) {
    this.insuredVehicle = insuredVehicle;
  }

  public InsuredVehicle getInsuredVehicle() {
    return insuredVehicle;
  }

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setCancelDate(String cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getCancelDate() {
    return cancelDate;
  }

  public void setVehicleName(String vehicleName) {
    this.vehicleName = vehicleName;
  }

  public String getVehicleName() {
    return vehicleName;
  }

  public void setExistActiveAsyncRequest(String existActiveAsyncRequest) {
    this.existActiveAsyncRequest = existActiveAsyncRequest;
  }

  public String getExistActiveAsyncRequest() {
    return existActiveAsyncRequest;
  }

  public void setStateProcurementStartDate(String stateProcurementStartDate) {
    this.stateProcurementStartDate = stateProcurementStartDate;
  }

  public String getStateProcurementStartDate() {
    return stateProcurementStartDate;
  }

  public void setDebitWriteOffReasonList(List<DebitWriteOffReasonListItem> debitWriteOffReasonList) {
    this.debitWriteOffReasonList = debitWriteOffReasonList;
  }

  public List<DebitWriteOffReasonListItem> getDebitWriteOffReasonList() {
    return debitWriteOffReasonList;
  }

  public void setInsuredVehicleId(String insuredVehicleId) {
    this.insuredVehicleId = insuredVehicleId;
  }

  public String getInsuredVehicleId() {
    return insuredVehicleId;
  }

  public void setLiabilityStartDate(String liabilityStartDate) {
    this.liabilityStartDate = liabilityStartDate;
  }

  public String getLiabilityStartDate() {
    return liabilityStartDate;
  }

  public void setIsCoInsurance(String isCoInsurance) {
    this.isCoInsurance = isCoInsurance;
  }

  public String getIsCoInsurance() {
    return isCoInsurance;
  }

  public void setAgentStatementNumber(String agentStatementNumber) {
    this.agentStatementNumber = agentStatementNumber;
  }

  public String getAgentStatementNumber() {
    return agentStatementNumber;
  }

  public void setFactAccruedPremiumDateStartDate(String factAccruedPremiumDateStartDate) {
    this.factAccruedPremiumDateStartDate = factAccruedPremiumDateStartDate;
  }

  public String getFactAccruedPremiumDateStartDate() {
    return factAccruedPremiumDateStartDate;
  }

  public void setVehicle(Vehicle vehicle) {
    this.vehicle = vehicle;
  }

  public Vehicle getVehicle() {
    return vehicle;
  }

  public void setSaleGroup(SaleGroup saleGroup) {
    this.saleGroup = saleGroup;
  }

  public SaleGroup getSaleGroup() {
    return saleGroup;
  }

  public void setPremium(String premium) {
    this.premium = premium;
  }

  public String getPremium() {
    return premium;
  }

  public void setInsurer(Insurer insurer) {
    this.insurer = insurer;
  }

  public Insurer getInsurer() {
    return insurer;
  }

  public void setPayerTypeList(List<PayerTypeListItem> payerTypeList) {
    this.payerTypeList = payerTypeList;
  }

  public List<PayerTypeListItem> getPayerTypeList() {
    return payerTypeList;
  }

  public void setReinsureStartDate(String reinsureStartDate) {
    this.reinsureStartDate = reinsureStartDate;
  }

  public String getReinsureStartDate() {
    return reinsureStartDate;
  }

  public void setLiabilityEndDate(String liabilityEndDate) {
    this.liabilityEndDate = liabilityEndDate;
  }

  public String getLiabilityEndDate() {
    return liabilityEndDate;
  }

  public void setCurrency(Currency currency) {
    this.currency = currency;
  }

  public Currency getCurrency() {
    return currency;
  }

  public void setUseNewCascoDate(String useNewCascoDate) {
    this.useNewCascoDate = useNewCascoDate;
  }

  public String getUseNewCascoDate() {
    return useNewCascoDate;
  }

  public void setVehicleId(String vehicleId) {
    this.vehicleId = vehicleId;
  }

  public String getVehicleId() {
    return vehicleId;
  }

  public void setCancelReason(CancelReason cancelReason) {
    this.cancelReason = cancelReason;
  }

  public CancelReason getCancelReason() {
    return cancelReason;
  }

  public void setDepartment(Department department) {
    this.department = department;
  }

  public Department getDepartment() {
    return department;
  }

  public void setInsurerChangeId(String insurerChangeId) {
    this.insurerChangeId = insurerChangeId;
  }

  public String getInsurerChangeId() {
    return insurerChangeId;
  }

  public void setLikardData(LikardData likardData) {
    this.likardData = likardData;
  }

  public LikardData getLikardData() {
    return likardData;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public Product getProduct() {
    return product;
  }

  public void setIsStateProcurement(String isStateProcurement) {
    this.isStateProcurement = isStateProcurement;
  }

  public String getIsStateProcurement() {
    return isStateProcurement;
  }

  public void setContractOption(ContractOption contractOption) {
    this.contractOption = contractOption;
  }

  public ContractOption getContractOption() {
    return contractOption;
  }

  public void setContractEndDate(String contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  public String getContractEndDate() {
    return contractEndDate;
  }

  public void setCancelStatementDate(String cancelStatementDate) {
    this.cancelStatementDate = cancelStatementDate;
  }

  public String getCancelStatementDate() {
    return cancelStatementDate;
  }

  public void setSmsSubscription(String smsSubscription) {
    this.smsSubscription = smsSubscription;
  }

  public String getSmsSubscription() {
    return smsSubscription;
  }

  public void setVinStartDate(String vinStartDate) {
    this.vinStartDate = vinStartDate;
  }

  public String getVinStartDate() {
    return vinStartDate;
  }

  public void setInsurerName(String insurerName) {
    this.insurerName = insurerName;
  }

  public String getInsurerName() {
    return insurerName;
  }

  public void setInsurerId(String insurerId) {
    this.insurerId = insurerId;
  }

  public String getInsurerId() {
    return insurerId;
  }

  public void setAgentStatementId(String agentStatementId) {
    this.agentStatementId = agentStatementId;
  }

  public String getAgentStatementId() {
    return agentStatementId;
  }

  public void setAgentStatementDate(String agentStatementDate) {
    this.agentStatementDate = agentStatementDate;
  }

  public String getAgentStatementDate() {
    return agentStatementDate;
  }

  public void setContractTypeClassStartDate(String contractTypeClassStartDate) {
    this.contractTypeClassStartDate = contractTypeClassStartDate;
  }

  public String getContractTypeClassStartDate() {
    return contractTypeClassStartDate;
  }

  public void setBlankDto(BlankDto blankDto) {
    this.blankDto = blankDto;
  }

  public BlankDto getBlankDto() {
    return blankDto;
  }

  public void setPremiumRur(String premiumRur) {
    this.premiumRur = premiumRur;
  }

  public String getPremiumRur() {
    return premiumRur;
  }

  public void setPaymentTypeList(List<PaymentTypeListItem> paymentTypeList) {
    this.paymentTypeList = paymentTypeList;
  }

  public List<PaymentTypeListItem> getPaymentTypeList() {
    return paymentTypeList;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public String getSeries() {
    return series;
  }

  public void setEntityPurpose(String entityPurpose) {
    this.entityPurpose = entityPurpose;
  }

  public String getEntityPurpose() {
    return entityPurpose;
  }

  public void setCoInsuranceTotalPremium(String coInsuranceTotalPremium) {
    this.coInsuranceTotalPremium = coInsuranceTotalPremium;
  }

  public String getCoInsuranceTotalPremium() {
    return coInsuranceTotalPremium;
  }

  @Override
  public String toString() {
    return
            "CreateObject{" +
                    "contractDate = '" + contractDate + '\'' +
                    ",drivingLimitationTypeByPersonTypeList = '" + drivingLimitationTypeByPersonTypeList + '\'' +
                    ",contractChangeList = '" + contractChangeList + '\'' +
                    ",contractType = '" + contractType + '\'' +
                    ",coInsuranceStartDate = '" + coInsuranceStartDate + '\'' +
                    ",vehicleSysEditor = '" + vehicleSysEditor + '\'' +
                    ",premiumRate = '" + premiumRate + '\'' +
                    ",office = '" + office + '\'' +
                    ",branch = '" + branch + '\'' +
                    ",insuranceActNumber = '" + insuranceActNumber + '\'' +
                    ",validationLogList = '" + validationLogList + '\'' +
                    ",number = '" + number + '\'' +
                    ",currentContractChange = '" + currentContractChange + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",contractTypeClassList = '" + contractTypeClassList + '\'' +
                    ",insurerIsOwner = '" + insurerIsOwner + '\'' +
                    ",id = '" + id + '\'' +
                    ",sysCreator = '" + sysCreator + '\'' +
                    ",contractTypeClass = '" + contractTypeClass + '\'' +
                    ",statementStatusCode = '" + statementStatusCode + '\'' +
                    ",isReceivedPrimaryDoc = '" + isReceivedPrimaryDoc + '\'' +
                    ",contractStartDate = '" + contractStartDate + '\'' +
                    ",liability = '" + liability + '\'' +
                    ",insurerSysEditor = '" + insurerSysEditor + '\'' +
                    ",isActivateAgentFromAnotherBranch = '" + isActivateAgentFromAnotherBranch + '\'' +
                    ",agentName = '" + agentName + '\'' +
                    ",premiumChargeType = '" + premiumChargeType + '\'' +
                    ",insurerPersonTypeCode = '" + insurerPersonTypeCode + '\'' +
                    ",creationType = '" + creationType + '\'' +
                    ",insurerHasCellPhone = '" + insurerHasCellPhone + '\'' +
                    ",isReinsure = '" + isReinsure + '\'' +
                    ",saleChannel = '" + saleChannel + '\'' +
                    ",productVariant = '" + productVariant + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",claimReturnSum = '" + claimReturnSum + '\'' +
                    ",status = '" + status + '\'' +
                    ",noBlank = '" + noBlank + '\'' +
                    ",insuredVehicle = '" + insuredVehicle + '\'' +
                    ",agentId = '" + agentId + '\'' +
                    ",cancelDate = '" + cancelDate + '\'' +
                    ",vehicleName = '" + vehicleName + '\'' +
                    ",existActiveAsyncRequest = '" + existActiveAsyncRequest + '\'' +
                    ",stateProcurementStartDate = '" + stateProcurementStartDate + '\'' +
                    ",debitWriteOffReasonList = '" + debitWriteOffReasonList + '\'' +
                    ",insuredVehicleId = '" + insuredVehicleId + '\'' +
                    ",liabilityStartDate = '" + liabilityStartDate + '\'' +
                    ",isCoInsurance = '" + isCoInsurance + '\'' +
                    ",agentStatementNumber = '" + agentStatementNumber + '\'' +
                    ",factAccruedPremiumDateStartDate = '" + factAccruedPremiumDateStartDate + '\'' +
                    ",vehicle = '" + vehicle + '\'' +
                    ",saleGroup = '" + saleGroup + '\'' +
                    ",premium = '" + premium + '\'' +
                    ",insurer = '" + insurer + '\'' +
                    ",payerTypeList = '" + payerTypeList + '\'' +
                    ",reinsureStartDate = '" + reinsureStartDate + '\'' +
                    ",liabilityEndDate = '" + liabilityEndDate + '\'' +
                    ",currency = '" + currency + '\'' +
                    ",useNewCascoDate = '" + useNewCascoDate + '\'' +
                    ",vehicleId = '" + vehicleId + '\'' +
                    ",cancelReason = '" + cancelReason + '\'' +
                    ",department = '" + department + '\'' +
                    ",insurerChangeId = '" + insurerChangeId + '\'' +
                    ",likardData = '" + likardData + '\'' +
                    ",product = '" + product + '\'' +
                    ",isStateProcurement = '" + isStateProcurement + '\'' +
                    ",contractOption = '" + contractOption + '\'' +
                    ",contractEndDate = '" + contractEndDate + '\'' +
                    ",cancelStatementDate = '" + cancelStatementDate + '\'' +
                    ",smsSubscription = '" + smsSubscription + '\'' +
                    ",vinStartDate = '" + vinStartDate + '\'' +
                    ",insurerName = '" + insurerName + '\'' +
                    ",insurerId = '" + insurerId + '\'' +
                    ",agentStatementId = '" + agentStatementId + '\'' +
                    ",agentStatementDate = '" + agentStatementDate + '\'' +
                    ",contractTypeClassStartDate = '" + contractTypeClassStartDate + '\'' +
                    ",blankDto = '" + blankDto + '\'' +
                    ",premiumRur = '" + premiumRur + '\'' +
                    ",paymentTypeList = '" + paymentTypeList + '\'' +
                    ",series = '" + series + '\'' +
                    ",entityPurpose = '" + entityPurpose + '\'' +
                    ",coInsuranceTotalPremium = '" + coInsuranceTotalPremium + '\'' +
                    "}";
  }
}