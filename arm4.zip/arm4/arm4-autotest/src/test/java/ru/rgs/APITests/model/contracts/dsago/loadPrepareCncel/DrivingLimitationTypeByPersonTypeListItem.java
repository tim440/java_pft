package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class DrivingLimitationTypeByPersonTypeListItem {

  @SerializedName("personTypeId")
  private String personTypeId;

  @SerializedName("personTypeName")
  private String personTypeName;

  @SerializedName("drLimTypeId")
  private String drLimTypeId;

  @SerializedName("personTypeCode")
  private String personTypeCode;

  @SerializedName("drLimTypeCode")
  private String drLimTypeCode;

  @SerializedName("drLimTypeName")
  private String drLimTypeName;

  public void setPersonTypeId(String personTypeId) {
    this.personTypeId = personTypeId;
  }

  public String getPersonTypeId() {
    return personTypeId;
  }

  public void setPersonTypeName(String personTypeName) {
    this.personTypeName = personTypeName;
  }

  public String getPersonTypeName() {
    return personTypeName;
  }

  public void setDrLimTypeId(String drLimTypeId) {
    this.drLimTypeId = drLimTypeId;
  }

  public String getDrLimTypeId() {
    return drLimTypeId;
  }

  public void setPersonTypeCode(String personTypeCode) {
    this.personTypeCode = personTypeCode;
  }

  public String getPersonTypeCode() {
    return personTypeCode;
  }

  public void setDrLimTypeCode(String drLimTypeCode) {
    this.drLimTypeCode = drLimTypeCode;
  }

  public String getDrLimTypeCode() {
    return drLimTypeCode;
  }

  public void setDrLimTypeName(String drLimTypeName) {
    this.drLimTypeName = drLimTypeName;
  }

  public String getDrLimTypeName() {
    return drLimTypeName;
  }

  @Override
  public String toString() {
    return
            "DrivingLimitationTypeByPersonTypeListItem{" +
                    "personTypeId = '" + personTypeId + '\'' +
                    ",personTypeName = '" + personTypeName + '\'' +
                    ",drLimTypeId = '" + drLimTypeId + '\'' +
                    ",personTypeCode = '" + personTypeCode + '\'' +
                    ",drLimTypeCode = '" + drLimTypeCode + '\'' +
                    ",drLimTypeName = '" + drLimTypeName + '\'' +
                    "}";
  }
}