package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class LikardBlank {

  @Override
  public String toString() {
    return
            "LikardBlank{" +
                    "}";
  }
}