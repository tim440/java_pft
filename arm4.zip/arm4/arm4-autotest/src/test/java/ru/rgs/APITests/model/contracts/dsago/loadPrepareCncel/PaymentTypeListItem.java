package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class PaymentTypeListItem {

  @SerializedName("code")
  private String code;

  @SerializedName("endDate")
  private String endDate;

  //TODO исправить, когда будет исправлена бага
  @SerializedName("paymentDocuments")
  private /*List<PaymentDocumentsItem>*/ Object paymentDocuments;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  @SerializedName("startDate")
  private String startDate;

  @SerializedName("codeAndName")
  private String codeAndName;

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setPaymentDocuments(List<PaymentDocumentsItem> paymentDocuments) {
    this.paymentDocuments = paymentDocuments;
  }

  public /*List<PaymentDocumentsItem>*/ Object getPaymentDocuments() {
    return paymentDocuments;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setCodeAndName(String codeAndName) {
    this.codeAndName = codeAndName;
  }

  public String getCodeAndName() {
    return codeAndName;
  }

  @Override
  public String toString() {
    return
            "PaymentTypeListItem{" +
                    "code = '" + code + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",paymentDocuments = '" + paymentDocuments + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    ",codeAndName = '" + codeAndName + '\'' +
                    "}";
  }
}