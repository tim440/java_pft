package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Model {

  @SerializedName("vehicleGroup")
  private VehicleGroup vehicleGroup;

  @SerializedName("code")
  private String code;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  @SerializedName("brand")
  private Brand brand;

  @SerializedName("startDate")
  private String startDate;

  @SerializedName("codeAndName")
  private String codeAndName;

  @SerializedName("vehicleType")
  private VehicleType vehicleType;

  public void setVehicleGroup(VehicleGroup vehicleGroup) {
    this.vehicleGroup = vehicleGroup;
  }

  public VehicleGroup getVehicleGroup() {
    return vehicleGroup;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setBrand(Brand brand) {
    this.brand = brand;
  }

  public Brand getBrand() {
    return brand;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setCodeAndName(String codeAndName) {
    this.codeAndName = codeAndName;
  }

  public String getCodeAndName() {
    return codeAndName;
  }

  public void setVehicleType(VehicleType vehicleType) {
    this.vehicleType = vehicleType;
  }

  public VehicleType getVehicleType() {
    return vehicleType;
  }

  @Override
  public String toString() {
    return
            "Model{" +
                    "vehicleGroup = '" + vehicleGroup + '\'' +
                    ",code = '" + code + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    ",brand = '" + brand + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    ",codeAndName = '" + codeAndName + '\'' +
                    ",vehicleType = '" + vehicleType + '\'' +
                    "}";
  }
}