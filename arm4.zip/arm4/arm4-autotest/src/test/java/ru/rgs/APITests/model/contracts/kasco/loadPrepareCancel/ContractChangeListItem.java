package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ContractChangeListItem {

  @SerializedName("premiumProportion")
  private String premiumProportion;

  @SerializedName("changeType")
  private ChangeType changeType;

  @SerializedName("topBranchUserName")
  private String topBranchUserName;

  @SerializedName("contractId")
  private String contractId;

  @SerializedName("id")
  private String id;

  @SerializedName("sysModifyDate")
  private String sysModifyDate;

  @SerializedName("bid")
  private String bid;

  @SerializedName("contractClassCode")
  private String contractClassCode;

  @SerializedName("user")
  private String user;

  @SerializedName("startDate")
  private String startDate;

  @SerializedName("versionNumber")
  private String versionNumber;

  @SerializedName("createDate")
  private String createDate;

  public void setPremiumProportion(String premiumProportion) {
    this.premiumProportion = premiumProportion;
  }

  public String getPremiumProportion() {
    return premiumProportion;
  }

  public void setChangeType(ChangeType changeType) {
    this.changeType = changeType;
  }

  public ChangeType getChangeType() {
    return changeType;
  }

  public void setTopBranchUserName(String topBranchUserName) {
    this.topBranchUserName = topBranchUserName;
  }

  public String getTopBranchUserName() {
    return topBranchUserName;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getContractId() {
    return contractId;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setSysModifyDate(String sysModifyDate) {
    this.sysModifyDate = sysModifyDate;
  }

  public String getSysModifyDate() {
    return sysModifyDate;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setContractClassCode(String contractClassCode) {
    this.contractClassCode = contractClassCode;
  }

  public String getContractClassCode() {
    return contractClassCode;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getUser() {
    return user;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setVersionNumber(String versionNumber) {
    this.versionNumber = versionNumber;
  }

  public String getVersionNumber() {
    return versionNumber;
  }

  public void setCreateDate(String createDate) {
    this.createDate = createDate;
  }

  public String getCreateDate() {
    return createDate;
  }

  @Override
  public String toString() {
    return
            "ContractChangeListItem{" +
                    "premiumProportion = '" + premiumProportion + '\'' +
                    ",changeType = '" + changeType + '\'' +
                    ",topBranchUserName = '" + topBranchUserName + '\'' +
                    ",contractId = '" + contractId + '\'' +
                    ",id = '" + id + '\'' +
                    ",sysModifyDate = '" + sysModifyDate + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",contractClassCode = '" + contractClassCode + '\'' +
                    ",user = '" + user + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    ",versionNumber = '" + versionNumber + '\'' +
                    ",createDate = '" + createDate + '\'' +
                    "}";
  }
}