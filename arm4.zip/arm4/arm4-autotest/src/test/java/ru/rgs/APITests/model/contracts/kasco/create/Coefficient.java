package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Coefficient {

  @SerializedName("minValue")
  private int minValue;

  @SerializedName("javaCode")
  private String javaCode;

  @SerializedName("maxValue")
  private int maxValue;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  public void setMinValue(int minValue) {
    this.minValue = minValue;
  }

  public int getMinValue() {
    return minValue;
  }

  public void setJavaCode(String javaCode) {
    this.javaCode = javaCode;
  }

  public String getJavaCode() {
    return javaCode;
  }

  public void setMaxValue(int maxValue) {
    this.maxValue = maxValue;
  }

  public int getMaxValue() {
    return maxValue;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  @Override
  public String toString() {
    return
            "Coefficient{" +
                    "minValue = '" + minValue + '\'' +
                    ",javaCode = '" + javaCode + '\'' +
                    ",maxValue = '" + maxValue + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    "}";
  }
}