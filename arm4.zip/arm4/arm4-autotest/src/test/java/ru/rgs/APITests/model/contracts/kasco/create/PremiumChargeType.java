package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PremiumChargeType {

  @SerializedName("code")
  private String code;

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  @Override
  public String toString() {
    return
            "PremiumChargeType{" +
                    "code = '" + code + '\'' +
                    "}";
  }
}