package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class AccidentListItem {

  @SerializedName("accidentType")
  private AccidentType accidentType;

  @SerializedName("selected")
  private boolean selected;

  public void setAccidentType(AccidentType accidentType) {
    this.accidentType = accidentType;
  }

  public AccidentType getAccidentType() {
    return accidentType;
  }

  public void setSelected(boolean selected) {
    this.selected = selected;
  }

  public boolean isSelected() {
    return selected;
  }

  @Override
  public String toString() {
    return
            "AccidentListItem{" +
                    "accidentType = '" + accidentType + '\'' +
                    ",selected = '" + selected + '\'' +
                    "}";
  }
}