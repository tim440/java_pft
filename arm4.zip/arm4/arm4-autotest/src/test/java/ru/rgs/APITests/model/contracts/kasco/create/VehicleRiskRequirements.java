package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class VehicleRiskRequirements {

  @SerializedName("alarmSystems")
  private String alarmSystems;

  @SerializedName("id")
  private String id;

  public void setAlarmSystems(String alarmSystems) {
    this.alarmSystems = alarmSystems;
  }

  public String getAlarmSystems() {
    return alarmSystems;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  @Override
  public String toString() {
    return
            "VehicleRiskRequirements{" +
                    "alarmSystems = '" + alarmSystems + '\'' +
                    ",id = '" + id + '\'' +
                    "}";
  }
}