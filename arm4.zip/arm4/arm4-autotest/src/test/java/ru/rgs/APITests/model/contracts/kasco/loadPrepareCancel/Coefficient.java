package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Coefficient {

  @SerializedName("minValue")
  private String minValue;

  @SerializedName("code")
  private String code;

  @SerializedName("javaCode")
  private String javaCode;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("defaultValue")
  private String defaultValue;

  @SerializedName("maxValue")
  private String maxValue;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  @SerializedName("startDate")
  private String startDate;

  @SerializedName("codeAndName")
  private String codeAndName;

  public void setMinValue(String minValue) {
    this.minValue = minValue;
  }

  public String getMinValue() {
    return minValue;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setJavaCode(String javaCode) {
    this.javaCode = javaCode;
  }

  public String getJavaCode() {
    return javaCode;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  public String getDefaultValue() {
    return defaultValue;
  }

  public void setMaxValue(String maxValue) {
    this.maxValue = maxValue;
  }

  public String getMaxValue() {
    return maxValue;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setCodeAndName(String codeAndName) {
    this.codeAndName = codeAndName;
  }

  public String getCodeAndName() {
    return codeAndName;
  }

  @Override
  public String toString() {
    return
            "Coefficient{" +
                    "minValue = '" + minValue + '\'' +
                    ",code = '" + code + '\'' +
                    ",javaCode = '" + javaCode + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",defaultValue = '" + defaultValue + '\'' +
                    ",maxValue = '" + maxValue + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    ",codeAndName = '" + codeAndName + '\'' +
                    "}";
  }
}