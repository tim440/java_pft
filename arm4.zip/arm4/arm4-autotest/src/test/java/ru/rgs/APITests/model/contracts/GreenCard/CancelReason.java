package ru.rgs.APITests.model.contracts.GreenCard;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class CancelReason {

  @SerializedName("code")
  private String code;

  @SerializedName("contractStatus")
  private ContractStatus contractStatus;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("contractClassId")
  private String contractClassId;

  @SerializedName("isRvdReturn")
  private String isRvdReturn;

  @SerializedName("sortOrder")
  private String sortOrder;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  @SerializedName("startDate")
  private String startDate;

  @SerializedName("codeAndName")
  private String codeAndName;

  @SerializedName("isPremiumReturn")
  private String isPremiumReturn;

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setContractStatus(ContractStatus contractStatus) {
    this.contractStatus = contractStatus;
  }

  public ContractStatus getContractStatus() {
    return contractStatus;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setContractClassId(String contractClassId) {
    this.contractClassId = contractClassId;
  }

  public String getContractClassId() {
    return contractClassId;
  }

  public void setIsRvdReturn(String isRvdReturn) {
    this.isRvdReturn = isRvdReturn;
  }

  public String getIsRvdReturn() {
    return isRvdReturn;
  }

  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

  public String getSortOrder() {
    return sortOrder;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setCodeAndName(String codeAndName) {
    this.codeAndName = codeAndName;
  }

  public String getCodeAndName() {
    return codeAndName;
  }

  public void setIsPremiumReturn(String isPremiumReturn) {
    this.isPremiumReturn = isPremiumReturn;
  }

  public String getIsPremiumReturn() {
    return isPremiumReturn;
  }

  @Override
  public String toString() {
    return
            "CancelReason{" +
                    "code = '" + code + '\'' +
                    ",contractStatus = '" + contractStatus + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",contractClassId = '" + contractClassId + '\'' +
                    ",isRvdReturn = '" + isRvdReturn + '\'' +
                    ",sortOrder = '" + sortOrder + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    ",codeAndName = '" + codeAndName + '\'' +
                    ",isPremiumReturn = '" + isPremiumReturn + '\'' +
                    "}";
  }
}