package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class InsuredVehicleListItem {

  @SerializedName("alarmSystem")
  private AlarmSystem alarmSystem;

  @SerializedName("cascoTerritory")
  private CascoTerritory cascoTerritory;

  @SerializedName("cascoVehicleUsagePurpose")
  private CascoVehicleUsagePurpose cascoVehicleUsagePurpose;

  @SerializedName("hasFranchise")
  private boolean hasFranchise;

  @SerializedName("cascoVehicleGroup")
  private CascoVehicleGroup cascoVehicleGroup;

  @SerializedName("vehicleUsagePurpose")
  private VehicleUsagePurpose vehicleUsagePurpose;

  @SerializedName("hasAddEquipmentGroup")
  private boolean hasAddEquipmentGroup;

  @SerializedName("registrationMark")
  private String registrationMark;

  @SerializedName("searchSystem")
  private SearchSystem searchSystem;

  @SerializedName("equipmentIsInsured")
  private boolean equipmentIsInsured;

  @SerializedName("regDocumentSeries")
  private String regDocumentSeries;

  @SerializedName("subjectId")
  private String subjectId;

  @SerializedName("vehicleCategoryName")
  private String vehicleCategoryName;

  @SerializedName("limitDamageSum")
  private Object limitDamageSum;

  @SerializedName("premium")
  private int premium;

  @SerializedName("vehicleAlarmList")
  private List<Object> vehicleAlarmList;

  @SerializedName("registrationDate")
  private String registrationDate;

  @SerializedName("trailerUsed")
  private boolean trailerUsed;

  @SerializedName("id")
  private String id;

  @SerializedName("riskObjectGroupList")
  private List<RiskObjectGroupListItem> riskObjectGroupList;

  @SerializedName("serviceCardNumber")
  private String serviceCardNumber;

  @SerializedName("actualCost")
  private int actualCost;

  @SerializedName("cascoInsurTerritory")
  private CascoInsurTerritory cascoInsurTerritory;

  @SerializedName("liability")
  private int liability;

  @SerializedName("regDocType")
  private RegDocType regDocType;

  @SerializedName("hasAccidentGroup")
  private boolean hasAccidentGroup;

  @SerializedName("isNew")
  private boolean isNew;

  @SerializedName("isRent")
  private boolean isRent;

  @SerializedName("equipmentList")
  private List<Object> equipmentList;

  @SerializedName("vehicleMileage")
  private Object vehicleMileage;

  @SerializedName("alarmSystems")
  private String alarmSystems;

  @SerializedName("telematicDevice")
  private TelematicDevice telematicDevice;

  @SerializedName("usagePurposeOther")
  private String usagePurposeOther;

  @SerializedName("isCascoVehicleGroupAutodetected")
  private boolean isCascoVehicleGroupAutodetected;

  @SerializedName("calcPremium")
  private int calcPremium;

  @SerializedName("contractId")
  private String contractId;

  @SerializedName("vehicleRiskRequirements")
  private VehicleRiskRequirements vehicleRiskRequirements;

  @SerializedName("regDocumentNumber")
  private String regDocumentNumber;

  @SerializedName("bid")
  private String bid;

  @SerializedName("hasDsagoGroup")
  private boolean hasDsagoGroup;

  @SerializedName("drivingLimitationType")
  private DrivingLimitationType drivingLimitationType;

  @SerializedName("osagoTerritory")
  private OsagoTerritory osagoTerritory;

  public void setAlarmSystem(AlarmSystem alarmSystem) {
    this.alarmSystem = alarmSystem;
  }

  public AlarmSystem getAlarmSystem() {
    return alarmSystem;
  }

  public void setCascoTerritory(CascoTerritory cascoTerritory) {
    this.cascoTerritory = cascoTerritory;
  }

  public CascoTerritory getCascoTerritory() {
    return cascoTerritory;
  }

  public void setCascoVehicleUsagePurpose(CascoVehicleUsagePurpose cascoVehicleUsagePurpose) {
    this.cascoVehicleUsagePurpose = cascoVehicleUsagePurpose;
  }

  public CascoVehicleUsagePurpose getCascoVehicleUsagePurpose() {
    return cascoVehicleUsagePurpose;
  }

  public void setHasFranchise(boolean hasFranchise) {
    this.hasFranchise = hasFranchise;
  }

  public boolean isHasFranchise() {
    return hasFranchise;
  }

  public void setCascoVehicleGroup(CascoVehicleGroup cascoVehicleGroup) {
    this.cascoVehicleGroup = cascoVehicleGroup;
  }

  public CascoVehicleGroup getCascoVehicleGroup() {
    return cascoVehicleGroup;
  }

  public void setVehicleUsagePurpose(VehicleUsagePurpose vehicleUsagePurpose) {
    this.vehicleUsagePurpose = vehicleUsagePurpose;
  }

  public VehicleUsagePurpose getVehicleUsagePurpose() {
    return vehicleUsagePurpose;
  }

  public void setHasAddEquipmentGroup(boolean hasAddEquipmentGroup) {
    this.hasAddEquipmentGroup = hasAddEquipmentGroup;
  }

  public boolean isHasAddEquipmentGroup() {
    return hasAddEquipmentGroup;
  }

  public void setRegistrationMark(String registrationMark) {
    this.registrationMark = registrationMark;
  }

  public String getRegistrationMark() {
    return registrationMark;
  }

  public void setSearchSystem(SearchSystem searchSystem) {
    this.searchSystem = searchSystem;
  }

  public SearchSystem getSearchSystem() {
    return searchSystem;
  }

  public void setEquipmentIsInsured(boolean equipmentIsInsured) {
    this.equipmentIsInsured = equipmentIsInsured;
  }

  public boolean isEquipmentIsInsured() {
    return equipmentIsInsured;
  }

  public void setRegDocumentSeries(String regDocumentSeries) {
    this.regDocumentSeries = regDocumentSeries;
  }

  public String getRegDocumentSeries() {
    return regDocumentSeries;
  }

  public void setSubjectId(String subjectId) {
    this.subjectId = subjectId;
  }

  public String getSubjectId() {
    return subjectId;
  }

  public void setVehicleCategoryName(String vehicleCategoryName) {
    this.vehicleCategoryName = vehicleCategoryName;
  }

  public String getVehicleCategoryName() {
    return vehicleCategoryName;
  }

  public void setLimitDamageSum(Object limitDamageSum) {
    this.limitDamageSum = limitDamageSum;
  }

  public Object getLimitDamageSum() {
    return limitDamageSum;
  }

  public void setPremium(int premium) {
    this.premium = premium;
  }

  public int getPremium() {
    return premium;
  }

  public void setVehicleAlarmList(List<Object> vehicleAlarmList) {
    this.vehicleAlarmList = vehicleAlarmList;
  }

  public List<Object> getVehicleAlarmList() {
    return vehicleAlarmList;
  }

  public void setRegistrationDate(String registrationDate) {
    this.registrationDate = registrationDate;
  }

  public String getRegistrationDate() {
    return registrationDate;
  }

  public void setTrailerUsed(boolean trailerUsed) {
    this.trailerUsed = trailerUsed;
  }

  public boolean isTrailerUsed() {
    return trailerUsed;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setRiskObjectGroupList(List<RiskObjectGroupListItem> riskObjectGroupList) {
    this.riskObjectGroupList = riskObjectGroupList;
  }

  public List<RiskObjectGroupListItem> getRiskObjectGroupList() {
    return riskObjectGroupList;
  }

  public void setServiceCardNumber(String serviceCardNumber) {
    this.serviceCardNumber = serviceCardNumber;
  }

  public String getServiceCardNumber() {
    return serviceCardNumber;
  }

  public void setActualCost(int actualCost) {
    this.actualCost = actualCost;
  }

  public int getActualCost() {
    return actualCost;
  }

  public void setCascoInsurTerritory(CascoInsurTerritory cascoInsurTerritory) {
    this.cascoInsurTerritory = cascoInsurTerritory;
  }

  public CascoInsurTerritory getCascoInsurTerritory() {
    return cascoInsurTerritory;
  }

  public void setLiability(int liability) {
    this.liability = liability;
  }

  public int getLiability() {
    return liability;
  }

  public void setRegDocType(RegDocType regDocType) {
    this.regDocType = regDocType;
  }

  public RegDocType getRegDocType() {
    return regDocType;
  }

  public void setHasAccidentGroup(boolean hasAccidentGroup) {
    this.hasAccidentGroup = hasAccidentGroup;
  }

  public boolean isHasAccidentGroup() {
    return hasAccidentGroup;
  }

  public void setIsNew(boolean isNew) {
    this.isNew = isNew;
  }

  public boolean isIsNew() {
    return isNew;
  }

  public void setIsRent(boolean isRent) {
    this.isRent = isRent;
  }

  public boolean isIsRent() {
    return isRent;
  }

  public void setEquipmentList(List<Object> equipmentList) {
    this.equipmentList = equipmentList;
  }

  public List<Object> getEquipmentList() {
    return equipmentList;
  }

  public void setVehicleMileage(Object vehicleMileage) {
    this.vehicleMileage = vehicleMileage;
  }

  public Object getVehicleMileage() {
    return vehicleMileage;
  }

  public void setAlarmSystems(String alarmSystems) {
    this.alarmSystems = alarmSystems;
  }

  public String getAlarmSystems() {
    return alarmSystems;
  }

  public void setTelematicDevice(TelematicDevice telematicDevice) {
    this.telematicDevice = telematicDevice;
  }

  public TelematicDevice getTelematicDevice() {
    return telematicDevice;
  }

  public void setUsagePurposeOther(String usagePurposeOther) {
    this.usagePurposeOther = usagePurposeOther;
  }

  public String getUsagePurposeOther() {
    return usagePurposeOther;
  }

  public void setIsCascoVehicleGroupAutodetected(boolean isCascoVehicleGroupAutodetected) {
    this.isCascoVehicleGroupAutodetected = isCascoVehicleGroupAutodetected;
  }

  public boolean isIsCascoVehicleGroupAutodetected() {
    return isCascoVehicleGroupAutodetected;
  }

  public void setCalcPremium(int calcPremium) {
    this.calcPremium = calcPremium;
  }

  public int getCalcPremium() {
    return calcPremium;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getContractId() {
    return contractId;
  }

  public void setVehicleRiskRequirements(VehicleRiskRequirements vehicleRiskRequirements) {
    this.vehicleRiskRequirements = vehicleRiskRequirements;
  }

  public VehicleRiskRequirements getVehicleRiskRequirements() {
    return vehicleRiskRequirements;
  }

  public void setRegDocumentNumber(String regDocumentNumber) {
    this.regDocumentNumber = regDocumentNumber;
  }

  public String getRegDocumentNumber() {
    return regDocumentNumber;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setHasDsagoGroup(boolean hasDsagoGroup) {
    this.hasDsagoGroup = hasDsagoGroup;
  }

  public boolean isHasDsagoGroup() {
    return hasDsagoGroup;
  }

  public void setDrivingLimitationType(DrivingLimitationType drivingLimitationType) {
    this.drivingLimitationType = drivingLimitationType;
  }

  public DrivingLimitationType getDrivingLimitationType() {
    return drivingLimitationType;
  }

  public void setOsagoTerritory(OsagoTerritory osagoTerritory) {
    this.osagoTerritory = osagoTerritory;
  }

  public OsagoTerritory getOsagoTerritory() {
    return osagoTerritory;
  }

  @Override
  public String toString() {
    return
            "InsuredVehicleListItem{" +
                    "alarmSystem = '" + alarmSystem + '\'' +
                    ",cascoTerritory = '" + cascoTerritory + '\'' +
                    ",cascoVehicleUsagePurpose = '" + cascoVehicleUsagePurpose + '\'' +
                    ",hasFranchise = '" + hasFranchise + '\'' +
                    ",cascoVehicleGroup = '" + cascoVehicleGroup + '\'' +
                    ",vehicleUsagePurpose = '" + vehicleUsagePurpose + '\'' +
                    ",hasAddEquipmentGroup = '" + hasAddEquipmentGroup + '\'' +
                    ",registrationMark = '" + registrationMark + '\'' +
                    ",searchSystem = '" + searchSystem + '\'' +
                    ",equipmentIsInsured = '" + equipmentIsInsured + '\'' +
                    ",regDocumentSeries = '" + regDocumentSeries + '\'' +
                    ",subjectId = '" + subjectId + '\'' +
                    ",vehicleCategoryName = '" + vehicleCategoryName + '\'' +
                    ",limitDamageSum = '" + limitDamageSum + '\'' +
                    ",premium = '" + premium + '\'' +
                    ",vehicleAlarmList = '" + vehicleAlarmList + '\'' +
                    ",registrationDate = '" + registrationDate + '\'' +
                    ",trailerUsed = '" + trailerUsed + '\'' +
                    ",id = '" + id + '\'' +
                    ",riskObjectGroupList = '" + riskObjectGroupList + '\'' +
                    ",serviceCardNumber = '" + serviceCardNumber + '\'' +
                    ",actualCost = '" + actualCost + '\'' +
                    ",cascoInsurTerritory = '" + cascoInsurTerritory + '\'' +
                    ",liability = '" + liability + '\'' +
                    ",regDocType = '" + regDocType + '\'' +
                    ",hasAccidentGroup = '" + hasAccidentGroup + '\'' +
                    ",isNew = '" + isNew + '\'' +
                    ",isRent = '" + isRent + '\'' +
                    ",equipmentList = '" + equipmentList + '\'' +
                    ",vehicleMileage = '" + vehicleMileage + '\'' +
                    ",alarmSystems = '" + alarmSystems + '\'' +
                    ",telematicDevice = '" + telematicDevice + '\'' +
                    ",usagePurposeOther = '" + usagePurposeOther + '\'' +
                    ",isCascoVehicleGroupAutodetected = '" + isCascoVehicleGroupAutodetected + '\'' +
                    ",calcPremium = '" + calcPremium + '\'' +
                    ",contractId = '" + contractId + '\'' +
                    ",vehicleRiskRequirements = '" + vehicleRiskRequirements + '\'' +
                    ",regDocumentNumber = '" + regDocumentNumber + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",hasDsagoGroup = '" + hasDsagoGroup + '\'' +
                    ",drivingLimitationType = '" + drivingLimitationType + '\'' +
                    ",osagoTerritory = '" + osagoTerritory + '\'' +
                    "}";
  }
}