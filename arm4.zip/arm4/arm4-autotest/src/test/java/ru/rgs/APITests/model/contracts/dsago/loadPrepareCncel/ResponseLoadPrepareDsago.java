package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ResponseLoadPrepareDsago {

  @SerializedName("success")
  private boolean success;

  @SerializedName("operationResult")
  private OperationResult operationResult;

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setOperationResult(OperationResult operationResult) {
    this.operationResult = operationResult;
  }

  public OperationResult getOperationResult() {
    return operationResult;
  }

  @Override
  public String toString() {
    return
            "ResponseLoadPrepareCancelBox{" +
                    "success = '" + success + '\'' +
                    ",operationResult = '" + operationResult + '\'' +
                    "}";
  }
}