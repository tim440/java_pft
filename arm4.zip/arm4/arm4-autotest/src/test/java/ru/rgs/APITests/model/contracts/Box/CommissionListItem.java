package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class CommissionListItem {

  @SerializedName("riskObjectTypeName")
  private String riskObjectTypeName;

  @SerializedName("agentId")
  private String agentId;

  @SerializedName("isEpsEnabled")
  private String isEpsEnabled;

  @SerializedName("agentListId")
  private String agentListId;

  @SerializedName("commissionSumRur")
  private String commissionSumRur;

  @SerializedName("premiumSumRur")
  private String premiumSumRur;

  @SerializedName("commissionSumRurForecast")
  private String commissionSumRurForecast;

  @SerializedName("isReadOnly")
  private String isReadOnly;

  @SerializedName("rate")
  private String rate;

  @SerializedName("paymentId")
  private String paymentId;

  @SerializedName("isChanged")
  private String isChanged;

  @SerializedName("agentRoleName")
  private String agentRoleName;

  @SerializedName("commissionTypeCode")
  private String commissionTypeCode;

  @SerializedName("agentContractNumber")
  private String agentContractNumber;

  @SerializedName("commissionSum")
  private String commissionSum;

  @SerializedName("commissionDate")
  private String commissionDate;

  @SerializedName("commissionSumForecast")
  private String commissionSumForecast;

  @SerializedName("id")
  private String id;

  @SerializedName("agentPersonalNumber")
  private String agentPersonalNumber;

  @SerializedName("isReserve")
  private String isReserve;

  @SerializedName("agentName")
  private String agentName;

  @SerializedName("agentNumber")
  private String agentNumber;

  @SerializedName("paymentPartId")
  private String paymentPartId;

  @SerializedName("riskObjectTypeId")
  private String riskObjectTypeId;

  @SerializedName("isAdjusted")
  private String isAdjusted;

  @SerializedName("bid")
  private String bid;

  @SerializedName("premiumSum")
  private String premiumSum;

  @SerializedName("commissionTypeName")
  private String commissionTypeName;

  @SerializedName("agentContractId")
  private String agentContractId;

  public void setRiskObjectTypeName(String riskObjectTypeName) {
    this.riskObjectTypeName = riskObjectTypeName;
  }

  public String getRiskObjectTypeName() {
    return riskObjectTypeName;
  }

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setIsEpsEnabled(String isEpsEnabled) {
    this.isEpsEnabled = isEpsEnabled;
  }

  public String getIsEpsEnabled() {
    return isEpsEnabled;
  }

  public void setAgentListId(String agentListId) {
    this.agentListId = agentListId;
  }

  public String getAgentListId() {
    return agentListId;
  }

  public void setCommissionSumRur(String commissionSumRur) {
    this.commissionSumRur = commissionSumRur;
  }

  public String getCommissionSumRur() {
    return commissionSumRur;
  }

  public void setPremiumSumRur(String premiumSumRur) {
    this.premiumSumRur = premiumSumRur;
  }

  public String getPremiumSumRur() {
    return premiumSumRur;
  }

  public void setCommissionSumRurForecast(String commissionSumRurForecast) {
    this.commissionSumRurForecast = commissionSumRurForecast;
  }

  public String getCommissionSumRurForecast() {
    return commissionSumRurForecast;
  }

  public void setIsReadOnly(String isReadOnly) {
    this.isReadOnly = isReadOnly;
  }

  public String getIsReadOnly() {
    return isReadOnly;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public String getRate() {
    return rate;
  }

  public void setPaymentId(String paymentId) {
    this.paymentId = paymentId;
  }

  public String getPaymentId() {
    return paymentId;
  }

  public void setIsChanged(String isChanged) {
    this.isChanged = isChanged;
  }

  public String getIsChanged() {
    return isChanged;
  }

  public void setAgentRoleName(String agentRoleName) {
    this.agentRoleName = agentRoleName;
  }

  public String getAgentRoleName() {
    return agentRoleName;
  }

  public void setCommissionTypeCode(String commissionTypeCode) {
    this.commissionTypeCode = commissionTypeCode;
  }

  public String getCommissionTypeCode() {
    return commissionTypeCode;
  }

  public void setAgentContractNumber(String agentContractNumber) {
    this.agentContractNumber = agentContractNumber;
  }

  public String getAgentContractNumber() {
    return agentContractNumber;
  }

  public void setCommissionSum(String commissionSum) {
    this.commissionSum = commissionSum;
  }

  public String getCommissionSum() {
    return commissionSum;
  }

  public void setCommissionDate(String commissionDate) {
    this.commissionDate = commissionDate;
  }

  public String getCommissionDate() {
    return commissionDate;
  }

  public void setCommissionSumForecast(String commissionSumForecast) {
    this.commissionSumForecast = commissionSumForecast;
  }

  public String getCommissionSumForecast() {
    return commissionSumForecast;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setAgentPersonalNumber(String agentPersonalNumber) {
    this.agentPersonalNumber = agentPersonalNumber;
  }

  public String getAgentPersonalNumber() {
    return agentPersonalNumber;
  }

  public void setIsReserve(String isReserve) {
    this.isReserve = isReserve;
  }

  public String getIsReserve() {
    return isReserve;
  }

  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }

  public String getAgentName() {
    return agentName;
  }

  public void setAgentNumber(String agentNumber) {
    this.agentNumber = agentNumber;
  }

  public String getAgentNumber() {
    return agentNumber;
  }

  public void setPaymentPartId(String paymentPartId) {
    this.paymentPartId = paymentPartId;
  }

  public String getPaymentPartId() {
    return paymentPartId;
  }

  public void setRiskObjectTypeId(String riskObjectTypeId) {
    this.riskObjectTypeId = riskObjectTypeId;
  }

  public String getRiskObjectTypeId() {
    return riskObjectTypeId;
  }

  public void setIsAdjusted(String isAdjusted) {
    this.isAdjusted = isAdjusted;
  }

  public String getIsAdjusted() {
    return isAdjusted;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setPremiumSum(String premiumSum) {
    this.premiumSum = premiumSum;
  }

  public String getPremiumSum() {
    return premiumSum;
  }

  public void setCommissionTypeName(String commissionTypeName) {
    this.commissionTypeName = commissionTypeName;
  }

  public String getCommissionTypeName() {
    return commissionTypeName;
  }

  public void setAgentContractId(String agentContractId) {
    this.agentContractId = agentContractId;
  }

  public String getAgentContractId() {
    return agentContractId;
  }

  @Override
  public String toString() {
    return
            "CommissionListItem{" +
                    "riskObjectTypeName = '" + riskObjectTypeName + '\'' +
                    ",agentId = '" + agentId + '\'' +
                    ",isEpsEnabled = '" + isEpsEnabled + '\'' +
                    ",agentListId = '" + agentListId + '\'' +
                    ",commissionSumRur = '" + commissionSumRur + '\'' +
                    ",premiumSumRur = '" + premiumSumRur + '\'' +
                    ",commissionSumRurForecast = '" + commissionSumRurForecast + '\'' +
                    ",isReadOnly = '" + isReadOnly + '\'' +
                    ",rate = '" + rate + '\'' +
                    ",paymentId = '" + paymentId + '\'' +
                    ",isChanged = '" + isChanged + '\'' +
                    ",agentRoleName = '" + agentRoleName + '\'' +
                    ",commissionTypeCode = '" + commissionTypeCode + '\'' +
                    ",agentContractNumber = '" + agentContractNumber + '\'' +
                    ",commissionSum = '" + commissionSum + '\'' +
                    ",commissionDate = '" + commissionDate + '\'' +
                    ",commissionSumForecast = '" + commissionSumForecast + '\'' +
                    ",id = '" + id + '\'' +
                    ",agentPersonalNumber = '" + agentPersonalNumber + '\'' +
                    ",isReserve = '" + isReserve + '\'' +
                    ",agentName = '" + agentName + '\'' +
                    ",agentNumber = '" + agentNumber + '\'' +
                    ",paymentPartId = '" + paymentPartId + '\'' +
                    ",riskObjectTypeId = '" + riskObjectTypeId + '\'' +
                    ",isAdjusted = '" + isAdjusted + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",premiumSum = '" + premiumSum + '\'' +
                    ",commissionTypeName = '" + commissionTypeName + '\'' +
                    ",agentContractId = '" + agentContractId + '\'' +
                    "}";
  }
}