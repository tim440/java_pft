package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Vehicle {

  @SerializedName("displayName")
  private String displayName;

  @SerializedName("enginePowerHp")
  private String enginePowerHp;

  @SerializedName("subjectType")
  private SubjectType subjectType;

  @SerializedName("modification")
  private Modification modification;

  @SerializedName("isNotVinSpecified")
  private String isNotVinSpecified;

  @SerializedName("enginePowerKw")
  private String enginePowerKw;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("model")
  private Model model;

  @SerializedName("vin")
  private String vin;

  @SerializedName("id")
  private String id;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("bid")
  private String bid;

  @SerializedName("brand")
  private Brand brand;

  @SerializedName("vehicleType")
  private VehicleType vehicleType;

  @SerializedName("constructionDate")
  private String constructionDate;

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setEnginePowerHp(String enginePowerHp) {
    this.enginePowerHp = enginePowerHp;
  }

  public String getEnginePowerHp() {
    return enginePowerHp;
  }

  public void setSubjectType(SubjectType subjectType) {
    this.subjectType = subjectType;
  }

  public SubjectType getSubjectType() {
    return subjectType;
  }

  public void setModification(Modification modification) {
    this.modification = modification;
  }

  public Modification getModification() {
    return modification;
  }

  public void setIsNotVinSpecified(String isNotVinSpecified) {
    this.isNotVinSpecified = isNotVinSpecified;
  }

  public String getIsNotVinSpecified() {
    return isNotVinSpecified;
  }

  public void setEnginePowerKw(String enginePowerKw) {
    this.enginePowerKw = enginePowerKw;
  }

  public String getEnginePowerKw() {
    return enginePowerKw;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setModel(Model model) {
    this.model = model;
  }

  public Model getModel() {
    return model;
  }

  public void setVin(String vin) {
    this.vin = vin;
  }

  public String getVin() {
    return vin;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setBrand(Brand brand) {
    this.brand = brand;
  }

  public Brand getBrand() {
    return brand;
  }

  public void setVehicleType(VehicleType vehicleType) {
    this.vehicleType = vehicleType;
  }

  public VehicleType getVehicleType() {
    return vehicleType;
  }

  public void setConstructionDate(String constructionDate) {
    this.constructionDate = constructionDate;
  }

  public String getConstructionDate() {
    return constructionDate;
  }

  @Override
  public String toString() {
    return
            "Vehicle{" +
                    "displayName = '" + displayName + '\'' +
                    ",enginePowerHp = '" + enginePowerHp + '\'' +
                    ",subjectType = '" + subjectType + '\'' +
                    ",modification = '" + modification + '\'' +
                    ",isNotVinSpecified = '" + isNotVinSpecified + '\'' +
                    ",enginePowerKw = '" + enginePowerKw + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",model = '" + model + '\'' +
                    ",vin = '" + vin + '\'' +
                    ",id = '" + id + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",brand = '" + brand + '\'' +
                    ",vehicleType = '" + vehicleType + '\'' +
                    ",constructionDate = '" + constructionDate + '\'' +
                    "}";
  }
}