package ru.rgs.APITests.model.contracts.dsago.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class HoldingCompany{

	@SerializedName("displayName")
	private String displayName;

	public void setDisplayName(String displayName){
		this.displayName = displayName;
	}

	public String getDisplayName(){
		return displayName;
	}

	@Override
 	public String toString(){
		return 
			"HoldingCompany{" + 
			"displayName = '" + displayName + '\'' + 
			"}";
		}
}