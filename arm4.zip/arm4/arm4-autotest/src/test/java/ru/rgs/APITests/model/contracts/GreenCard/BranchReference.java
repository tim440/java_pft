package ru.rgs.APITests.model.contracts.GreenCard;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class BranchReference {

  @SerializedName("displayName")
  private String displayName;

  @SerializedName("id")
  private String id;

  @SerializedName("bid")
  private String bid;

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  @Override
  public String toString() {
    return
            "BranchReference{" +
                    "displayName = '" + displayName + '\'' +
                    ",id = '" + id + '\'' +
                    ",bid = '" + bid + '\'' +
                    "}";
  }
}