package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class ResponseKasco {

  @SerializedName("contractType")
  private ContractType contractType;

  @SerializedName("coInsuranceRole")
  private CoInsuranceRole coInsuranceRole;

  @SerializedName("premiumRate")
  private PremiumRate premiumRate;

  @SerializedName("removedChangeId")
  private String removedChangeId;

  @SerializedName("program")
  private Program program;

  @SerializedName("branch")
  private Branch branch;

  @SerializedName("parentContractOption")
  private ParentContractOption parentContractOption;

  @SerializedName("sapContractId")
  private String sapContractId;

  @SerializedName("validationLogList")
  private List<Object> validationLogList;

  @SerializedName("number")
  private String number;

  @SerializedName("currentContractChange")
  private CurrentContractChange currentContractChange;

  @SerializedName("paymentScheduleType")
  private PaymentScheduleType paymentScheduleType;

  @SerializedName("autoDealer")
  private AutoDealer autoDealer;

  @SerializedName("prevContractPayedCount")
  private String prevContractPayedCount;

  @SerializedName("financialUnit")
  private FinancialUnit financialUnit;

  @SerializedName("isCurrencyEquivalent")
  private boolean isCurrencyEquivalent;

  @SerializedName("id")
  private String id;

  @SerializedName("otherPartner")
  private OtherPartner otherPartner;

  @SerializedName("isReceivedPrimaryDoc")
  private boolean isReceivedPrimaryDoc;

  @SerializedName("privilegedProlongation")
  private boolean privilegedProlongation;

  @SerializedName("beneficiarList")
  private List<BeneficiarListItem> beneficiarList;

  @SerializedName("premiumChargeType")
  private PremiumChargeType premiumChargeType;

  @SerializedName("agreementList")
  private List<Object> agreementList;

  @SerializedName("insurerPersonTypeCode")
  private String insurerPersonTypeCode;

  @SerializedName("blankChangeReasonDto")
  private String blankChangeReasonDto;

  @SerializedName("isExtPrefProlong")
  private Object isExtPrefProlong;

  @SerializedName("creationType")
  private CreationType creationType;

  @SerializedName("vehicleCount")
  private int vehicleCount;

  @SerializedName("saleChannel")
  private SaleChannel saleChannel;

  @SerializedName("coInsuranceCompany")
  private CoInsuranceCompany coInsuranceCompany;

  @SerializedName("insuranceByFirstRisk")
  private String insuranceByFirstRisk;

  @SerializedName("status")
  private Status status;

  @SerializedName("noBlank")
  private boolean noBlank;

  @SerializedName("isCoInsurance")
  private boolean isCoInsurance;

  @SerializedName("agentStatementNumber")
  private String agentStatementNumber;

  @SerializedName("debitWriteOffReason")
  private DebitWriteOffReason debitWriteOffReason;

  @SerializedName("isFranchiseInsteadCoeff")
  private boolean isFranchiseInsteadCoeff;

  @SerializedName("sapNotMigratedStatementNumberList")
  private String sapNotMigratedStatementNumberList;

  @SerializedName("premium")
  private int premium;

  @SerializedName("insurer")
  private Insurer insurer;

  @SerializedName("insBridgeParamHash")
  private String insBridgeParamHash;

  @SerializedName("liabilityEndDate")
  private String liabilityEndDate;

  @SerializedName("currency")
  private Currency currency;

  @SerializedName("useNewCascoDate")
  private String useNewCascoDate;

  @SerializedName("cancelReason")
  private CancelReason cancelReason;

  @SerializedName("product")
  private Product product;

  @SerializedName("isStateProcurement")
  private boolean isStateProcurement;

  @SerializedName("parentId")
  private String parentId;

  @SerializedName("insurerId")
  private String insurerId;

  @SerializedName("agentStatementId")
  private String agentStatementId;

  @SerializedName("agentStatementDate")
  private String agentStatementDate;

  @SerializedName("series")
  private String series;

  @SerializedName("insBridgeActivationDate")
  private String insBridgeActivationDate;

  @SerializedName("coInsuranceTotalPremium")
  private int coInsuranceTotalPremium;

  @SerializedName("paymentScheduleList")
  private List<PaymentScheduleListItem> paymentScheduleList;

  @SerializedName("payedSum")
  private int payedSum;

  @SerializedName("previousInsuranceCompany")
  private PreviousInsuranceCompany previousInsuranceCompany;

  @SerializedName("isQuoteApproved")
  private boolean isQuoteApproved;

  @SerializedName("previousContractNumber")
  private String previousContractNumber;

  @SerializedName("contractDate")
  private String contractDate;

  @SerializedName("agentRoleList")
  private List<Object> agentRoleList;

  @SerializedName("contractChangeList")
  private String contractChangeList;

  @SerializedName("claimReturnList")
  private List<Object> claimReturnList;

  @SerializedName("coInsuranceStartDate")
  private String coInsuranceStartDate;

  @SerializedName("project")
  private Project project;

  @SerializedName("office")
  private Office office;

  @SerializedName("prevContractPayedSum")
  private int prevContractPayedSum;

  @SerializedName("insuranceActNumber")
  private String insuranceActNumber;

  @SerializedName("commissionList")
  private String commissionList;

  @SerializedName("driverList")
  private List<Object> driverList;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("sysCreator")
  private String sysCreator;

  @SerializedName("contractTypeClass")
  private ContractTypeClass contractTypeClass;

  @SerializedName("statementStatusCode")
  private String statementStatusCode;

  @SerializedName("sector")
  private Sector sector;

  @SerializedName("untypicalContractNumber")
  private String untypicalContractNumber;

  @SerializedName("contractCheckInfo")
  private String contractCheckInfo;

  @SerializedName("contractStartDate")
  private String contractStartDate;

  @SerializedName("insurerSysEditor")
  private String insurerSysEditor;

  @SerializedName("leasingCompany")
  private LeasingCompany leasingCompany;

  @SerializedName("isActivateAgentFromAnotherBranch")
  private boolean isActivateAgentFromAnotherBranch;

  @SerializedName("agentName")
  private String agentName;

  @SerializedName("debitWriteOffDate")
  private Object debitWriteOffDate;

  @SerializedName("isReinsure")
  private boolean isReinsure;

  @SerializedName("insurerHasCellPhone")
  private boolean insurerHasCellPhone;

  @SerializedName("productVariant")
  private ProductVariant productVariant;

  @SerializedName("isEmptySourceCheckSum")
  private boolean isEmptySourceCheckSum;

  @SerializedName("underwriterName")
  private String underwriterName;

  @SerializedName("premiumCalcDate")
  private Object premiumCalcDate;

  @SerializedName("isCoInsuranceLeaderPayType")
  private Object isCoInsuranceLeaderPayType;

  @SerializedName("paymentMethod")
  private PaymentMethod paymentMethod;

  @SerializedName("checkSum")
  private String checkSum;

  @SerializedName("lastModified")
  private Object lastModified;

  @SerializedName("bankIntermediary")
  private BankIntermediary bankIntermediary;

  @SerializedName("claimReturnSum")
  private int claimReturnSum;

  @SerializedName("sapMigrationReasonCode")
  private String sapMigrationReasonCode;

  @SerializedName("agentId")
  private String agentId;

  @SerializedName("cancelDate")
  private Object cancelDate;

  @SerializedName("securityName")
  private String securityName;

  @SerializedName("stateProcurementStartDate")
  private String stateProcurementStartDate;

  @SerializedName("existActiveAsyncRequest")
  private boolean existActiveAsyncRequest;

  @SerializedName("previousPremium")
  private int previousPremium;

  @SerializedName("liabilityStartDate")
  private String liabilityStartDate;

  @SerializedName("liabilityType")
  private LiabilityType liabilityType;

  @SerializedName("factAccruedPremiumDateStartDate")
  private String factAccruedPremiumDateStartDate;

  @SerializedName("saleGroup")
  private SaleGroup saleGroup;

  @SerializedName("reinsureStartDate")
  private String reinsureStartDate;

  @SerializedName("insuredVehicleList")
  private List<InsuredVehicleListItem> insuredVehicleList;

  @SerializedName("factAccruedPremium")
  private int factAccruedPremium;

  @SerializedName("agentList")
  private List<Object> agentList;

  @SerializedName("department")
  private Department department;

  @SerializedName("activeAgentRolesDate")
  private Object activeAgentRolesDate;

  @SerializedName("scoringFormNumber")
  private String scoringFormNumber;

  @SerializedName("insurerChangeId")
  private String insurerChangeId;

  @SerializedName("quoteDate")
  private String quoteDate;

  @SerializedName("likardData")
  private LikardData likardData;

  @SerializedName("comments")
  private String comments;

  @SerializedName("contractOption")
  private ContractOption contractOption;

  @SerializedName("exceedsTariff")
  private boolean exceedsTariff;

  @SerializedName("contractEndDate")
  private String contractEndDate;

  @SerializedName("cancelStatementDate")
  private Object cancelStatementDate;

  @SerializedName("requestSource")
  private RequestSource requestSource;

  @SerializedName("smsSubscription")
  private Object smsSubscription;

  @SerializedName("insurerName")
  private String insurerName;

  @SerializedName("paymentList")
  private List<Object> paymentList;

  @SerializedName("contractTypeClassStartDate")
  private String contractTypeClassStartDate;

  @SerializedName("blankDto")
  private BlankDto blankDto;

  @SerializedName("premiumRur")
  private int premiumRur;

  @SerializedName("canPayWithoutDoc")
  private boolean canPayWithoutDoc;

  @SerializedName("reservationValueList")
  private List<Object> reservationValueList;

  @SerializedName("entityPurpose")
  private String entityPurpose;

  @SerializedName("liabilitySum")
  private int liabilitySum;

  @SerializedName("calculatedPremium")
  private int calculatedPremium;

  @SerializedName("isPledgedProperty")
  private boolean isPledgedProperty;

  @SerializedName("isProcessPersInfo")
  private boolean isProcessPersInfo;

  @SerializedName("personLinkList")
  private List<Object> personLinkList;

  @SerializedName("previousContractSeries")
  private String previousContractSeries;

  @SerializedName("isProcessPersInfoEmpty")
  private boolean isProcessPersInfoEmpty;

  public void setContractType(ContractType contractType) {
    this.contractType = contractType;
  }

  public ContractType getContractType() {
    return contractType;
  }

  public void setCoInsuranceRole(CoInsuranceRole coInsuranceRole) {
    this.coInsuranceRole = coInsuranceRole;
  }

  public CoInsuranceRole getCoInsuranceRole() {
    return coInsuranceRole;
  }

  public void setPremiumRate(PremiumRate premiumRate) {
    this.premiumRate = premiumRate;
  }

  public PremiumRate getPremiumRate() {
    return premiumRate;
  }

  public void setRemovedChangeId(String removedChangeId) {
    this.removedChangeId = removedChangeId;
  }

  public String getRemovedChangeId() {
    return removedChangeId;
  }

  public void setProgram(Program program) {
    this.program = program;
  }

  public Program getProgram() {
    return program;
  }

  public void setBranch(Branch branch) {
    this.branch = branch;
  }

  public Branch getBranch() {
    return branch;
  }

  public void setParentContractOption(ParentContractOption parentContractOption) {
    this.parentContractOption = parentContractOption;
  }

  public ParentContractOption getParentContractOption() {
    return parentContractOption;
  }

  public void setSapContractId(String sapContractId) {
    this.sapContractId = sapContractId;
  }

  public String getSapContractId() {
    return sapContractId;
  }

  public void setValidationLogList(List<Object> validationLogList) {
    this.validationLogList = validationLogList;
  }

  public List<Object> getValidationLogList() {
    return validationLogList;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getNumber() {
    return number;
  }

  public void setCurrentContractChange(CurrentContractChange currentContractChange) {
    this.currentContractChange = currentContractChange;
  }

  public CurrentContractChange getCurrentContractChange() {
    return currentContractChange;
  }

  public void setPaymentScheduleType(PaymentScheduleType paymentScheduleType) {
    this.paymentScheduleType = paymentScheduleType;
  }

  public PaymentScheduleType getPaymentScheduleType() {
    return paymentScheduleType;
  }

  public void setAutoDealer(AutoDealer autoDealer) {
    this.autoDealer = autoDealer;
  }

  public AutoDealer getAutoDealer() {
    return autoDealer;
  }

  public void setPrevContractPayedCount(String prevContractPayedCount) {
    this.prevContractPayedCount = prevContractPayedCount;
  }

  public String getPrevContractPayedCount() {
    return prevContractPayedCount;
  }

  public void setFinancialUnit(FinancialUnit financialUnit) {
    this.financialUnit = financialUnit;
  }

  public FinancialUnit getFinancialUnit() {
    return financialUnit;
  }

  public void setIsCurrencyEquivalent(boolean isCurrencyEquivalent) {
    this.isCurrencyEquivalent = isCurrencyEquivalent;
  }

  public boolean isIsCurrencyEquivalent() {
    return isCurrencyEquivalent;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setOtherPartner(OtherPartner otherPartner) {
    this.otherPartner = otherPartner;
  }

  public OtherPartner getOtherPartner() {
    return otherPartner;
  }

  public void setIsReceivedPrimaryDoc(boolean isReceivedPrimaryDoc) {
    this.isReceivedPrimaryDoc = isReceivedPrimaryDoc;
  }

  public boolean isIsReceivedPrimaryDoc() {
    return isReceivedPrimaryDoc;
  }

  public void setPrivilegedProlongation(boolean privilegedProlongation) {
    this.privilegedProlongation = privilegedProlongation;
  }

  public boolean isPrivilegedProlongation() {
    return privilegedProlongation;
  }

  public void setBeneficiarList(List<BeneficiarListItem> beneficiarList) {
    this.beneficiarList = beneficiarList;
  }

  public List<BeneficiarListItem> getBeneficiarList() {
    return beneficiarList;
  }

  public void setPremiumChargeType(PremiumChargeType premiumChargeType) {
    this.premiumChargeType = premiumChargeType;
  }

  public PremiumChargeType getPremiumChargeType() {
    return premiumChargeType;
  }

  public void setAgreementList(List<Object> agreementList) {
    this.agreementList = agreementList;
  }

  public List<Object> getAgreementList() {
    return agreementList;
  }

  public void setInsurerPersonTypeCode(String insurerPersonTypeCode) {
    this.insurerPersonTypeCode = insurerPersonTypeCode;
  }

  public String getInsurerPersonTypeCode() {
    return insurerPersonTypeCode;
  }

  public void setBlankChangeReasonDto(String blankChangeReasonDto) {
    this.blankChangeReasonDto = blankChangeReasonDto;
  }

  public String getBlankChangeReasonDto() {
    return blankChangeReasonDto;
  }

  public void setIsExtPrefProlong(Object isExtPrefProlong) {
    this.isExtPrefProlong = isExtPrefProlong;
  }

  public Object getIsExtPrefProlong() {
    return isExtPrefProlong;
  }

  public void setCreationType(CreationType creationType) {
    this.creationType = creationType;
  }

  public CreationType getCreationType() {
    return creationType;
  }

  public void setVehicleCount(int vehicleCount) {
    this.vehicleCount = vehicleCount;
  }

  public int getVehicleCount() {
    return vehicleCount;
  }

  public void setSaleChannel(SaleChannel saleChannel) {
    this.saleChannel = saleChannel;
  }

  public SaleChannel getSaleChannel() {
    return saleChannel;
  }

  public void setCoInsuranceCompany(CoInsuranceCompany coInsuranceCompany) {
    this.coInsuranceCompany = coInsuranceCompany;
  }

  public CoInsuranceCompany getCoInsuranceCompany() {
    return coInsuranceCompany;
  }

  public void setInsuranceByFirstRisk(String insuranceByFirstRisk) {
    this.insuranceByFirstRisk = insuranceByFirstRisk;
  }

  public String getInsuranceByFirstRisk() {
    return insuranceByFirstRisk;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public Status getStatus() {
    return status;
  }

  public void setNoBlank(boolean noBlank) {
    this.noBlank = noBlank;
  }

  public boolean isNoBlank() {
    return noBlank;
  }

  public void setIsCoInsurance(boolean isCoInsurance) {
    this.isCoInsurance = isCoInsurance;
  }

  public boolean isIsCoInsurance() {
    return isCoInsurance;
  }

  public void setAgentStatementNumber(String agentStatementNumber) {
    this.agentStatementNumber = agentStatementNumber;
  }

  public String getAgentStatementNumber() {
    return agentStatementNumber;
  }

  public void setDebitWriteOffReason(DebitWriteOffReason debitWriteOffReason) {
    this.debitWriteOffReason = debitWriteOffReason;
  }

  public DebitWriteOffReason getDebitWriteOffReason() {
    return debitWriteOffReason;
  }

  public void setIsFranchiseInsteadCoeff(boolean isFranchiseInsteadCoeff) {
    this.isFranchiseInsteadCoeff = isFranchiseInsteadCoeff;
  }

  public boolean isIsFranchiseInsteadCoeff() {
    return isFranchiseInsteadCoeff;
  }

  public void setSapNotMigratedStatementNumberList(String sapNotMigratedStatementNumberList) {
    this.sapNotMigratedStatementNumberList = sapNotMigratedStatementNumberList;
  }

  public String getSapNotMigratedStatementNumberList() {
    return sapNotMigratedStatementNumberList;
  }

  public void setPremium(int premium) {
    this.premium = premium;
  }

  public int getPremium() {
    return premium;
  }

  public void setInsurer(Insurer insurer) {
    this.insurer = insurer;
  }

  public Insurer getInsurer() {
    return insurer;
  }

  public void setInsBridgeParamHash(String insBridgeParamHash) {
    this.insBridgeParamHash = insBridgeParamHash;
  }

  public String getInsBridgeParamHash() {
    return insBridgeParamHash;
  }

  public void setLiabilityEndDate(String liabilityEndDate) {
    this.liabilityEndDate = liabilityEndDate;
  }

  public String getLiabilityEndDate() {
    return liabilityEndDate;
  }

  public void setCurrency(Currency currency) {
    this.currency = currency;
  }

  public Currency getCurrency() {
    return currency;
  }

  public void setUseNewCascoDate(String useNewCascoDate) {
    this.useNewCascoDate = useNewCascoDate;
  }

  public String getUseNewCascoDate() {
    return useNewCascoDate;
  }

  public void setCancelReason(CancelReason cancelReason) {
    this.cancelReason = cancelReason;
  }

  public CancelReason getCancelReason() {
    return cancelReason;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public Product getProduct() {
    return product;
  }

  public void setIsStateProcurement(boolean isStateProcurement) {
    this.isStateProcurement = isStateProcurement;
  }

  public boolean isIsStateProcurement() {
    return isStateProcurement;
  }

  public void setParentId(String parentId) {
    this.parentId = parentId;
  }

  public String getParentId() {
    return parentId;
  }

  public void setInsurerId(String insurerId) {
    this.insurerId = insurerId;
  }

  public String getInsurerId() {
    return insurerId;
  }

  public void setAgentStatementId(String agentStatementId) {
    this.agentStatementId = agentStatementId;
  }

  public String getAgentStatementId() {
    return agentStatementId;
  }

  public void setAgentStatementDate(String agentStatementDate) {
    this.agentStatementDate = agentStatementDate;
  }

  public String getAgentStatementDate() {
    return agentStatementDate;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public String getSeries() {
    return series;
  }

  public void setInsBridgeActivationDate(String insBridgeActivationDate) {
    this.insBridgeActivationDate = insBridgeActivationDate;
  }

  public String getInsBridgeActivationDate() {
    return insBridgeActivationDate;
  }

  public void setCoInsuranceTotalPremium(int coInsuranceTotalPremium) {
    this.coInsuranceTotalPremium = coInsuranceTotalPremium;
  }

  public int getCoInsuranceTotalPremium() {
    return coInsuranceTotalPremium;
  }

  public void setPaymentScheduleList(List<PaymentScheduleListItem> paymentScheduleList) {
    this.paymentScheduleList = paymentScheduleList;
  }

  public List<PaymentScheduleListItem> getPaymentScheduleList() {
    return paymentScheduleList;
  }

  public void setPayedSum(int payedSum) {
    this.payedSum = payedSum;
  }

  public int getPayedSum() {
    return payedSum;
  }

  public void setPreviousInsuranceCompany(PreviousInsuranceCompany previousInsuranceCompany) {
    this.previousInsuranceCompany = previousInsuranceCompany;
  }

  public PreviousInsuranceCompany getPreviousInsuranceCompany() {
    return previousInsuranceCompany;
  }

  public void setIsQuoteApproved(boolean isQuoteApproved) {
    this.isQuoteApproved = isQuoteApproved;
  }

  public boolean isIsQuoteApproved() {
    return isQuoteApproved;
  }

  public void setPreviousContractNumber(String previousContractNumber) {
    this.previousContractNumber = previousContractNumber;
  }

  public String getPreviousContractNumber() {
    return previousContractNumber;
  }

  public void setContractDate(String contractDate) {
    this.contractDate = contractDate;
  }

  public String getContractDate() {
    return contractDate;
  }

  public void setAgentRoleList(List<Object> agentRoleList) {
    this.agentRoleList = agentRoleList;
  }

  public List<Object> getAgentRoleList() {
    return agentRoleList;
  }

  public void setContractChangeList(String contractChangeList) {
    this.contractChangeList = contractChangeList;
  }

  public String getContractChangeList() {
    return contractChangeList;
  }

  public void setClaimReturnList(List<Object> claimReturnList) {
    this.claimReturnList = claimReturnList;
  }

  public List<Object> getClaimReturnList() {
    return claimReturnList;
  }

  public void setCoInsuranceStartDate(String coInsuranceStartDate) {
    this.coInsuranceStartDate = coInsuranceStartDate;
  }

  public String getCoInsuranceStartDate() {
    return coInsuranceStartDate;
  }

  public void setProject(Project project) {
    this.project = project;
  }

  public Project getProject() {
    return project;
  }

  public void setOffice(Office office) {
    this.office = office;
  }

  public Office getOffice() {
    return office;
  }

  public void setPrevContractPayedSum(int prevContractPayedSum) {
    this.prevContractPayedSum = prevContractPayedSum;
  }

  public int getPrevContractPayedSum() {
    return prevContractPayedSum;
  }

  public void setInsuranceActNumber(String insuranceActNumber) {
    this.insuranceActNumber = insuranceActNumber;
  }

  public String getInsuranceActNumber() {
    return insuranceActNumber;
  }

  public void setCommissionList(String commissionList) {
    this.commissionList = commissionList;
  }

  public String getCommissionList() {
    return commissionList;
  }

  public void setDriverList(List<Object> driverList) {
    this.driverList = driverList;
  }

  public List<Object> getDriverList() {
    return driverList;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setSysCreator(String sysCreator) {
    this.sysCreator = sysCreator;
  }

  public String getSysCreator() {
    return sysCreator;
  }

  public void setContractTypeClass(ContractTypeClass contractTypeClass) {
    this.contractTypeClass = contractTypeClass;
  }

  public ContractTypeClass getContractTypeClass() {
    return contractTypeClass;
  }

  public void setStatementStatusCode(String statementStatusCode) {
    this.statementStatusCode = statementStatusCode;
  }

  public String getStatementStatusCode() {
    return statementStatusCode;
  }

  public void setSector(Sector sector) {
    this.sector = sector;
  }

  public Sector getSector() {
    return sector;
  }

  public void setUntypicalContractNumber(String untypicalContractNumber) {
    this.untypicalContractNumber = untypicalContractNumber;
  }

  public String getUntypicalContractNumber() {
    return untypicalContractNumber;
  }

  public void setContractCheckInfo(String contractCheckInfo) {
    this.contractCheckInfo = contractCheckInfo;
  }

  public String getContractCheckInfo() {
    return contractCheckInfo;
  }

  public void setContractStartDate(String contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  public String getContractStartDate() {
    return contractStartDate;
  }

  public void setInsurerSysEditor(String insurerSysEditor) {
    this.insurerSysEditor = insurerSysEditor;
  }

  public String getInsurerSysEditor() {
    return insurerSysEditor;
  }

  public void setLeasingCompany(LeasingCompany leasingCompany) {
    this.leasingCompany = leasingCompany;
  }

  public LeasingCompany getLeasingCompany() {
    return leasingCompany;
  }

  public void setIsActivateAgentFromAnotherBranch(boolean isActivateAgentFromAnotherBranch) {
    this.isActivateAgentFromAnotherBranch = isActivateAgentFromAnotherBranch;
  }

  public boolean isIsActivateAgentFromAnotherBranch() {
    return isActivateAgentFromAnotherBranch;
  }

  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }

  public String getAgentName() {
    return agentName;
  }

  public void setDebitWriteOffDate(Object debitWriteOffDate) {
    this.debitWriteOffDate = debitWriteOffDate;
  }

  public Object getDebitWriteOffDate() {
    return debitWriteOffDate;
  }

  public void setIsReinsure(boolean isReinsure) {
    this.isReinsure = isReinsure;
  }

  public boolean isIsReinsure() {
    return isReinsure;
  }

  public void setInsurerHasCellPhone(boolean insurerHasCellPhone) {
    this.insurerHasCellPhone = insurerHasCellPhone;
  }

  public boolean isInsurerHasCellPhone() {
    return insurerHasCellPhone;
  }

  public void setProductVariant(ProductVariant productVariant) {
    this.productVariant = productVariant;
  }

  public ProductVariant getProductVariant() {
    return productVariant;
  }

  public void setIsEmptySourceCheckSum(boolean isEmptySourceCheckSum) {
    this.isEmptySourceCheckSum = isEmptySourceCheckSum;
  }

  public boolean isIsEmptySourceCheckSum() {
    return isEmptySourceCheckSum;
  }

  public void setUnderwriterName(String underwriterName) {
    this.underwriterName = underwriterName;
  }

  public String getUnderwriterName() {
    return underwriterName;
  }

  public void setPremiumCalcDate(Object premiumCalcDate) {
    this.premiumCalcDate = premiumCalcDate;
  }

  public Object getPremiumCalcDate() {
    return premiumCalcDate;
  }

  public void setIsCoInsuranceLeaderPayType(Object isCoInsuranceLeaderPayType) {
    this.isCoInsuranceLeaderPayType = isCoInsuranceLeaderPayType;
  }

  public Object getIsCoInsuranceLeaderPayType() {
    return isCoInsuranceLeaderPayType;
  }

  public void setPaymentMethod(PaymentMethod paymentMethod) {
    this.paymentMethod = paymentMethod;
  }

  public PaymentMethod getPaymentMethod() {
    return paymentMethod;
  }

  public void setCheckSum(String checkSum) {
    this.checkSum = checkSum;
  }

  public String getCheckSum() {
    return checkSum;
  }

  public void setLastModified(Object lastModified) {
    this.lastModified = lastModified;
  }

  public Object getLastModified() {
    return lastModified;
  }

  public void setBankIntermediary(BankIntermediary bankIntermediary) {
    this.bankIntermediary = bankIntermediary;
  }

  public BankIntermediary getBankIntermediary() {
    return bankIntermediary;
  }

  public void setClaimReturnSum(int claimReturnSum) {
    this.claimReturnSum = claimReturnSum;
  }

  public int getClaimReturnSum() {
    return claimReturnSum;
  }

  public void setSapMigrationReasonCode(String sapMigrationReasonCode) {
    this.sapMigrationReasonCode = sapMigrationReasonCode;
  }

  public String getSapMigrationReasonCode() {
    return sapMigrationReasonCode;
  }

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setCancelDate(Object cancelDate) {
    this.cancelDate = cancelDate;
  }

  public Object getCancelDate() {
    return cancelDate;
  }

  public void setSecurityName(String securityName) {
    this.securityName = securityName;
  }

  public String getSecurityName() {
    return securityName;
  }

  public void setStateProcurementStartDate(String stateProcurementStartDate) {
    this.stateProcurementStartDate = stateProcurementStartDate;
  }

  public String getStateProcurementStartDate() {
    return stateProcurementStartDate;
  }

  public void setExistActiveAsyncRequest(boolean existActiveAsyncRequest) {
    this.existActiveAsyncRequest = existActiveAsyncRequest;
  }

  public boolean isExistActiveAsyncRequest() {
    return existActiveAsyncRequest;
  }

  public void setPreviousPremium(int previousPremium) {
    this.previousPremium = previousPremium;
  }

  public int getPreviousPremium() {
    return previousPremium;
  }

  public void setLiabilityStartDate(String liabilityStartDate) {
    this.liabilityStartDate = liabilityStartDate;
  }

  public String getLiabilityStartDate() {
    return liabilityStartDate;
  }

  public void setLiabilityType(LiabilityType liabilityType) {
    this.liabilityType = liabilityType;
  }

  public LiabilityType getLiabilityType() {
    return liabilityType;
  }

  public void setFactAccruedPremiumDateStartDate(String factAccruedPremiumDateStartDate) {
    this.factAccruedPremiumDateStartDate = factAccruedPremiumDateStartDate;
  }

  public String getFactAccruedPremiumDateStartDate() {
    return factAccruedPremiumDateStartDate;
  }

  public void setSaleGroup(SaleGroup saleGroup) {
    this.saleGroup = saleGroup;
  }

  public SaleGroup getSaleGroup() {
    return saleGroup;
  }

  public void setReinsureStartDate(String reinsureStartDate) {
    this.reinsureStartDate = reinsureStartDate;
  }

  public String getReinsureStartDate() {
    return reinsureStartDate;
  }

  public void setInsuredVehicleList(List<InsuredVehicleListItem> insuredVehicleList) {
    this.insuredVehicleList = insuredVehicleList;
  }

  public List<InsuredVehicleListItem> getInsuredVehicleList() {
    return insuredVehicleList;
  }

  public void setFactAccruedPremium(int factAccruedPremium) {
    this.factAccruedPremium = factAccruedPremium;
  }

  public int getFactAccruedPremium() {
    return factAccruedPremium;
  }

  public void setAgentList(List<Object> agentList) {
    this.agentList = agentList;
  }

  public List<Object> getAgentList() {
    return agentList;
  }

  public void setDepartment(Department department) {
    this.department = department;
  }

  public Department getDepartment() {
    return department;
  }

  public void setActiveAgentRolesDate(Object activeAgentRolesDate) {
    this.activeAgentRolesDate = activeAgentRolesDate;
  }

  public Object getActiveAgentRolesDate() {
    return activeAgentRolesDate;
  }

  public void setScoringFormNumber(String scoringFormNumber) {
    this.scoringFormNumber = scoringFormNumber;
  }

  public String getScoringFormNumber() {
    return scoringFormNumber;
  }

  public void setInsurerChangeId(String insurerChangeId) {
    this.insurerChangeId = insurerChangeId;
  }

  public String getInsurerChangeId() {
    return insurerChangeId;
  }

  public void setQuoteDate(String quoteDate) {
    this.quoteDate = quoteDate;
  }

  public String getQuoteDate() {
    return quoteDate;
  }

  public void setLikardData(LikardData likardData) {
    this.likardData = likardData;
  }

  public LikardData getLikardData() {
    return likardData;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public String getComments() {
    return comments;
  }

  public void setContractOption(ContractOption contractOption) {
    this.contractOption = contractOption;
  }

  public ContractOption getContractOption() {
    return contractOption;
  }

  public void setExceedsTariff(boolean exceedsTariff) {
    this.exceedsTariff = exceedsTariff;
  }

  public boolean isExceedsTariff() {
    return exceedsTariff;
  }

  public void setContractEndDate(String contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  public String getContractEndDate() {
    return contractEndDate;
  }

  public void setCancelStatementDate(Object cancelStatementDate) {
    this.cancelStatementDate = cancelStatementDate;
  }

  public Object getCancelStatementDate() {
    return cancelStatementDate;
  }

  public void setRequestSource(RequestSource requestSource) {
    this.requestSource = requestSource;
  }

  public RequestSource getRequestSource() {
    return requestSource;
  }

  public void setSmsSubscription(Object smsSubscription) {
    this.smsSubscription = smsSubscription;
  }

  public Object getSmsSubscription() {
    return smsSubscription;
  }

  public void setInsurerName(String insurerName) {
    this.insurerName = insurerName;
  }

  public String getInsurerName() {
    return insurerName;
  }

  public void setPaymentList(List<Object> paymentList) {
    this.paymentList = paymentList;
  }

  public List<Object> getPaymentList() {
    return paymentList;
  }

  public void setContractTypeClassStartDate(String contractTypeClassStartDate) {
    this.contractTypeClassStartDate = contractTypeClassStartDate;
  }

  public String getContractTypeClassStartDate() {
    return contractTypeClassStartDate;
  }

  public void setBlankDto(BlankDto blankDto) {
    this.blankDto = blankDto;
  }

  public BlankDto getBlankDto() {
    return blankDto;
  }

  public void setPremiumRur(int premiumRur) {
    this.premiumRur = premiumRur;
  }

  public int getPremiumRur() {
    return premiumRur;
  }

  public void setCanPayWithoutDoc(boolean canPayWithoutDoc) {
    this.canPayWithoutDoc = canPayWithoutDoc;
  }

  public boolean isCanPayWithoutDoc() {
    return canPayWithoutDoc;
  }

  public void setReservationValueList(List<Object> reservationValueList) {
    this.reservationValueList = reservationValueList;
  }

  public List<Object> getReservationValueList() {
    return reservationValueList;
  }

  public void setEntityPurpose(String entityPurpose) {
    this.entityPurpose = entityPurpose;
  }

  public String getEntityPurpose() {
    return entityPurpose;
  }

  public void setLiabilitySum(int liabilitySum) {
    this.liabilitySum = liabilitySum;
  }

  public int getLiabilitySum() {
    return liabilitySum;
  }

  public void setCalculatedPremium(int calculatedPremium) {
    this.calculatedPremium = calculatedPremium;
  }

  public int getCalculatedPremium() {
    return calculatedPremium;
  }

  public void setIsPledgedProperty(boolean isPledgedProperty) {
    this.isPledgedProperty = isPledgedProperty;
  }

  public boolean isIsPledgedProperty() {
    return isPledgedProperty;
  }

  public void setIsProcessPersInfo(boolean isProcessPersInfo) {
    this.isProcessPersInfo = isProcessPersInfo;
  }

  public boolean isIsProcessPersInfo() {
    return isProcessPersInfo;
  }

  public void setPersonLinkList(List<Object> personLinkList) {
    this.personLinkList = personLinkList;
  }

  public List<Object> getPersonLinkList() {
    return personLinkList;
  }

  public void setPreviousContractSeries(String previousContractSeries) {
    this.previousContractSeries = previousContractSeries;
  }

  public String getPreviousContractSeries() {
    return previousContractSeries;
  }

  public void setIsProcessPersInfoEmpty(boolean isProcessPersInfoEmpty) {
    this.isProcessPersInfoEmpty = isProcessPersInfoEmpty;
  }

  public boolean isIsProcessPersInfoEmpty() {
    return isProcessPersInfoEmpty;
  }

  @Override
  public String toString() {
    return
            "ResponseKasco{" +
                    "contractType = '" + contractType + '\'' +
                    ",coInsuranceRole = '" + coInsuranceRole + '\'' +
                    ",premiumRate = '" + premiumRate + '\'' +
                    ",removedChangeId = '" + removedChangeId + '\'' +
                    ",program = '" + program + '\'' +
                    ",branch = '" + branch + '\'' +
                    ",parentContractOption = '" + parentContractOption + '\'' +
                    ",sapContractId = '" + sapContractId + '\'' +
                    ",validationLogList = '" + validationLogList + '\'' +
                    ",number = '" + number + '\'' +
                    ",currentContractChange = '" + currentContractChange + '\'' +
                    ",paymentScheduleType = '" + paymentScheduleType + '\'' +
                    ",autoDealer = '" + autoDealer + '\'' +
                    ",prevContractPayedCount = '" + prevContractPayedCount + '\'' +
                    ",financialUnit = '" + financialUnit + '\'' +
                    ",isCurrencyEquivalent = '" + isCurrencyEquivalent + '\'' +
                    ",id = '" + id + '\'' +
                    ",otherPartner = '" + otherPartner + '\'' +
                    ",isReceivedPrimaryDoc = '" + isReceivedPrimaryDoc + '\'' +
                    ",privilegedProlongation = '" + privilegedProlongation + '\'' +
                    ",beneficiarList = '" + beneficiarList + '\'' +
                    ",premiumChargeType = '" + premiumChargeType + '\'' +
                    ",agreementList = '" + agreementList + '\'' +
                    ",insurerPersonTypeCode = '" + insurerPersonTypeCode + '\'' +
                    ",blankChangeReasonDto = '" + blankChangeReasonDto + '\'' +
                    ",isExtPrefProlong = '" + isExtPrefProlong + '\'' +
                    ",creationType = '" + creationType + '\'' +
                    ",vehicleCount = '" + vehicleCount + '\'' +
                    ",saleChannel = '" + saleChannel + '\'' +
                    ",coInsuranceCompany = '" + coInsuranceCompany + '\'' +
                    ",insuranceByFirstRisk = '" + insuranceByFirstRisk + '\'' +
                    ",status = '" + status + '\'' +
                    ",noBlank = '" + noBlank + '\'' +
                    ",isCoInsurance = '" + isCoInsurance + '\'' +
                    ",agentStatementNumber = '" + agentStatementNumber + '\'' +
                    ",debitWriteOffReason = '" + debitWriteOffReason + '\'' +
                    ",isFranchiseInsteadCoeff = '" + isFranchiseInsteadCoeff + '\'' +
                    ",sapNotMigratedStatementNumberList = '" + sapNotMigratedStatementNumberList + '\'' +
                    ",premium = '" + premium + '\'' +
                    ",insurer = '" + insurer + '\'' +
                    ",insBridgeParamHash = '" + insBridgeParamHash + '\'' +
                    ",liabilityEndDate = '" + liabilityEndDate + '\'' +
                    ",currency = '" + currency + '\'' +
                    ",useNewCascoDate = '" + useNewCascoDate + '\'' +
                    ",cancelReason = '" + cancelReason + '\'' +
                    ",product = '" + product + '\'' +
                    ",isStateProcurement = '" + isStateProcurement + '\'' +
                    ",parentId = '" + parentId + '\'' +
                    ",insurerId = '" + insurerId + '\'' +
                    ",agentStatementId = '" + agentStatementId + '\'' +
                    ",agentStatementDate = '" + agentStatementDate + '\'' +
                    ",series = '" + series + '\'' +
                    ",insBridgeActivationDate = '" + insBridgeActivationDate + '\'' +
                    ",coInsuranceTotalPremium = '" + coInsuranceTotalPremium + '\'' +
                    ",paymentScheduleList = '" + paymentScheduleList + '\'' +
                    ",payedSum = '" + payedSum + '\'' +
                    ",previousInsuranceCompany = '" + previousInsuranceCompany + '\'' +
                    ",isQuoteApproved = '" + isQuoteApproved + '\'' +
                    ",previousContractNumber = '" + previousContractNumber + '\'' +
                    ",contractDate = '" + contractDate + '\'' +
                    ",agentRoleList = '" + agentRoleList + '\'' +
                    ",contractChangeList = '" + contractChangeList + '\'' +
                    ",claimReturnList = '" + claimReturnList + '\'' +
                    ",coInsuranceStartDate = '" + coInsuranceStartDate + '\'' +
                    ",project = '" + project + '\'' +
                    ",office = '" + office + '\'' +
                    ",prevContractPayedSum = '" + prevContractPayedSum + '\'' +
                    ",insuranceActNumber = '" + insuranceActNumber + '\'' +
                    ",commissionList = '" + commissionList + '\'' +
                    ",driverList = '" + driverList + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",sysCreator = '" + sysCreator + '\'' +
                    ",contractTypeClass = '" + contractTypeClass + '\'' +
                    ",statementStatusCode = '" + statementStatusCode + '\'' +
                    ",sector = '" + sector + '\'' +
                    ",untypicalContractNumber = '" + untypicalContractNumber + '\'' +
                    ",contractCheckInfo = '" + contractCheckInfo + '\'' +
                    ",contractStartDate = '" + contractStartDate + '\'' +
                    ",insurerSysEditor = '" + insurerSysEditor + '\'' +
                    ",leasingCompany = '" + leasingCompany + '\'' +
                    ",isActivateAgentFromAnotherBranch = '" + isActivateAgentFromAnotherBranch + '\'' +
                    ",agentName = '" + agentName + '\'' +
                    ",debitWriteOffDate = '" + debitWriteOffDate + '\'' +
                    ",isReinsure = '" + isReinsure + '\'' +
                    ",insurerHasCellPhone = '" + insurerHasCellPhone + '\'' +
                    ",productVariant = '" + productVariant + '\'' +
                    ",isEmptySourceCheckSum = '" + isEmptySourceCheckSum + '\'' +
                    ",underwriterName = '" + underwriterName + '\'' +
                    ",premiumCalcDate = '" + premiumCalcDate + '\'' +
                    ",isCoInsuranceLeaderPayType = '" + isCoInsuranceLeaderPayType + '\'' +
                    ",paymentMethod = '" + paymentMethod + '\'' +
                    ",checkSum = '" + checkSum + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",bankIntermediary = '" + bankIntermediary + '\'' +
                    ",claimReturnSum = '" + claimReturnSum + '\'' +
                    ",sapMigrationReasonCode = '" + sapMigrationReasonCode + '\'' +
                    ",agentId = '" + agentId + '\'' +
                    ",cancelDate = '" + cancelDate + '\'' +
                    ",securityName = '" + securityName + '\'' +
                    ",stateProcurementStartDate = '" + stateProcurementStartDate + '\'' +
                    ",existActiveAsyncRequest = '" + existActiveAsyncRequest + '\'' +
                    ",previousPremium = '" + previousPremium + '\'' +
                    ",liabilityStartDate = '" + liabilityStartDate + '\'' +
                    ",liabilityType = '" + liabilityType + '\'' +
                    ",factAccruedPremiumDateStartDate = '" + factAccruedPremiumDateStartDate + '\'' +
                    ",saleGroup = '" + saleGroup + '\'' +
                    ",reinsureStartDate = '" + reinsureStartDate + '\'' +
                    ",insuredVehicleList = '" + insuredVehicleList + '\'' +
                    ",factAccruedPremium = '" + factAccruedPremium + '\'' +
                    ",agentList = '" + agentList + '\'' +
                    ",department = '" + department + '\'' +
                    ",activeAgentRolesDate = '" + activeAgentRolesDate + '\'' +
                    ",scoringFormNumber = '" + scoringFormNumber + '\'' +
                    ",insurerChangeId = '" + insurerChangeId + '\'' +
                    ",quoteDate = '" + quoteDate + '\'' +
                    ",likardData = '" + likardData + '\'' +
                    ",comments = '" + comments + '\'' +
                    ",contractOption = '" + contractOption + '\'' +
                    ",exceedsTariff = '" + exceedsTariff + '\'' +
                    ",contractEndDate = '" + contractEndDate + '\'' +
                    ",cancelStatementDate = '" + cancelStatementDate + '\'' +
                    ",requestSource = '" + requestSource + '\'' +
                    ",smsSubscription = '" + smsSubscription + '\'' +
                    ",insurerName = '" + insurerName + '\'' +
                    ",paymentList = '" + paymentList + '\'' +
                    ",contractTypeClassStartDate = '" + contractTypeClassStartDate + '\'' +
                    ",blankDto = '" + blankDto + '\'' +
                    ",premiumRur = '" + premiumRur + '\'' +
                    ",canPayWithoutDoc = '" + canPayWithoutDoc + '\'' +
                    ",reservationValueList = '" + reservationValueList + '\'' +
                    ",entityPurpose = '" + entityPurpose + '\'' +
                    ",liabilitySum = '" + liabilitySum + '\'' +
                    ",calculatedPremium = '" + calculatedPremium + '\'' +
                    ",isPledgedProperty = '" + isPledgedProperty + '\'' +
                    ",isProcessPersInfo = '" + isProcessPersInfo + '\'' +
                    ",personLinkList = '" + personLinkList + '\'' +
                    ",previousContractSeries = '" + previousContractSeries + '\'' +
                    ",isProcessPersInfoEmpty = '" + isProcessPersInfoEmpty + '\'' +
                    "}";
  }
}