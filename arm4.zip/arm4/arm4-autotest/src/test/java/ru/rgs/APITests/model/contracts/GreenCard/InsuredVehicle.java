package ru.rgs.APITests.model.contracts.GreenCard;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class InsuredVehicle {

  @SerializedName("registrationMark")
  private String registrationMark;

  @SerializedName("usedForDangerousCargo")
  private String usedForDangerousCargo;

  @SerializedName("contractId")
  private String contractId;

  @SerializedName("id")
  private String id;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("bid")
  private String bid;

  @SerializedName("subjectId")
  private String subjectId;

  @SerializedName("vehicleType")
  private VehicleType vehicleType;

  @SerializedName("territory")
  private Territory territory;

  public void setRegistrationMark(String registrationMark) {
    this.registrationMark = registrationMark;
  }

  public String getRegistrationMark() {
    return registrationMark;
  }

  public void setUsedForDangerousCargo(String usedForDangerousCargo) {
    this.usedForDangerousCargo = usedForDangerousCargo;
  }

  public String getUsedForDangerousCargo() {
    return usedForDangerousCargo;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getContractId() {
    return contractId;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setSubjectId(String subjectId) {
    this.subjectId = subjectId;
  }

  public String getSubjectId() {
    return subjectId;
  }

  public void setVehicleType(VehicleType vehicleType) {
    this.vehicleType = vehicleType;
  }

  public VehicleType getVehicleType() {
    return vehicleType;
  }

  public void setTerritory(Territory territory) {
    this.territory = territory;
  }

  public Territory getTerritory() {
    return territory;
  }

  @Override
  public String toString() {
    return
            "InsuredVehicle{" +
                    "registrationMark = '" + registrationMark + '\'' +
                    ",usedForDangerousCargo = '" + usedForDangerousCargo + '\'' +
                    ",contractId = '" + contractId + '\'' +
                    ",id = '" + id + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",subjectId = '" + subjectId + '\'' +
                    ",vehicleType = '" + vehicleType + '\'' +
                    ",territory = '" + territory + '\'' +
                    "}";
  }
}