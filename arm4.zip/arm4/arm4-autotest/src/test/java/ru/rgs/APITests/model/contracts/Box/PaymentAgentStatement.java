package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PaymentAgentStatement {

  @SerializedName("agentId")
  private String agentId;

  @SerializedName("statementDate")
  private String statementDate;

  @SerializedName("id")
  private String id;

  @SerializedName("agentPersonName")
  private String agentPersonName;

  @SerializedName("bid")
  private String bid;

  @SerializedName("agentStatementStatus")
  private AgentStatementStatus agentStatementStatus;

  @SerializedName("statementNumber")
  private String statementNumber;

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setStatementDate(String statementDate) {
    this.statementDate = statementDate;
  }

  public String getStatementDate() {
    return statementDate;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setAgentPersonName(String agentPersonName) {
    this.agentPersonName = agentPersonName;
  }

  public String getAgentPersonName() {
    return agentPersonName;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setAgentStatementStatus(AgentStatementStatus agentStatementStatus) {
    this.agentStatementStatus = agentStatementStatus;
  }

  public AgentStatementStatus getAgentStatementStatus() {
    return agentStatementStatus;
  }

  public void setStatementNumber(String statementNumber) {
    this.statementNumber = statementNumber;
  }

  public String getStatementNumber() {
    return statementNumber;
  }

  @Override
  public String toString() {
    return
            "PaymentAgentStatement{" +
                    "agentId = '" + agentId + '\'' +
                    ",statementDate = '" + statementDate + '\'' +
                    ",id = '" + id + '\'' +
                    ",agentPersonName = '" + agentPersonName + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",agentStatementStatus = '" + agentStatementStatus + '\'' +
                    ",statementNumber = '" + statementNumber + '\'' +
                    "}";
  }
}