package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PremiumRate {

  @SerializedName("rateValue")
  private String rateValue;

  @SerializedName("rateCurrencyQuantity")
  private String rateCurrencyQuantity;

  @SerializedName("currencyTypeCode")
  private String currencyTypeCode;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("rateForOne")
  private String rateForOne;

  public void setRateValue(String rateValue) {
    this.rateValue = rateValue;
  }

  public String getRateValue() {
    return rateValue;
  }

  public void setRateCurrencyQuantity(String rateCurrencyQuantity) {
    this.rateCurrencyQuantity = rateCurrencyQuantity;
  }

  public String getRateCurrencyQuantity() {
    return rateCurrencyQuantity;
  }

  public void setCurrencyTypeCode(String currencyTypeCode) {
    this.currencyTypeCode = currencyTypeCode;
  }

  public String getCurrencyTypeCode() {
    return currencyTypeCode;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setRateForOne(String rateForOne) {
    this.rateForOne = rateForOne;
  }

  public String getRateForOne() {
    return rateForOne;
  }

  @Override
  public String toString() {
    return
            "PremiumRate{" +
                    "rateValue = '" + rateValue + '\'' +
                    ",rateCurrencyQuantity = '" + rateCurrencyQuantity + '\'' +
                    ",currencyTypeCode = '" + currencyTypeCode + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",rateForOne = '" + rateForOne + '\'' +
                    "}";
  }
}