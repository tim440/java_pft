package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class InsuredVehicleListItem {

  @SerializedName("hasFranchise")
  private String hasFranchise;

  @SerializedName("cascoTerritory")
  private CascoTerritory cascoTerritory;

  @SerializedName("cascoVehicleUsagePurpose")
  private CascoVehicleUsagePurpose cascoVehicleUsagePurpose;

  @SerializedName("cascoVehicleGroup")
  private CascoVehicleGroup cascoVehicleGroup;

  @SerializedName("hasAddEquipmentGroup")
  private String hasAddEquipmentGroup;

  @SerializedName("equipmentIsInsured")
  private String equipmentIsInsured;

  @SerializedName("usePurposeList")
  private List<UsePurposeListItem> usePurposeList;

  @SerializedName("regDocumentSeries")
  private String regDocumentSeries;

  @SerializedName("subjectId")
  private String subjectId;

  @SerializedName("vehicle")
  private Vehicle vehicle;

  @SerializedName("vehicleCategoryName")
  private String vehicleCategoryName;

  @SerializedName("premium")
  private String premium;

  @SerializedName("infoAlarmSystemList")
  private List<InfoAlarmSystemListItem> infoAlarmSystemList;

  @SerializedName("registrationDate")
  private String registrationDate;

  @SerializedName("trailerUsed")
  private String trailerUsed;

  @SerializedName("regDocTypeList")
  private List<RegDocTypeListItem> regDocTypeList;

  @SerializedName("id")
  private String id;

  @SerializedName("riskObjectGroupList")
  private List<RiskObjectGroupListItem> riskObjectGroupList;

  @SerializedName("cascoInsurTerritory")
  private CascoInsurTerritory cascoInsurTerritory;

  @SerializedName("actualCost")
  private String actualCost;

  @SerializedName("vehicleAlarmTypeList")
  private List<VehicleAlarmTypeListItem> vehicleAlarmTypeList;

  @SerializedName("liability")
  private String liability;

  @SerializedName("regDocType")
  private RegDocType regDocType;

  @SerializedName("vehicleGroupList")
  private List<VehicleGroupListItem> vehicleGroupList;

  @SerializedName("hasAccidentGroup")
  private String hasAccidentGroup;

  @SerializedName("isNew")
  private String isNew;

  @SerializedName("isRent")
  private String isRent;

  @SerializedName("isCascoVehicleGroupAutodetected")
  private String isCascoVehicleGroupAutodetected;

  @SerializedName("contractId")
  private String contractId;

  @SerializedName("regDocumentNumber")
  private String regDocumentNumber;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("bid")
  private String bid;

  @SerializedName("hasDsagoGroup")
  private String hasDsagoGroup;

  @SerializedName("cascoInsurTerritoryList")
  private List<CascoInsurTerritoryListItem> cascoInsurTerritoryList;

  @SerializedName("drivingLimitationType")
  private DrivingLimitationType drivingLimitationType;

  public void setHasFranchise(String hasFranchise) {
    this.hasFranchise = hasFranchise;
  }

  public String getHasFranchise() {
    return hasFranchise;
  }

  public void setCascoTerritory(CascoTerritory cascoTerritory) {
    this.cascoTerritory = cascoTerritory;
  }

  public CascoTerritory getCascoTerritory() {
    return cascoTerritory;
  }

  public void setCascoVehicleUsagePurpose(CascoVehicleUsagePurpose cascoVehicleUsagePurpose) {
    this.cascoVehicleUsagePurpose = cascoVehicleUsagePurpose;
  }

  public CascoVehicleUsagePurpose getCascoVehicleUsagePurpose() {
    return cascoVehicleUsagePurpose;
  }

  public void setCascoVehicleGroup(CascoVehicleGroup cascoVehicleGroup) {
    this.cascoVehicleGroup = cascoVehicleGroup;
  }

  public CascoVehicleGroup getCascoVehicleGroup() {
    return cascoVehicleGroup;
  }

  public void setHasAddEquipmentGroup(String hasAddEquipmentGroup) {
    this.hasAddEquipmentGroup = hasAddEquipmentGroup;
  }

  public String getHasAddEquipmentGroup() {
    return hasAddEquipmentGroup;
  }

  public void setEquipmentIsInsured(String equipmentIsInsured) {
    this.equipmentIsInsured = equipmentIsInsured;
  }

  public String getEquipmentIsInsured() {
    return equipmentIsInsured;
  }

  public void setUsePurposeList(List<UsePurposeListItem> usePurposeList) {
    this.usePurposeList = usePurposeList;
  }

  public List<UsePurposeListItem> getUsePurposeList() {
    return usePurposeList;
  }

  public void setRegDocumentSeries(String regDocumentSeries) {
    this.regDocumentSeries = regDocumentSeries;
  }

  public String getRegDocumentSeries() {
    return regDocumentSeries;
  }

  public void setSubjectId(String subjectId) {
    this.subjectId = subjectId;
  }

  public String getSubjectId() {
    return subjectId;
  }

  public void setVehicle(Vehicle vehicle) {
    this.vehicle = vehicle;
  }

  public Vehicle getVehicle() {
    return vehicle;
  }

  public void setVehicleCategoryName(String vehicleCategoryName) {
    this.vehicleCategoryName = vehicleCategoryName;
  }

  public String getVehicleCategoryName() {
    return vehicleCategoryName;
  }

  public void setPremium(String premium) {
    this.premium = premium;
  }

  public String getPremium() {
    return premium;
  }

  public void setInfoAlarmSystemList(List<InfoAlarmSystemListItem> infoAlarmSystemList) {
    this.infoAlarmSystemList = infoAlarmSystemList;
  }

  public List<InfoAlarmSystemListItem> getInfoAlarmSystemList() {
    return infoAlarmSystemList;
  }

  public void setRegistrationDate(String registrationDate) {
    this.registrationDate = registrationDate;
  }

  public String getRegistrationDate() {
    return registrationDate;
  }

  public void setTrailerUsed(String trailerUsed) {
    this.trailerUsed = trailerUsed;
  }

  public String getTrailerUsed() {
    return trailerUsed;
  }

  public void setRegDocTypeList(List<RegDocTypeListItem> regDocTypeList) {
    this.regDocTypeList = regDocTypeList;
  }

  public List<RegDocTypeListItem> getRegDocTypeList() {
    return regDocTypeList;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setRiskObjectGroupList(List<RiskObjectGroupListItem> riskObjectGroupList) {
    this.riskObjectGroupList = riskObjectGroupList;
  }

  public List<RiskObjectGroupListItem> getRiskObjectGroupList() {
    return riskObjectGroupList;
  }

  public void setCascoInsurTerritory(CascoInsurTerritory cascoInsurTerritory) {
    this.cascoInsurTerritory = cascoInsurTerritory;
  }

  public CascoInsurTerritory getCascoInsurTerritory() {
    return cascoInsurTerritory;
  }

  public void setActualCost(String actualCost) {
    this.actualCost = actualCost;
  }

  public String getActualCost() {
    return actualCost;
  }

  public void setVehicleAlarmTypeList(List<VehicleAlarmTypeListItem> vehicleAlarmTypeList) {
    this.vehicleAlarmTypeList = vehicleAlarmTypeList;
  }

  public List<VehicleAlarmTypeListItem> getVehicleAlarmTypeList() {
    return vehicleAlarmTypeList;
  }

  public void setLiability(String liability) {
    this.liability = liability;
  }

  public String getLiability() {
    return liability;
  }

  public void setRegDocType(RegDocType regDocType) {
    this.regDocType = regDocType;
  }

  public RegDocType getRegDocType() {
    return regDocType;
  }

  public void setVehicleGroupList(List<VehicleGroupListItem> vehicleGroupList) {
    this.vehicleGroupList = vehicleGroupList;
  }

  public List<VehicleGroupListItem> getVehicleGroupList() {
    return vehicleGroupList;
  }

  public void setHasAccidentGroup(String hasAccidentGroup) {
    this.hasAccidentGroup = hasAccidentGroup;
  }

  public String getHasAccidentGroup() {
    return hasAccidentGroup;
  }

  public void setIsNew(String isNew) {
    this.isNew = isNew;
  }

  public String getIsNew() {
    return isNew;
  }

  public void setIsRent(String isRent) {
    this.isRent = isRent;
  }

  public String getIsRent() {
    return isRent;
  }

  public void setIsCascoVehicleGroupAutodetected(String isCascoVehicleGroupAutodetected) {
    this.isCascoVehicleGroupAutodetected = isCascoVehicleGroupAutodetected;
  }

  public String getIsCascoVehicleGroupAutodetected() {
    return isCascoVehicleGroupAutodetected;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getContractId() {
    return contractId;
  }

  public void setRegDocumentNumber(String regDocumentNumber) {
    this.regDocumentNumber = regDocumentNumber;
  }

  public String getRegDocumentNumber() {
    return regDocumentNumber;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setHasDsagoGroup(String hasDsagoGroup) {
    this.hasDsagoGroup = hasDsagoGroup;
  }

  public String getHasDsagoGroup() {
    return hasDsagoGroup;
  }

  public void setCascoInsurTerritoryList(List<CascoInsurTerritoryListItem> cascoInsurTerritoryList) {
    this.cascoInsurTerritoryList = cascoInsurTerritoryList;
  }

  public List<CascoInsurTerritoryListItem> getCascoInsurTerritoryList() {
    return cascoInsurTerritoryList;
  }

  public void setDrivingLimitationType(DrivingLimitationType drivingLimitationType) {
    this.drivingLimitationType = drivingLimitationType;
  }

  public DrivingLimitationType getDrivingLimitationType() {
    return drivingLimitationType;
  }

  @Override
  public String toString() {
    return
            "InsuredVehicleListItem{" +
                    "hasFranchise = '" + hasFranchise + '\'' +
                    ",cascoTerritory = '" + cascoTerritory + '\'' +
                    ",cascoVehicleUsagePurpose = '" + cascoVehicleUsagePurpose + '\'' +
                    ",cascoVehicleGroup = '" + cascoVehicleGroup + '\'' +
                    ",hasAddEquipmentGroup = '" + hasAddEquipmentGroup + '\'' +
                    ",equipmentIsInsured = '" + equipmentIsInsured + '\'' +
                    ",usePurposeList = '" + usePurposeList + '\'' +
                    ",regDocumentSeries = '" + regDocumentSeries + '\'' +
                    ",subjectId = '" + subjectId + '\'' +
                    ",vehicle = '" + vehicle + '\'' +
                    ",vehicleCategoryName = '" + vehicleCategoryName + '\'' +
                    ",premium = '" + premium + '\'' +
                    ",infoAlarmSystemList = '" + infoAlarmSystemList + '\'' +
                    ",registrationDate = '" + registrationDate + '\'' +
                    ",trailerUsed = '" + trailerUsed + '\'' +
                    ",regDocTypeList = '" + regDocTypeList + '\'' +
                    ",id = '" + id + '\'' +
                    ",riskObjectGroupList = '" + riskObjectGroupList + '\'' +
                    ",cascoInsurTerritory = '" + cascoInsurTerritory + '\'' +
                    ",actualCost = '" + actualCost + '\'' +
                    ",vehicleAlarmTypeList = '" + vehicleAlarmTypeList + '\'' +
                    ",liability = '" + liability + '\'' +
                    ",regDocType = '" + regDocType + '\'' +
                    ",vehicleGroupList = '" + vehicleGroupList + '\'' +
                    ",hasAccidentGroup = '" + hasAccidentGroup + '\'' +
                    ",isNew = '" + isNew + '\'' +
                    ",isRent = '" + isRent + '\'' +
                    ",isCascoVehicleGroupAutodetected = '" + isCascoVehicleGroupAutodetected + '\'' +
                    ",contractId = '" + contractId + '\'' +
                    ",regDocumentNumber = '" + regDocumentNumber + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",hasDsagoGroup = '" + hasDsagoGroup + '\'' +
                    ",cascoInsurTerritoryList = '" + cascoInsurTerritoryList + '\'' +
                    ",drivingLimitationType = '" + drivingLimitationType + '\'' +
                    "}";
  }
}