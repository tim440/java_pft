package ru.rgs.APITests.model.contracts.dsago.create;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Vehicle{

	@Override
 	public String toString(){
		return 
			"Vehicle{" + 
			"}";
		}
}