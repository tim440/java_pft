package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class CoeffValueListItem {

  @SerializedName("calcCoeffValue")
  private String calcCoeffValue;

  @SerializedName("allowCorrection")
  private String allowCorrection;

  @SerializedName("coefficient")
  private Coefficient coefficient;

  @SerializedName("id")
  private String id;

  @SerializedName("value")
  private String value;

  public void setCalcCoeffValue(String calcCoeffValue) {
    this.calcCoeffValue = calcCoeffValue;
  }

  public String getCalcCoeffValue() {
    return calcCoeffValue;
  }

  public void setAllowCorrection(String allowCorrection) {
    this.allowCorrection = allowCorrection;
  }

  public String getAllowCorrection() {
    return allowCorrection;
  }

  public void setCoefficient(Coefficient coefficient) {
    this.coefficient = coefficient;
  }

  public Coefficient getCoefficient() {
    return coefficient;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return
            "CoeffValueListItem{" +
                    "calcCoeffValue = '" + calcCoeffValue + '\'' +
                    ",allowCorrection = '" + allowCorrection + '\'' +
                    ",coefficient = '" + coefficient + '\'' +
                    ",id = '" + id + '\'' +
                    ",value = '" + value + '\'' +
                    "}";
  }
}