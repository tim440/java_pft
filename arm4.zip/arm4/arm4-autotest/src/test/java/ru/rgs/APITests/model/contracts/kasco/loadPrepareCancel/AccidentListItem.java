package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class AccidentListItem {

  @SerializedName("accidentType")
  private AccidentType accidentType;

  @SerializedName("selected")
  private String selected;

  public void setAccidentType(AccidentType accidentType) {
    this.accidentType = accidentType;
  }

  public AccidentType getAccidentType() {
    return accidentType;
  }

  public void setSelected(String selected) {
    this.selected = selected;
  }

  public String getSelected() {
    return selected;
  }

  @Override
  public String toString() {
    return
            "AccidentListItem{" +
                    "accidentType = '" + accidentType + '\'' +
                    ",selected = '" + selected + '\'' +
                    "}";
  }
}