package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class GroupChoiceRuleListItem {

  @SerializedName("sourceId")
  private String sourceId;

  @SerializedName("targetId")
  private String targetId;

  @SerializedName("productId")
  private String productId;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("choiceRule")
  private ChoiceRule choiceRule;

  @SerializedName("startDate")
  private String startDate;

  public void setSourceId(String sourceId) {
    this.sourceId = sourceId;
  }

  public String getSourceId() {
    return sourceId;
  }

  public void setTargetId(String targetId) {
    this.targetId = targetId;
  }

  public String getTargetId() {
    return targetId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public String getProductId() {
    return productId;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setChoiceRule(ChoiceRule choiceRule) {
    this.choiceRule = choiceRule;
  }

  public ChoiceRule getChoiceRule() {
    return choiceRule;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  @Override
  public String toString() {
    return
            "GroupChoiceRuleListItem{" +
                    "sourceId = '" + sourceId + '\'' +
                    ",targetId = '" + targetId + '\'' +
                    ",productId = '" + productId + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",choiceRule = '" + choiceRule + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    "}";
  }
}