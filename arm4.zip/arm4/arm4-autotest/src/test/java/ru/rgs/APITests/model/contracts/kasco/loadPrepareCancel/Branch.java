package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Branch {

  @SerializedName("blankType")
  private BlankType blankType;

  @SerializedName("code")
  private String code;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("parentId")
  private String parentId;

  @SerializedName("countrySubjectId")
  private String countrySubjectId;

  @SerializedName("isIdPregenerated")
  private String isIdPregenerated;

  @SerializedName("displayValue")
  private String displayValue;

  @SerializedName("branchTypeId")
  private String branchTypeId;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("name")
  private String name;

  @SerializedName("sysCreator")
  private String sysCreator;

  @SerializedName("id")
  private String id;

  @SerializedName("bid")
  private String bid;

  @SerializedName("startDate")
  private String startDate;

  public void setBlankType(BlankType blankType) {
    this.blankType = blankType;
  }

  public BlankType getBlankType() {
    return blankType;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setParentId(String parentId) {
    this.parentId = parentId;
  }

  public String getParentId() {
    return parentId;
  }

  public void setCountrySubjectId(String countrySubjectId) {
    this.countrySubjectId = countrySubjectId;
  }

  public String getCountrySubjectId() {
    return countrySubjectId;
  }

  public void setIsIdPregenerated(String isIdPregenerated) {
    this.isIdPregenerated = isIdPregenerated;
  }

  public String getIsIdPregenerated() {
    return isIdPregenerated;
  }

  public void setDisplayValue(String displayValue) {
    this.displayValue = displayValue;
  }

  public String getDisplayValue() {
    return displayValue;
  }

  public void setBranchTypeId(String branchTypeId) {
    this.branchTypeId = branchTypeId;
  }

  public String getBranchTypeId() {
    return branchTypeId;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setSysCreator(String sysCreator) {
    this.sysCreator = sysCreator;
  }

  public String getSysCreator() {
    return sysCreator;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  @Override
  public String toString() {
    return
            "Branch{" +
                    "blankType = '" + blankType + '\'' +
                    ",code = '" + code + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",parentId = '" + parentId + '\'' +
                    ",countrySubjectId = '" + countrySubjectId + '\'' +
                    ",isIdPregenerated = '" + isIdPregenerated + '\'' +
                    ",displayValue = '" + displayValue + '\'' +
                    ",branchTypeId = '" + branchTypeId + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",name = '" + name + '\'' +
                    ",sysCreator = '" + sysCreator + '\'' +
                    ",id = '" + id + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    "}";
  }
}