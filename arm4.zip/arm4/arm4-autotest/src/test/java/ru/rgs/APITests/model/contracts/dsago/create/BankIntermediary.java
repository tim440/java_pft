package ru.rgs.APITests.model.contracts.dsago.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class BankIntermediary{

	@SerializedName("id")
	private String id;

	@SerializedName("codeAndName")
	private String codeAndName;

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setCodeAndName(String codeAndName){
		this.codeAndName = codeAndName;
	}

	public String getCodeAndName(){
		return codeAndName;
	}

	@Override
 	public String toString(){
		return 
			"BankIntermediary{" + 
			"id = '" + id + '\'' + 
			",codeAndName = '" + codeAndName + '\'' + 
			"}";
		}
}