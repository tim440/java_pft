package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Modification {

  @SerializedName("model")
  private Model model;

  public void setModel(Model model) {
    this.model = model;
  }

  public Model getModel() {
    return model;
  }

  @Override
  public String toString() {
    return
            "Modification{" +
                    "model = '" + model + '\'' +
                    "}";
  }
}