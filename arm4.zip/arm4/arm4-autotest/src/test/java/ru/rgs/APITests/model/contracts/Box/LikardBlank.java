package ru.rgs.APITests.model.contracts.Box;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class LikardBlank {

  @Override
  public String toString() {
    return
            "LikardBlank{" +
                    "}";
  }
}