package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ResponseLoadPrepareCancelBox {

  @SerializedName("success")
  private boolean success;

  @SerializedName("operationResult")
  private OperationResult operationResult;

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setOperationResult(OperationResult operationResult) {
    this.operationResult = operationResult;
  }

  public OperationResult getOperationResult() {
    return operationResult;
  }

  @Override
  public String toString() {
    return
            "ResponseLoadPrepareCancelGc{" +
                    "success = '" + success + '\'' +
                    ",operationResult = '" + operationResult + '\'' +
                    "}";
  }
}