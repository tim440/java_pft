package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class CoeffValueListItem {

  @SerializedName("calcCoeffValue")
  private int calcCoeffValue;

  @SerializedName("allowCorrection")
  private boolean allowCorrection;

  @SerializedName("coefficient")
  private Coefficient coefficient;

  @SerializedName("id")
  private String id;

  @SerializedName("value")
  private int value;

  public void setCalcCoeffValue(int calcCoeffValue) {
    this.calcCoeffValue = calcCoeffValue;
  }

  public int getCalcCoeffValue() {
    return calcCoeffValue;
  }

  public void setAllowCorrection(boolean allowCorrection) {
    this.allowCorrection = allowCorrection;
  }

  public boolean isAllowCorrection() {
    return allowCorrection;
  }

  public void setCoefficient(Coefficient coefficient) {
    this.coefficient = coefficient;
  }

  public Coefficient getCoefficient() {
    return coefficient;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public int getValue() {
    return value;
  }

  @Override
  public String toString() {
    return
            "CoeffValueListItem{" +
                    "calcCoeffValue = '" + calcCoeffValue + '\'' +
                    ",allowCorrection = '" + allowCorrection + '\'' +
                    ",coefficient = '" + coefficient + '\'' +
                    ",id = '" + id + '\'' +
                    ",value = '" + value + '\'' +
                    "}";
  }
}