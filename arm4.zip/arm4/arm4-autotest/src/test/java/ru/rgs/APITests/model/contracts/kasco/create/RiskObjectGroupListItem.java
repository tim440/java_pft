package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class RiskObjectGroupListItem {

  @SerializedName("franchise")
  private Franchise franchise;

  @SerializedName("cost")
  private int cost;

  @SerializedName("liability")
  private int liability;

  @SerializedName("franchiseSize")
  private int franchiseSize;

  @SerializedName("oneSeatLiability")
  private int oneSeatLiability;

  @SerializedName("type")
  private Type type;

  @SerializedName("coeffValueList")
  private List<CoeffValueListItem> coeffValueList;

  @SerializedName("accidentList")
  private List<AccidentListItem> accidentList;

  @SerializedName("premium")
  private int premium;

  @SerializedName("calcPremium")
  private int calcPremium;

  @SerializedName("trailerUsed")
  private boolean trailerUsed;

  @SerializedName("seatsQuantity")
  private int seatsQuantity;

  @SerializedName("calcTariff")
  private int calcTariff;

  @SerializedName("tariff")
  private int tariff;

  @SerializedName("franchiseUnit")
  private FranchiseUnit franchiseUnit;

  @SerializedName("selected")
  private boolean selected;

  @SerializedName("osagoTerritory")
  private OsagoTerritory osagoTerritory;

  @SerializedName("accidentInsuranceSystem")
  private String accidentInsuranceSystem;

  public void setFranchise(Franchise franchise) {
    this.franchise = franchise;
  }

  public Franchise getFranchise() {
    return franchise;
  }

  public void setCost(int cost) {
    this.cost = cost;
  }

  public int getCost() {
    return cost;
  }

  public void setLiability(int liability) {
    this.liability = liability;
  }

  public int getLiability() {
    return liability;
  }

  public void setFranchiseSize(int franchiseSize) {
    this.franchiseSize = franchiseSize;
  }

  public int getFranchiseSize() {
    return franchiseSize;
  }

  public void setOneSeatLiability(int oneSeatLiability) {
    this.oneSeatLiability = oneSeatLiability;
  }

  public int getOneSeatLiability() {
    return oneSeatLiability;
  }

  public void setType(Type type) {
    this.type = type;
  }

  public Type getType() {
    return type;
  }

  public void setCoeffValueList(List<CoeffValueListItem> coeffValueList) {
    this.coeffValueList = coeffValueList;
  }

  public List<CoeffValueListItem> getCoeffValueList() {
    return coeffValueList;
  }

  public void setAccidentList(List<AccidentListItem> accidentList) {
    this.accidentList = accidentList;
  }

  public List<AccidentListItem> getAccidentList() {
    return accidentList;
  }

  public void setPremium(int premium) {
    this.premium = premium;
  }

  public int getPremium() {
    return premium;
  }

  public void setCalcPremium(int calcPremium) {
    this.calcPremium = calcPremium;
  }

  public int getCalcPremium() {
    return calcPremium;
  }

  public void setTrailerUsed(boolean trailerUsed) {
    this.trailerUsed = trailerUsed;
  }

  public boolean isTrailerUsed() {
    return trailerUsed;
  }

  public void setSeatsQuantity(int seatsQuantity) {
    this.seatsQuantity = seatsQuantity;
  }

  public int getSeatsQuantity() {
    return seatsQuantity;
  }

  public void setCalcTariff(int calcTariff) {
    this.calcTariff = calcTariff;
  }

  public int getCalcTariff() {
    return calcTariff;
  }

  public void setTariff(int tariff) {
    this.tariff = tariff;
  }

  public int getTariff() {
    return tariff;
  }

  public void setFranchiseUnit(FranchiseUnit franchiseUnit) {
    this.franchiseUnit = franchiseUnit;
  }

  public FranchiseUnit getFranchiseUnit() {
    return franchiseUnit;
  }

  public void setSelected(boolean selected) {
    this.selected = selected;
  }

  public boolean isSelected() {
    return selected;
  }

  public void setOsagoTerritory(OsagoTerritory osagoTerritory) {
    this.osagoTerritory = osagoTerritory;
  }

  public OsagoTerritory getOsagoTerritory() {
    return osagoTerritory;
  }

  public void setAccidentInsuranceSystem(String accidentInsuranceSystem) {
    this.accidentInsuranceSystem = accidentInsuranceSystem;
  }

  public String getAccidentInsuranceSystem() {
    return accidentInsuranceSystem;
  }

  @Override
  public String toString() {
    return
            "RiskObjectGroupListItem{" +
                    "franchise = '" + franchise + '\'' +
                    ",cost = '" + cost + '\'' +
                    ",liability = '" + liability + '\'' +
                    ",franchiseSize = '" + franchiseSize + '\'' +
                    ",oneSeatLiability = '" + oneSeatLiability + '\'' +
                    ",type = '" + type + '\'' +
                    ",coeffValueList = '" + coeffValueList + '\'' +
                    ",accidentList = '" + accidentList + '\'' +
                    ",premium = '" + premium + '\'' +
                    ",calcPremium = '" + calcPremium + '\'' +
                    ",trailerUsed = '" + trailerUsed + '\'' +
                    ",seatsQuantity = '" + seatsQuantity + '\'' +
                    ",calcTariff = '" + calcTariff + '\'' +
                    ",tariff = '" + tariff + '\'' +
                    ",franchiseUnit = '" + franchiseUnit + '\'' +
                    ",selected = '" + selected + '\'' +
                    ",osagoTerritory = '" + osagoTerritory + '\'' +
                    ",accidentInsuranceSystem = '" + accidentInsuranceSystem + '\'' +
                    "}";
  }
}