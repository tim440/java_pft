package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class BeneficiarListItem {

  @SerializedName("personName")
  private String personName;

  @SerializedName("beneficiaryShare")
  private int beneficiaryShare;

  @SerializedName("personTypeCode")
  private String personTypeCode;

  @SerializedName("personId")
  private String personId;

  @SerializedName("personChangeId")
  private String personChangeId;

  @SerializedName("personSysEditor")
  private String personSysEditor;

  @SerializedName("possessionGround")
  private PossessionGround possessionGround;

  public void setPersonName(String personName) {
    this.personName = personName;
  }

  public String getPersonName() {
    return personName;
  }

  public void setBeneficiaryShare(int beneficiaryShare) {
    this.beneficiaryShare = beneficiaryShare;
  }

  public int getBeneficiaryShare() {
    return beneficiaryShare;
  }

  public void setPersonTypeCode(String personTypeCode) {
    this.personTypeCode = personTypeCode;
  }

  public String getPersonTypeCode() {
    return personTypeCode;
  }

  public void setPersonId(String personId) {
    this.personId = personId;
  }

  public String getPersonId() {
    return personId;
  }

  public void setPersonChangeId(String personChangeId) {
    this.personChangeId = personChangeId;
  }

  public String getPersonChangeId() {
    return personChangeId;
  }

  public void setPersonSysEditor(String personSysEditor) {
    this.personSysEditor = personSysEditor;
  }

  public String getPersonSysEditor() {
    return personSysEditor;
  }

  public void setPossessionGround(PossessionGround possessionGround) {
    this.possessionGround = possessionGround;
  }

  public PossessionGround getPossessionGround() {
    return possessionGround;
  }

  @Override
  public String toString() {
    return
            "BeneficiarListItem{" +
                    "personName = '" + personName + '\'' +
                    ",beneficiaryShare = '" + beneficiaryShare + '\'' +
                    ",personTypeCode = '" + personTypeCode + '\'' +
                    ",personId = '" + personId + '\'' +
                    ",personChangeId = '" + personChangeId + '\'' +
                    ",personSysEditor = '" + personSysEditor + '\'' +
                    ",possessionGround = '" + possessionGround + '\'' +
                    "}";
  }
}