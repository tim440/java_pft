package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PersonForContract {

  @SerializedName("isNotPrimaryDocContact")
  private String isNotPrimaryDocContact;

  public void setIsNotPrimaryDocContact(String isNotPrimaryDocContact) {
    this.isNotPrimaryDocContact = isNotPrimaryDocContact;
  }

  public String getIsNotPrimaryDocContact() {
    return isNotPrimaryDocContact;
  }

  @Override
  public String toString() {
    return
            "PersonForContract{" +
                    "isNotPrimaryDocContact = '" + isNotPrimaryDocContact + '\'' +
                    "}";
  }
}