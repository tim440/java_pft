package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class PaymentScheduleListItem {

  @SerializedName("isPayGovernment")
  private boolean isPayGovernment;

  @SerializedName("expectedSum")
  private int expectedSum;

  @SerializedName("invoiceNumber")
  private String invoiceNumber;

  @SerializedName("id")
  private String id;

  @SerializedName("expectedDate")
  private String expectedDate;

  @SerializedName("isPayAgreement")
  private boolean isPayAgreement;

  @SerializedName("expectedSumRur")
  private int expectedSumRur;

  public void setIsPayGovernment(boolean isPayGovernment) {
    this.isPayGovernment = isPayGovernment;
  }

  public boolean isIsPayGovernment() {
    return isPayGovernment;
  }

  public void setExpectedSum(int expectedSum) {
    this.expectedSum = expectedSum;
  }

  public int getExpectedSum() {
    return expectedSum;
  }

  public void setInvoiceNumber(String invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setExpectedDate(String expectedDate) {
    this.expectedDate = expectedDate;
  }

  public String getExpectedDate() {
    return expectedDate;
  }

  public void setIsPayAgreement(boolean isPayAgreement) {
    this.isPayAgreement = isPayAgreement;
  }

  public boolean isIsPayAgreement() {
    return isPayAgreement;
  }

  public void setExpectedSumRur(int expectedSumRur) {
    this.expectedSumRur = expectedSumRur;
  }

  public int getExpectedSumRur() {
    return expectedSumRur;
  }

  @Override
  public String toString() {
    return
            "PaymentScheduleListItem{" +
                    "isPayGovernment = '" + isPayGovernment + '\'' +
                    ",expectedSum = '" + expectedSum + '\'' +
                    ",invoiceNumber = '" + invoiceNumber + '\'' +
                    ",id = '" + id + '\'' +
                    ",expectedDate = '" + expectedDate + '\'' +
                    ",isPayAgreement = '" + isPayAgreement + '\'' +
                    ",expectedSumRur = '" + expectedSumRur + '\'' +
                    "}";
  }
}