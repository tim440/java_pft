package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class InsuredVehicle {

  @SerializedName("registrationMark")
  private String registrationMark;

  @SerializedName("insurTerritoryList")
  private List<InsurTerritoryListItem> insurTerritoryList;

  @SerializedName("regDocType")
  private RegDocType regDocType;

  @SerializedName("regDocumentSeries")
  private String regDocumentSeries;

  @SerializedName("subjectId")
  private String subjectId;

  @SerializedName("contractId")
  private String contractId;

  @SerializedName("registrationDate")
  private String registrationDate;

  @SerializedName("regDocTypeList")
  private List<RegDocTypeListItem> regDocTypeList;

  @SerializedName("regDocumentNumber")
  private String regDocumentNumber;

  @SerializedName("id")
  private String id;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("bid")
  private String bid;

  @SerializedName("territoryList")
  private List<TerritoryListItem> territoryList;

  public void setRegistrationMark(String registrationMark) {
    this.registrationMark = registrationMark;
  }

  public String getRegistrationMark() {
    return registrationMark;
  }

  public void setInsurTerritoryList(List<InsurTerritoryListItem> insurTerritoryList) {
    this.insurTerritoryList = insurTerritoryList;
  }

  public List<InsurTerritoryListItem> getInsurTerritoryList() {
    return insurTerritoryList;
  }

  public void setRegDocType(RegDocType regDocType) {
    this.regDocType = regDocType;
  }

  public RegDocType getRegDocType() {
    return regDocType;
  }

  public void setRegDocumentSeries(String regDocumentSeries) {
    this.regDocumentSeries = regDocumentSeries;
  }

  public String getRegDocumentSeries() {
    return regDocumentSeries;
  }

  public void setSubjectId(String subjectId) {
    this.subjectId = subjectId;
  }

  public String getSubjectId() {
    return subjectId;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getContractId() {
    return contractId;
  }

  public void setRegistrationDate(String registrationDate) {
    this.registrationDate = registrationDate;
  }

  public String getRegistrationDate() {
    return registrationDate;
  }

  public void setRegDocTypeList(List<RegDocTypeListItem> regDocTypeList) {
    this.regDocTypeList = regDocTypeList;
  }

  public List<RegDocTypeListItem> getRegDocTypeList() {
    return regDocTypeList;
  }

  public void setRegDocumentNumber(String regDocumentNumber) {
    this.regDocumentNumber = regDocumentNumber;
  }

  public String getRegDocumentNumber() {
    return regDocumentNumber;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setTerritoryList(List<TerritoryListItem> territoryList) {
    this.territoryList = territoryList;
  }

  public List<TerritoryListItem> getTerritoryList() {
    return territoryList;
  }

  @Override
  public String toString() {
    return
            "InsuredVehicle{" +
                    "registrationMark = '" + registrationMark + '\'' +
                    ",insurTerritoryList = '" + insurTerritoryList + '\'' +
                    ",regDocType = '" + regDocType + '\'' +
                    ",regDocumentSeries = '" + regDocumentSeries + '\'' +
                    ",subjectId = '" + subjectId + '\'' +
                    ",contractId = '" + contractId + '\'' +
                    ",registrationDate = '" + registrationDate + '\'' +
                    ",regDocTypeList = '" + regDocTypeList + '\'' +
                    ",regDocumentNumber = '" + regDocumentNumber + '\'' +
                    ",id = '" + id + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",territoryList = '" + territoryList + '\'' +
                    "}";
  }
}