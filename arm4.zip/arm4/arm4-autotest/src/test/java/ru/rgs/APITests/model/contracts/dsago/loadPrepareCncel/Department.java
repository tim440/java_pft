package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Department {

  @SerializedName("isIdPregenerated")
  private String isIdPregenerated;

  @SerializedName("blankType")
  private BlankType blankType;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("sysCreator")
  private String sysCreator;

  public void setIsIdPregenerated(String isIdPregenerated) {
    this.isIdPregenerated = isIdPregenerated;
  }

  public String getIsIdPregenerated() {
    return isIdPregenerated;
  }

  public void setBlankType(BlankType blankType) {
    this.blankType = blankType;
  }

  public BlankType getBlankType() {
    return blankType;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setSysCreator(String sysCreator) {
    this.sysCreator = sysCreator;
  }

  public String getSysCreator() {
    return sysCreator;
  }

  @Override
  public String toString() {
    return
            "Department{" +
                    "isIdPregenerated = '" + isIdPregenerated + '\'' +
                    ",blankType = '" + blankType + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",sysCreator = '" + sysCreator + '\'' +
                    "}";
  }
}