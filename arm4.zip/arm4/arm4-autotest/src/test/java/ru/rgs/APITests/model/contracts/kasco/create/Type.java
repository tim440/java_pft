package ru.rgs.APITests.model.contracts.kasco.create;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class Type {

  @SerializedName("code")
  private String code;

  @SerializedName("premiumCalcTypeId")
  private String premiumCalcTypeId;

  @SerializedName("isEnabled")
  private boolean isEnabled;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setPremiumCalcTypeId(String premiumCalcTypeId) {
    this.premiumCalcTypeId = premiumCalcTypeId;
  }

  public String getPremiumCalcTypeId() {
    return premiumCalcTypeId;
  }

  public void setIsEnabled(boolean isEnabled) {
    this.isEnabled = isEnabled;
  }

  public boolean isIsEnabled() {
    return isEnabled;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  @Override
  public String toString() {
    return
            "Type{" +
                    "code = '" + code + '\'' +
                    ",premiumCalcTypeId = '" + premiumCalcTypeId + '\'' +
                    ",isEnabled = '" + isEnabled + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    "}";
  }
}