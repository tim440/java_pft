package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class SaleGroup {

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("saleChannel")
  private SaleChannel saleChannel;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("name")
  private String name;

  @SerializedName("branchReference")
  private BranchReference branchReference;

  @SerializedName("id")
  private String id;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("sysUser")
  private String sysUser;

  @SerializedName("personReference")
  private PersonReference personReference;

  @SerializedName("startDate")
  private String startDate;

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setSaleChannel(SaleChannel saleChannel) {
    this.saleChannel = saleChannel;
  }

  public SaleChannel getSaleChannel() {
    return saleChannel;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setBranchReference(BranchReference branchReference) {
    this.branchReference = branchReference;
  }

  public BranchReference getBranchReference() {
    return branchReference;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setSysUser(String sysUser) {
    this.sysUser = sysUser;
  }

  public String getSysUser() {
    return sysUser;
  }

  public void setPersonReference(PersonReference personReference) {
    this.personReference = personReference;
  }

  public PersonReference getPersonReference() {
    return personReference;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  @Override
  public String toString() {
    return
            "SaleGroup{" +
                    "sysEditor = '" + sysEditor + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",saleChannel = '" + saleChannel + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",name = '" + name + '\'' +
                    ",branchReference = '" + branchReference + '\'' +
                    ",id = '" + id + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",sysUser = '" + sysUser + '\'' +
                    ",personReference = '" + personReference + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    "}";
  }
}