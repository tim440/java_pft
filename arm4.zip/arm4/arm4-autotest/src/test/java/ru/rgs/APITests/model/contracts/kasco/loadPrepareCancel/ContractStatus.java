package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ContractStatus {

  @SerializedName("code")
  private String code;

  @SerializedName("sortOrder")
  private String sortOrder;

  @SerializedName("name")
  private String name;

  @SerializedName("isActive")
  private String isActive;

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

  public String getSortOrder() {
    return sortOrder;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setIsActive(String isActive) {
    this.isActive = isActive;
  }

  public String getIsActive() {
    return isActive;
  }

  @Override
  public String toString() {
    return
            "ContractStatus{" +
                    "code = '" + code + '\'' +
                    ",sortOrder = '" + sortOrder + '\'' +
                    ",name = '" + name + '\'' +
                    ",isActive = '" + isActive + '\'' +
                    "}";
  }
}