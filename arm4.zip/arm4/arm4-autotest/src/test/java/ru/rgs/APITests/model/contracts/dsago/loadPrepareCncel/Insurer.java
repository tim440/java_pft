package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class Insurer {

  @SerializedName("lastName")
  private String lastName;

  @SerializedName("isNotResident")
  private String isNotResident;

  @SerializedName("isInboul")
  private String isInboul;

  @SerializedName("displayName")
  private String displayName;

  @SerializedName("isOverload")
  private String isOverload;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("isForeignPublic")
  private String isForeignPublic;

  @SerializedName("businessmanRgsAgent")
  private String businessmanRgsAgent;

  @SerializedName("entityChangeId")
  private String entityChangeId;

  @SerializedName("id")
  private String id;

  @SerializedName("personType")
  private PersonType personType;

  @SerializedName("secondName")
  private String secondName;

  @SerializedName("bonusMalusList")
  private List<BonusMalusListItem> bonusMalusList;

  @SerializedName("addressShortInfo")
  private String addressShortInfo;

  @SerializedName("isIpension")
  private String isIpension;

  @SerializedName("personForContract")
  private PersonForContract personForContract;

  @SerializedName("primaryDocumentTypeList")
  private List<PrimaryDocumentTypeListItem> primaryDocumentTypeList;

  @SerializedName("sex")
  private String sex;

  @SerializedName("additionalDocumentTypeList")
  private List<AdditionalDocumentTypeListItem> additionalDocumentTypeList;

  @SerializedName("vehicleTypeList")
  private List<VehicleTypeListItem> vehicleTypeList;

  @SerializedName("personChangeList")
  private List<PersonChangeListItem> personChangeList;

  @SerializedName("birthDate")
  private String birthDate;

  @SerializedName("personProfileId")
  private String personProfileId;

  @SerializedName("firstName")
  private String firstName;

  @SerializedName("contactList")
  private List<ContactListItem> contactList;

  @SerializedName("nationality")
  private Nationality nationality;

  @SerializedName("documentList")
  private List<DocumentListItem> documentList;

  @SerializedName("isNotOkved")
  private String isNotOkved;

  @SerializedName("primaryAddress")
  private PrimaryAddress primaryAddress;

  @SerializedName("additionalAddress")
  private AdditionalAddress additionalAddress;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("bid")
  private String bid;

  @SerializedName("vipCode")
  private String vipCode;

  @SerializedName("possessionGroundList")
  private List<PossessionGroundListItem> possessionGroundList;

  @SerializedName("isNotPrimaryDocContact")
  private String isNotPrimaryDocContact;

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setIsNotResident(String isNotResident) {
    this.isNotResident = isNotResident;
  }

  public String getIsNotResident() {
    return isNotResident;
  }

  public void setIsInboul(String isInboul) {
    this.isInboul = isInboul;
  }

  public String getIsInboul() {
    return isInboul;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setIsOverload(String isOverload) {
    this.isOverload = isOverload;
  }

  public String getIsOverload() {
    return isOverload;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setIsForeignPublic(String isForeignPublic) {
    this.isForeignPublic = isForeignPublic;
  }

  public String getIsForeignPublic() {
    return isForeignPublic;
  }

  public void setBusinessmanRgsAgent(String businessmanRgsAgent) {
    this.businessmanRgsAgent = businessmanRgsAgent;
  }

  public String getBusinessmanRgsAgent() {
    return businessmanRgsAgent;
  }

  public void setEntityChangeId(String entityChangeId) {
    this.entityChangeId = entityChangeId;
  }

  public String getEntityChangeId() {
    return entityChangeId;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setPersonType(PersonType personType) {
    this.personType = personType;
  }

  public PersonType getPersonType() {
    return personType;
  }

  public void setSecondName(String secondName) {
    this.secondName = secondName;
  }

  public String getSecondName() {
    return secondName;
  }

  public void setBonusMalusList(List<BonusMalusListItem> bonusMalusList) {
    this.bonusMalusList = bonusMalusList;
  }

  public List<BonusMalusListItem> getBonusMalusList() {
    return bonusMalusList;
  }

  public void setAddressShortInfo(String addressShortInfo) {
    this.addressShortInfo = addressShortInfo;
  }

  public String getAddressShortInfo() {
    return addressShortInfo;
  }

  public void setIsIpension(String isIpension) {
    this.isIpension = isIpension;
  }

  public String getIsIpension() {
    return isIpension;
  }

  public void setPersonForContract(PersonForContract personForContract) {
    this.personForContract = personForContract;
  }

  public PersonForContract getPersonForContract() {
    return personForContract;
  }

  public void setPrimaryDocumentTypeList(List<PrimaryDocumentTypeListItem> primaryDocumentTypeList) {
    this.primaryDocumentTypeList = primaryDocumentTypeList;
  }

  public List<PrimaryDocumentTypeListItem> getPrimaryDocumentTypeList() {
    return primaryDocumentTypeList;
  }

  public void setSex(String sex) {
    this.sex = sex;
  }

  public String getSex() {
    return sex;
  }

  public void setAdditionalDocumentTypeList(List<AdditionalDocumentTypeListItem> additionalDocumentTypeList) {
    this.additionalDocumentTypeList = additionalDocumentTypeList;
  }

  public List<AdditionalDocumentTypeListItem> getAdditionalDocumentTypeList() {
    return additionalDocumentTypeList;
  }

  public void setVehicleTypeList(List<VehicleTypeListItem> vehicleTypeList) {
    this.vehicleTypeList = vehicleTypeList;
  }

  public List<VehicleTypeListItem> getVehicleTypeList() {
    return vehicleTypeList;
  }

  public void setPersonChangeList(List<PersonChangeListItem> personChangeList) {
    this.personChangeList = personChangeList;
  }

  public List<PersonChangeListItem> getPersonChangeList() {
    return personChangeList;
  }

  public void setBirthDate(String birthDate) {
    this.birthDate = birthDate;
  }

  public String getBirthDate() {
    return birthDate;
  }

  public void setPersonProfileId(String personProfileId) {
    this.personProfileId = personProfileId;
  }

  public String getPersonProfileId() {
    return personProfileId;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setContactList(List<ContactListItem> contactList) {
    this.contactList = contactList;
  }

  public List<ContactListItem> getContactList() {
    return contactList;
  }

  public void setNationality(Nationality nationality) {
    this.nationality = nationality;
  }

  public Nationality getNationality() {
    return nationality;
  }

  public void setDocumentList(List<DocumentListItem> documentList) {
    this.documentList = documentList;
  }

  public List<DocumentListItem> getDocumentList() {
    return documentList;
  }

  public void setIsNotOkved(String isNotOkved) {
    this.isNotOkved = isNotOkved;
  }

  public String getIsNotOkved() {
    return isNotOkved;
  }

  public void setPrimaryAddress(PrimaryAddress primaryAddress) {
    this.primaryAddress = primaryAddress;
  }

  public PrimaryAddress getPrimaryAddress() {
    return primaryAddress;
  }

  public void setAdditionalAddress(AdditionalAddress additionalAddress) {
    this.additionalAddress = additionalAddress;
  }

  public AdditionalAddress getAdditionalAddress() {
    return additionalAddress;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setVipCode(String vipCode) {
    this.vipCode = vipCode;
  }

  public String getVipCode() {
    return vipCode;
  }

  public void setPossessionGroundList(List<PossessionGroundListItem> possessionGroundList) {
    this.possessionGroundList = possessionGroundList;
  }

  public List<PossessionGroundListItem> getPossessionGroundList() {
    return possessionGroundList;
  }

  public void setIsNotPrimaryDocContact(String isNotPrimaryDocContact) {
    this.isNotPrimaryDocContact = isNotPrimaryDocContact;
  }

  public String getIsNotPrimaryDocContact() {
    return isNotPrimaryDocContact;
  }

  @Override
  public String toString() {
    return
            "Insurer{" +
                    "lastName = '" + lastName + '\'' +
                    ",isNotResident = '" + isNotResident + '\'' +
                    ",isInboul = '" + isInboul + '\'' +
                    ",displayName = '" + displayName + '\'' +
                    ",isOverload = '" + isOverload + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",isForeignPublic = '" + isForeignPublic + '\'' +
                    ",businessmanRgsAgent = '" + businessmanRgsAgent + '\'' +
                    ",entityChangeId = '" + entityChangeId + '\'' +
                    ",id = '" + id + '\'' +
                    ",personType = '" + personType + '\'' +
                    ",secondName = '" + secondName + '\'' +
                    ",bonusMalusList = '" + bonusMalusList + '\'' +
                    ",addressShortInfo = '" + addressShortInfo + '\'' +
                    ",isIpension = '" + isIpension + '\'' +
                    ",personForContract = '" + personForContract + '\'' +
                    ",primaryDocumentTypeList = '" + primaryDocumentTypeList + '\'' +
                    ",sex = '" + sex + '\'' +
                    ",additionalDocumentTypeList = '" + additionalDocumentTypeList + '\'' +
                    ",vehicleTypeList = '" + vehicleTypeList + '\'' +
                    ",personChangeList = '" + personChangeList + '\'' +
                    ",birthDate = '" + birthDate + '\'' +
                    ",personProfileId = '" + personProfileId + '\'' +
                    ",firstName = '" + firstName + '\'' +
                    ",contactList = '" + contactList + '\'' +
                    ",nationality = '" + nationality + '\'' +
                    ",documentList = '" + documentList + '\'' +
                    ",isNotOkved = '" + isNotOkved + '\'' +
                    ",primaryAddress = '" + primaryAddress + '\'' +
                    ",additionalAddress = '" + additionalAddress + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",vipCode = '" + vipCode + '\'' +
                    ",possessionGroundList = '" + possessionGroundList + '\'' +
                    ",isNotPrimaryDocContact = '" + isNotPrimaryDocContact + '\'' +
                    "}";
  }
}