package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class AccidentType {

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("code")
  private String code;

  @SerializedName("accidentClass")
  private AccidentClass accidentClass;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("sysSource")
  private String sysSource;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  @SerializedName("lastModified")
  private String lastModified;

  @SerializedName("sysUser")
  private String sysUser;

  @SerializedName("startDate")
  private String startDate;

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setAccidentClass(AccidentClass accidentClass) {
    this.accidentClass = accidentClass;
  }

  public AccidentClass getAccidentClass() {
    return accidentClass;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setSysSource(String sysSource) {
    this.sysSource = sysSource;
  }

  public String getSysSource() {
    return sysSource;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setLastModified(String lastModified) {
    this.lastModified = lastModified;
  }

  public String getLastModified() {
    return lastModified;
  }

  public void setSysUser(String sysUser) {
    this.sysUser = sysUser;
  }

  public String getSysUser() {
    return sysUser;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  @Override
  public String toString() {
    return
            "AccidentType{" +
                    "sysEditor = '" + sysEditor + '\'' +
                    ",code = '" + code + '\'' +
                    ",accidentClass = '" + accidentClass + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",sysSource = '" + sysSource + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    ",lastModified = '" + lastModified + '\'' +
                    ",sysUser = '" + sysUser + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    "}";
  }
}