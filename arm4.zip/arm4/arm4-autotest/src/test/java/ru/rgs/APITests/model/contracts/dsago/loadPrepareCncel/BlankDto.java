package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class BlankDto {

  @SerializedName("number")
  private String number;

  @SerializedName("series")
  private String series;

  public void setNumber(String number) {
    this.number = number;
  }

  public String getNumber() {
    return number;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public String getSeries() {
    return series;
  }

  @Override
  public String toString() {
    return
            "BlankDto{" +
                    "number = '" + number + '\'' +
                    ",series = '" + series + '\'' +
                    "}";
  }
}