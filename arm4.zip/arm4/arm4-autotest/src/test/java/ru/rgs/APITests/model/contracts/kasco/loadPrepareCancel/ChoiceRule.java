package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class ChoiceRule {

  @SerializedName("code")
  private String code;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("targetAction")
  private String targetAction;

  @SerializedName("sortOrder")
  private String sortOrder;

  @SerializedName("name")
  private String name;

  @SerializedName("id")
  private String id;

  @SerializedName("startDate")
  private String startDate;

  @SerializedName("codeAndName")
  private String codeAndName;

  @SerializedName("sourceAction")
  private String sourceAction;

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setTargetAction(String targetAction) {
    this.targetAction = targetAction;
  }

  public String getTargetAction() {
    return targetAction;
  }

  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

  public String getSortOrder() {
    return sortOrder;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setCodeAndName(String codeAndName) {
    this.codeAndName = codeAndName;
  }

  public String getCodeAndName() {
    return codeAndName;
  }

  public void setSourceAction(String sourceAction) {
    this.sourceAction = sourceAction;
  }

  public String getSourceAction() {
    return sourceAction;
  }

  @Override
  public String toString() {
    return
            "ChoiceRule{" +
                    "code = '" + code + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",targetAction = '" + targetAction + '\'' +
                    ",sortOrder = '" + sortOrder + '\'' +
                    ",name = '" + name + '\'' +
                    ",id = '" + id + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    ",codeAndName = '" + codeAndName + '\'' +
                    ",sourceAction = '" + sourceAction + '\'' +
                    "}";
  }
}