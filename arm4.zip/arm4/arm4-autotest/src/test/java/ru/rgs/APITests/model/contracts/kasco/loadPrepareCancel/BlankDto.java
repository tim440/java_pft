package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class BlankDto {

  @SerializedName("number")
  private String number;

  @SerializedName("sysEditor")
  private String sysEditor;

  @SerializedName("series")
  private String series;

  @SerializedName("blankTypeCode")
  private String blankTypeCode;

  @SerializedName("id")
  private String id;

  @SerializedName("blankTypeName")
  private String blankTypeName;

  @SerializedName("blankTypeId")
  private String blankTypeId;

  public void setNumber(String number) {
    this.number = number;
  }

  public String getNumber() {
    return number;
  }

  public void setSysEditor(String sysEditor) {
    this.sysEditor = sysEditor;
  }

  public String getSysEditor() {
    return sysEditor;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public String getSeries() {
    return series;
  }

  public void setBlankTypeCode(String blankTypeCode) {
    this.blankTypeCode = blankTypeCode;
  }

  public String getBlankTypeCode() {
    return blankTypeCode;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getId() {
    return id;
  }

  public void setBlankTypeName(String blankTypeName) {
    this.blankTypeName = blankTypeName;
  }

  public String getBlankTypeName() {
    return blankTypeName;
  }

  public void setBlankTypeId(String blankTypeId) {
    this.blankTypeId = blankTypeId;
  }

  public String getBlankTypeId() {
    return blankTypeId;
  }

  @Override
  public String toString() {
    return
            "BlankDto{" +
                    "number = '" + number + '\'' +
                    ",sysEditor = '" + sysEditor + '\'' +
                    ",series = '" + series + '\'' +
                    ",blankTypeCode = '" + blankTypeCode + '\'' +
                    ",id = '" + id + '\'' +
                    ",blankTypeName = '" + blankTypeName + '\'' +
                    ",blankTypeId = '" + blankTypeId + '\'' +
                    "}";
  }
}