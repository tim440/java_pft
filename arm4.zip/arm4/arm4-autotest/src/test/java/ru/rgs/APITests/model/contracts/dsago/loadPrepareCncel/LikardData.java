package ru.rgs.APITests.model.contracts.dsago.loadPrepareCncel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class LikardData {

  @SerializedName("likardBlank")
  private LikardBlank likardBlank;

  public void setLikardBlank(LikardBlank likardBlank) {
    this.likardBlank = likardBlank;
  }

  public LikardBlank getLikardBlank() {
    return likardBlank;
  }

  @Override
  public String toString() {
    return
            "LikardData{" +
                    "likardBlank = '" + likardBlank + '\'' +
                    "}";
  }
}