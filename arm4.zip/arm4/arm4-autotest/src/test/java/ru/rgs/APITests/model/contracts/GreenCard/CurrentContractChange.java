package ru.rgs.APITests.model.contracts.GreenCard;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class CurrentContractChange {

  @SerializedName("agreementType")
  private AgreementType agreementType;

  @SerializedName("agentId")
  private String agentId;

  @SerializedName("endDate")
  private String endDate;

  @SerializedName("agentDisplayName")
  private String agentDisplayName;

  @SerializedName("contractStatusCode")
  private String contractStatusCode;

  @SerializedName("signDate")
  private String signDate;

  @SerializedName("agentStatementNumber")
  private String agentStatementNumber;

  @SerializedName("number")
  private String number;

  @SerializedName("premiumProportion")
  private String premiumProportion;

  @SerializedName("createDate")
  private String createDate;

  @SerializedName("contractCancel")
  private String contractCancel;

  @SerializedName("comments")
  private String comments;

  @SerializedName("contractStartDate")
  private String contractStartDate;

  @SerializedName("changeType")
  private ChangeType changeType;

  @SerializedName("changeTypeList")
  private List<ChangeTypeListItem> changeTypeList;

  @SerializedName("agentStatementId")
  private String agentStatementId;

  @SerializedName("agentStatementDate")
  private String agentStatementDate;

  @SerializedName("blankDto")
  private BlankDto blankDto;

  @SerializedName("series")
  private String series;

  @SerializedName("contractId")
  private String contractId;

  @SerializedName("sysModifyDate")
  private String sysModifyDate;

  @SerializedName("bid")
  private String bid;

  @SerializedName("contractClassCode")
  private String contractClassCode;

  @SerializedName("user")
  private String user;

  @SerializedName("startDate")
  private String startDate;

  public void setAgreementType(AgreementType agreementType) {
    this.agreementType = agreementType;
  }

  public AgreementType getAgreementType() {
    return agreementType;
  }

  public void setAgentId(String agentId) {
    this.agentId = agentId;
  }

  public String getAgentId() {
    return agentId;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setAgentDisplayName(String agentDisplayName) {
    this.agentDisplayName = agentDisplayName;
  }

  public String getAgentDisplayName() {
    return agentDisplayName;
  }

  public void setContractStatusCode(String contractStatusCode) {
    this.contractStatusCode = contractStatusCode;
  }

  public String getContractStatusCode() {
    return contractStatusCode;
  }

  public void setSignDate(String signDate) {
    this.signDate = signDate;
  }

  public String getSignDate() {
    return signDate;
  }

  public void setAgentStatementNumber(String agentStatementNumber) {
    this.agentStatementNumber = agentStatementNumber;
  }

  public String getAgentStatementNumber() {
    return agentStatementNumber;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getNumber() {
    return number;
  }

  public void setPremiumProportion(String premiumProportion) {
    this.premiumProportion = premiumProportion;
  }

  public String getPremiumProportion() {
    return premiumProportion;
  }

  public void setCreateDate(String createDate) {
    this.createDate = createDate;
  }

  public String getCreateDate() {
    return createDate;
  }

  public void setContractCancel(String contractCancel) {
    this.contractCancel = contractCancel;
  }

  public String getContractCancel() {
    return contractCancel;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public String getComments() {
    return comments;
  }

  public void setContractStartDate(String contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  public String getContractStartDate() {
    return contractStartDate;
  }

  public void setChangeType(ChangeType changeType) {
    this.changeType = changeType;
  }

  public ChangeType getChangeType() {
    return changeType;
  }

  public void setChangeTypeList(List<ChangeTypeListItem> changeTypeList) {
    this.changeTypeList = changeTypeList;
  }

  public List<ChangeTypeListItem> getChangeTypeList() {
    return changeTypeList;
  }

  public void setAgentStatementId(String agentStatementId) {
    this.agentStatementId = agentStatementId;
  }

  public String getAgentStatementId() {
    return agentStatementId;
  }

  public void setAgentStatementDate(String agentStatementDate) {
    this.agentStatementDate = agentStatementDate;
  }

  public String getAgentStatementDate() {
    return agentStatementDate;
  }

  public void setBlankDto(BlankDto blankDto) {
    this.blankDto = blankDto;
  }

  public BlankDto getBlankDto() {
    return blankDto;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public String getSeries() {
    return series;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  public String getContractId() {
    return contractId;
  }

  public void setSysModifyDate(String sysModifyDate) {
    this.sysModifyDate = sysModifyDate;
  }

  public String getSysModifyDate() {
    return sysModifyDate;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getBid() {
    return bid;
  }

  public void setContractClassCode(String contractClassCode) {
    this.contractClassCode = contractClassCode;
  }

  public String getContractClassCode() {
    return contractClassCode;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getUser() {
    return user;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getStartDate() {
    return startDate;
  }

  @Override
  public String toString() {
    return
            "CurrentContractChange{" +
                    "agreementType = '" + agreementType + '\'' +
                    ",agentId = '" + agentId + '\'' +
                    ",endDate = '" + endDate + '\'' +
                    ",agentDisplayName = '" + agentDisplayName + '\'' +
                    ",contractStatusCode = '" + contractStatusCode + '\'' +
                    ",signDate = '" + signDate + '\'' +
                    ",agentStatementNumber = '" + agentStatementNumber + '\'' +
                    ",number = '" + number + '\'' +
                    ",premiumProportion = '" + premiumProportion + '\'' +
                    ",createDate = '" + createDate + '\'' +
                    ",contractCancel = '" + contractCancel + '\'' +
                    ",comments = '" + comments + '\'' +
                    ",contractStartDate = '" + contractStartDate + '\'' +
                    ",changeType = '" + changeType + '\'' +
                    ",changeTypeList = '" + changeTypeList + '\'' +
                    ",agentStatementId = '" + agentStatementId + '\'' +
                    ",agentStatementDate = '" + agentStatementDate + '\'' +
                    ",blankDto = '" + blankDto + '\'' +
                    ",series = '" + series + '\'' +
                    ",contractId = '" + contractId + '\'' +
                    ",sysModifyDate = '" + sysModifyDate + '\'' +
                    ",bid = '" + bid + '\'' +
                    ",contractClassCode = '" + contractClassCode + '\'' +
                    ",user = '" + user + '\'' +
                    ",startDate = '" + startDate + '\'' +
                    "}";
  }
}