package ru.rgs.APITests.model.contracts.kasco.loadPrepareCancel;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class BlankType {

  @SerializedName("sortOrder")
  private String sortOrder;

  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

  public String getSortOrder() {
    return sortOrder;
  }

  @Override
  public String toString() {
    return
            "BlankType{" +
                    "sortOrder = '" + sortOrder + '\'' +
                    "}";
  }
}