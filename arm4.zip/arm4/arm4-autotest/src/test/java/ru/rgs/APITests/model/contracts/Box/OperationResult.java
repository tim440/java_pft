package ru.rgs.APITests.model.contracts.Box;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class OperationResult {

  @SerializedName("createObject")
  private CreateObject createObject;

  public void setCreateObject(CreateObject createObject) {
    this.createObject = createObject;
  }

  public CreateObject getCreateObject() {
    return createObject;
  }

  @Override
  public String toString() {
    return
            "OperationResult{" +
                    "createObject = '" + createObject + '\'' +
                    "}";
  }
}