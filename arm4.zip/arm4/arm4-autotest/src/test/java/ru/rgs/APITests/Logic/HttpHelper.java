package ru.rgs.APITests.Logic;

public class HttpHelper {

    HttpHelper(Application app) {
    }


}